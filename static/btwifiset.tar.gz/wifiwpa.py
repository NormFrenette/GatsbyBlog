#!/usr/local/bin/python3.9
import sys
import subprocess
import re
import time
from datetime import datetime
import pathlib
from my_logger.my_logger import mLOG as Log

FILEDIR = f"{pathlib.Path(__file__).parent.resolve()}/"


"""
on init call get_wpa_supplicant_ssids(): this is the list of all ssid already in the wpa_supplicant.conf file
on ios start - make a scan: list_AP: returns the list of AP seen by the raspberry pi, signal strength and if they have WPA encryption
then list these on the ios device.
user selects a wifi AP to connect to:
    1) if it is in the wpa_supplicant list:
        - call connect_to - which gets network number for the selected ssid and connects to it
        - connect to it and wait for OK
        - if not OK - tell user stored password incorrect and show password box to reconnect / ask to overwrite
        - when user gives password: need to rewrite the wpa_supplicant file to update password, run configure, then get-network and connect

    2) if it is not in the list:
        -show password box if encryption is true or enter NONE if no password required
        - append network to wpa_supplicant.conf
        - run wpa_cli configure
        - connect to ssid
            - if OK : we are done
            - if not OK - do as above for existing ssid with wrong password
"""
#this is used to sotre any SSID which have one type of encryption in supplicant conf file 
# and a different in live AP list
#key: SSID name      value:  locked (True or False) (this is the value as it is in the wpa_supplicant.conf file)
conflict_lock_ssid = {}

class AP:
    def __init__(self,ssid='',signal=0,locked=False,in_supplicant=False,connected=False):
        self.ssid = ssid
        self.signal = signal
        self.locked = locked
        self.in_supplicant = in_supplicant
        self.connected = connected

    def msg(self):
        return f'{self.signal}{int(self.locked)}{int(self.in_supplicant)}{int(self.connected)}{self.ssid}'

class AP_List:
    def __init__(self):
        self.wpa_supplicant_list = []
        self.list_of_APs = []
        self.get_list()

    def get_list(self):
        '''this builds the list of AP with the flags: signal (Strength), locked,in_supplicant, connected
        Particular case where an SSID is in_supplicant - but the locked status of the AP seen by Rpi and the lock status 
            stored in the wpa_supplicant.conf file do not match:
            - The network is shown as existing in_supplicant - when the user attemps to connect it will fail 
              and the password box will be shown (if going from open to locked).
        '''
        global conflict_lock_ssid
        conflict_lock_ssid = {}
        info_AP = self.get_APs()  #loads the list of AP seen by RPi with info on signal strength and open vs locked
        Log.log(f'Info_AP {info_AP}')
        self.wpa_supplicant_list = self.get_wpa_supplicant_ssids() 
        wpa_ssid = [x[0] for x in self.wpa_supplicant_list]
        current_ssid = subprocess.run(" iwgetid -r", 
                        shell=True,capture_output=True,encoding='utf-8',text=True).stdout.strip()
        try:
            seen_ssid = []
            for ap_dict in info_AP:
                target = (ap_dict['ssid'],ap_dict['encrypt'])
                #Log.log(f'doing ap list {target} check in {seen_ssid}')
                if target not in seen_ssid:
                    ap = AP()
                    #found_ssids.append({'ssid':ssid, 'signal':val, 'encrypt':'WPA' in encryption})
                    ap.ssid = ap_dict['ssid']
                    ap.signal = ap_dict['signal']
                    ap.locked = ap_dict['encrypt']
                    ap.connected = ap.ssid == current_ssid
                    ap.in_supplicant = False
                    seen_ssid.append( (ap.ssid,ap.locked) )
                    for ssid, locked in self.wpa_supplicant_list:
                        if ap.ssid == ssid:
                            ap.in_supplicant = True
                            if locked != ap.locked:
                                conflict_lock_ssid[ssid] = locked
                            break
                    self.list_of_APs.append(ap)
        except Exception as e:
            Log.log(e)

            '''if ap.ssid in wpa_ssid:
                try:
                    i = self.wpa_supplicant_list.index( (ap.ssid,ap.locked))
                    ap.in_supplicant = True
                except ValueError:
                    ap.in_supplicant = False
            '''
            

    def get_APs(self):
        """
        bssid / frequency / signal level / flags / ssid
        10:06:45:e5:01:a0	2462	-42	[WPA2-PSK-CCMP][WPS][ESS]	BELL671
        fa:b4:6a:09:02:e7	2462	-46	[WPA2-PSK-CCMP][WPS][ESS][P2P]	DIRECT-E7-HP ENVY 5000 series
        d0:4d:2c:1e:70:7d	2462	-71	[WPA2-PSK-CCMP][WPS][ESS][P2P]	DIRECT-roku-937-092AAE
        c8:b3:73:00:6a:01	2412	-87	[WPA2-PSK-CCMP][WPS][ESS]	nksan
        """
        found_ssids = []
        out = subprocess.run("wpa_cli -i wlan0 scan", 
                            shell=True,capture_output=True,encoding='utf-8',text=True).stdout
        out = subprocess.run("wpa_cli -i wlan0 scan_results", 
                            shell=True,capture_output=True,encoding='utf-8',text=True).stdout
        #this grabs the sign of the dbm strength
        ssids = re.findall('[^\s]+\s+\d+\s+(-?\d+)\s+([^\s]+)\s+([^\s]+)', out,re.DOTALL)  #   (^\s+)\s+(.*?)
        for strength,encryption,ssid in ssids:
            if '\\x00' not in ssid:
                val = 5
                if int(strength)<-39:
                    #python int function drops the decimal part: int(1.99) = 1
                    #<40=5, 40-50 =5, 51-60 = 4, 60-70: 3, 71-80: 2, 81-90: 1  smaller than -91 returns 0
                    val = max(0,int( (100+int(strength))/10 ))
                found_ssids.append({'ssid':ssid, 'signal':val, 'encrypt':'WPA' in encryption})
        return found_ssids


    def get_wpa_supplicant_ssids(self):
        """
        This gets the list of SSID already in the wpa_supplicant.conf.
        ssids - returns list of tupples ( SSID name , psk= or key_mgmt=NONE)
        this is coverted to a list of tupples (SSID name, Locked: Bool)  
            Locked = True if "psk", false - means open network because it had key_mgmt=NONE
        (returns tupple ( SSID name , psk= or key_mgmt=NONE)  )psk means using wpa, key_mgmt=NONE means open)
        We do not handle WEP / untested.
        """
        global last_suplicant_list
        ssids=[]
        filename = "/etc/wpa_supplicant/wpa_supplicant.conf"
        Log.log('opening file...')
        try:
            f = open(filename, 'r')
            data = f.read()
            f.close()
        except Exception as e:
            Log.log(e)
            return ssids
        ssids = re.findall('ssid="(.*?)"\s+(psk=|key_mgmt=NONE)', data, re.DOTALL)  # yields array of ssid
        Log.log(f'list of supplicant ssid: {ssids}')
        supplicant_ssid=[]
        for ssid,pw in ssids:
            if pw == 'key_mgmt=NONE':
                supplicant_ssid.append( (ssid,False))  #means open network
            else: 
                supplicant_ssid.append( (ssid,True))
        return(supplicant_ssid)



def connect_wait(num, timeout = 10):
    p=subprocess.Popen(f"wpa_cli -i wlan0 select_network {num}", shell=True)
    p.wait()
    n=0
    time.sleep(5)
    while n<timeout:
        connected_ssid = subprocess.run(" iwgetid -r", shell=True,capture_output=True,encoding='utf-8',text=True).stdout.strip()
        if len(connected_ssid)>0:
            break
        Log.log(n)
        n+=1
        time.sleep(1)
    try:
        msg = f'wait loop exited after {n+5} seconds with ssid: --{connected_ssid}--\n'
        f = open(f"{FILEDIR}wificonnect.log",'a+')
        f.writelines(f'{datetime.now()}\n')
        f.writelines(msg)
        f.close()
    except Exception as e:
        Log.log(e)
    return len(connected_ssid) > 0

def get_network_number(ssid):
    '''return the network number as a string or "-1" if ssid not in supplicant.conf'''
    network_number = "-1"
    if len(ssid)>0:
        out = subprocess.run("wpa_cli -i wlan0 list_networks", shell=True,capture_output=True,encoding='utf-8',text=True).stdout
        ssids = re.findall('(\d+)\s+([^\s]+)', out, re.DOTALL)  #\s+([^\s]+)
        #ssids is returned as: [('0', 'BELL671'), ('1', 'nksan')] - netwrok number, ssid
        Log.log(f'List of Networks found: {ssids}')
        for num, listed_ssid in ssids:
            if ssid == listed_ssid:
                network_number = num
                break
    return network_number

def connect_to(ssid,network_number = '-1',remove_on_fail = False):
    """
    returns a tupple (success, connected_ssid)
    this attempts to connect to the requested ssid
    if connection is established - returns success = True, if not returns succes = False
    however - if cannot connect - it will revert to the ssid to which RPi is connected
        at the time of calling this method.  if it can it will connect to that - to insure connection is maintained.
        But: even if it can reconnect to previous ssid (current_ssid) - it will return success = False because 
        it could not connect to the requested ssid

    Special case: when connecting to a network that is stored in wpa_supplicant under one type of encryption
                  while the live AP is a different type of encryption:
        always check the conflict_lock_ssid dict: if there is a conflict return "fail" immediately.
        1) if AP is Locked (key_mgmt=WPA-PSK) and wpa_supplicant.conf is open (key_mgmt=NONE):
            - on receiving fail;
                i)  user will be shown a password box and change password method will be called 
                ii) there,  key_mgmt will be updated to WPA-PSK with password will be entered 
                iii) change password will remove the conflict entry for this ssid
                iv) connect_to will be called and connection will be successful (assuming password is correct)
        2) if AP is open but wpa_supplicant.conf is Locked (key_mgmt=WPA-PSK):
            - since we know connection fails (from conflict file)
            - change password/key_mgmt to NONE (open) - and then connect
    """
    current_ssid = subprocess.run(" iwgetid -r", shell=True,capture_output=True,encoding='utf-8',text=True).stdout.strip()
    if ssid in conflict_lock_ssid.keys():
        if  not conflict_lock_ssid[ssid]:  #AP is locked - network in wpa_supplicant.conf is open
            Log.log('conflict detected network in supplicant is open - returning fail')
            return(False,current_ssid)
        else: #AP is open - network in wpa_supplicant.conf is locked - update immediately
            Log.log('conflict detected network in supplicant is locked - changing ')
            network_number = changePassword(ssid, 'NONE')
            #now go on with the connection


    if int(network_number) < -1:
        Log.log("network number error - from CP or AD - returning")
        return(False,current_ssid)
    Log.log(f'current ssid:{current_ssid}:')
    connected_ssid = ''  # this is set only after a connection is attempted
    ssid_network = str(network_number)  #if passed, else = -1 as default
    #first get the currently connected SSID if it exists:
    if current_ssid == ssid:
        Log.log(f"method connect_to exiting because already connected to {ssid}")
        return(True,ssid)
    #get network numbers from wpa_supplicant.conf
    current_network = get_network_number(current_ssid)
    if ssid_network == "-1":
        ssid_network = get_network_number(ssid)
    #now attempt to connect to the requested ssid
    Log.log(f'connecting to: {ssid} number:{ssid_network} -- current: {current_ssid} num:{current_network}')
    if ssid_network == '-1':
        Log.log(f"method connect_to exiting because {ssid} is not in supplicant file")
        return(False,current_ssid)
    connected = connect_wait(ssid_network)
    if not connected:
        if int(current_network) > -1 :
            connected = connect_wait(current_network)
    Log.log(f'is connected = {connected} ')
    if connected:
        connected_ssid = subprocess.run(" iwgetid -r", shell=True,capture_output=True,encoding='utf-8',text=True).stdout.strip()
        Log.log(f'Connected to: {connected_ssid}')
    Log.log(f'Connect_to is returning {connected_ssid == ssid}')
    if remove_on_fail:
        if  not connected or (connected and (connected_ssid == current_ssid)):
            out = subprocess.run(f"wpa_cli -i wlan0 remove_network {ssid_network}", 
                                shell=True,capture_output=True,encoding='utf-8',text=True).stdout
            out = subprocess.run("wpa_cli -i wlan0 save_config", 
                                shell=True,capture_output=True,encoding='utf-8',text=True).stdout
    return (connected_ssid == ssid, connected_ssid)
    


def get_psk(ssid,pw):
    '''
    Note: this works for WPA/PSK encryption which requires a password of at least 8 characters and less than 63
    if pw = '' it returns the string psk=NONE - which is what wpa_supplicant expects when it is an open network
    '''
    psk = ""
    if pw == "NONE": 
        psk = 'psk=NONE' # for open network - ios will pass NONE as password
    if len(pw)>=8 and len(pw)<=63:
        out = subprocess.run(["wpa_passphrase",f'{ssid}',f'{pw}'],
                        capture_output=True,encoding='utf-8',text=True).stdout
        temp_psk = re.findall('(psk=[^\s]+)\s+\}', out, re.DOTALL)
        if len(temp_psk)>0: psk = temp_psk[0]
        Log.log(f'psk from get_psk: {psk}')
    return psk

def changePassword(ssid,pw):
    """returns -2 if password length is illegal, -3 if error"""
    global conflict_lock_ssid
    try:
        Log.log(f'method changePassword: {ssid}, {pw}')
        psk = get_psk(ssid,pw)
        if len(psk) == 0:
            Log.log(f"illegal length password len{pw}")
            return -2
        
        out = subprocess.run("wpa_cli -i wlan0 list_networks", shell=True,capture_output=True,encoding='utf-8',text=True).stdout
        ssids = re.findall('(\d+)\s+([^\s]+)', out, re.DOTALL)  #\s+([^\s]+)
        #ssids is returned as: [('0', 'BELL671'), ('1', 'nksan')] - netwrok number, ssid
        ssid_num = "-1"
        for num,found_ssid in ssids:
            if found_ssid == ssid:
                ssid_num = num
        if ssid_num != '-1':
            if psk == "psk=NONE":
                #cannot change password - need to remove network then add it as open
                out = subprocess.run(f"wpa_cli -i wlan0 remove_network {ssid_num}", 
                                    shell=True,capture_output=True,encoding='utf-8',text=True).stdout
                ssid_num = add_network(ssid,pw)

            else:
                # wpa_cli set_network 4 key_mgmt WPA-PSK
                out = subprocess.run(f'wpa_cli -i wlan0 set_network {ssid_num} key_mgmt WPA-PSK', 
                        shell=True,capture_output=True,encoding='utf-8',text=True).stdout
                Log.log('set key_mgmt',out)
                out = subprocess.run(f'wpa_cli -i wlan0 set_network {ssid_num} psk {psk[4:]}', 
                        shell=True,capture_output=True,encoding='utf-8',text=True).stdout
                Log.log('set psk',out)
                out = subprocess.run(f'wpa_cli -i wlan0 enable_network {ssid_num}', 
                                shell=True,capture_output=True,encoding='utf-8',text=True).stdout
                Log.log(f'enabling network {ssid} num: {ssid_num} returns {out}')

                out = subprocess.run(f'wpa_cli -i wlan0 save_config', 
                        shell=True,capture_output=True,encoding='utf-8',text=True).stdout

        if ssid in conflict_lock_ssid.keys():
            del conflict_lock_ssid[ssid]

        return int(ssid_num)
    except Exception as e:
        Log.log(e)
        return -3


def add_network(ssid,pw):
    """returns -2 if password length is illegal, -3 if error"""
    Log.log(f'method Add_network: {ssid}, {pw}')
    psk = get_psk(ssid,pw)
    Log.log(f'coded psk: {psk}')
    if len(psk) == 0:
            Log.log(f"illegal length password len{pw}")
            return -2
    try:
        #this returns the network number
        network_num = subprocess.run(f"wpa_cli -i wlan0 add_network", 
                        shell=True,capture_output=True,encoding='utf-8',text=True).stdout.strip()
        Log.log(f'new network number = {network_num}')
        ssid_hex=''.join([x.encode('utf-8').hex() for x in ssid])
        Log.log(f'coded ssid: {ssid_hex}', f'wpa_cli -i wlan0 set_network {network_num} ssid "{ssid_hex}"')

        out = subprocess.run(f'wpa_cli -i wlan0 set_network {network_num} ssid "{ssid_hex}"', 
                        shell=True,capture_output=True,encoding='utf-8',text=True).stdout
        Log.log(' set ssid',out)
        if psk == "psk=NONE":
            Log.log(f'psk: ',f'wpa_cli -i wlan0 set_network {network_num} key_mgmt {psk[4:]}')
            out = subprocess.run(f'wpa_cli -i wlan0 set_network {network_num} key_mgmt {psk[4:]}', 
                        shell=True,capture_output=True,encoding='utf-8',text=True).stdout
        else:
            out = subprocess.run(f'wpa_cli -i wlan0 set_network {network_num} psk {psk[4:]}', 
                        shell=True,capture_output=True,encoding='utf-8',text=True).stdout
        Log.log('set psk',out)
        out = subprocess.run(f'wpa_cli -i wlan0 enable_network {network_num}', 
                        shell=True,capture_output=True,encoding='utf-8',text=True).stdout
        Log.log(f'enabling network {out}')

        out = subprocess.run(f'wpa_cli -i wlan0 save_config', 
                        shell=True,capture_output=True,encoding='utf-8',text=True).stdout

        return int(network_num)
    except Exception as e:
        Log.log(e)
        return -3

def disconnect():
    command_str = "wpa_cli -i wlan0 disconnect"
    out= subprocess.run(command_str, 
                            shell=True,capture_output=True,encoding='utf-8',text=True).stdout

def wifi_connect(up = True):
    """
    this disconnects the wifi of the RPI - calls a file that uses sudo with chmod 777
    to run sudo ip link set wlan0 up or down
    """
    arr = [f"{FILEDIR}wifiup.py"]
    msg = 'bringing wifi up '
    if not up:
        arr = [f"{FILEDIR}wifidown.py"]
        msg = 'bringing wifi down '
    try:
        p = subprocess.Popen(arr)
        p.wait()
    except Exception as e:
        msg += e
        Log.log(e)
    f = open(f"{FILEDIR}wificonnect.log",'a')
    f.writelines(f'{datetime.now()}\n')
    f.writelines(msg)
    f.close()


    




if __name__ == "__main__":
    """
    if no arguments are passed - it means external (ios) has requested the lsit of AP only
    if only ssid is passed - no password - it means to connect to ssid already in wpa_supplicant.conf 
    if ssid and password is passed:
        either ssid is not in wpa_supplicant.conf - call add_network to add it
        or: previous connection to ssid in wpa_supplicant.conf has failed and password was requested
            in this case call add_network with ssid_exists = True to change the password
    """
    ssid=""
    pw=""
    try:
        ssid = sys.argv[1]
        pw = sys.argv[2]
        Log.log(f'ssid: {ssid} , pw: {pw}')
    except:
            Log.log("ERROR ARGS")
            pass


    '''list_of_APs = list_AP()
    #Log.log(f'list of AP: {list_of_APs}')
    list_of_AP_SSID = [x['ssid']for x in list_of_APs]
    Log.log(f'list of AP SSID: {list_of_AP_SSID}')
    wpa_supplicant_list = get_wpa_supplicant_ssids()
    '''
    x = AP_List()
    Log.log('signal  locked  in_supplicant  connected')
    for ap in x.list_of_APs:
        Log.log(ap.msg())
    Log.log(x.wpa_supplicant_list)

    

    if 1==0 and pw:
        #add_network(ssid,pw,ssid in wpa_supplicant_list)
        network_num = add_network(ssid,pw,False)
        connect_to(ssid,network_num)

    



    

