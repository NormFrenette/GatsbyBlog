
import multiprocessing
import alsaaudio
import wave
import audioop
import time
import RPi.GPIO as GPIO
import sys
import rgb_segment 
from my_logger.my_logger import mLOG
from statemgr import StateMgr,Status
import traceback
import os
import pickle
import bt_svc 
from os import path, rename, remove, truncate
from shutil import copy
from glob import glob
import re



class F_INFO():

    DATADIR = '/data'
    REPODIR = '/repo'
    PREFIX = '/data/loop'



class Loops(list):
    
    def __init__(self):
        self.multiplier = 1
        self.previous_multiplier = 1
        self.overdub_data={}
        self.base_loop_length = 0
        self.longest = 0
        self.cursor=0
        # self.has_song_name = '' - this is removed and managed with Handlers.saved_song_name
        self.current_volumes={}



    def add_loop(self,loop):
        #loop must be of class Loop
        self.append(loop)
        self.current_volumes[len(self)-1]=loop.volume
        if len(self) == 1:
            self.base_loop_length = len(loop)
            self.multiplier=1
            self.longest = self.base_loop_length
        else:
            self.compute_multiplier()
        Status.track_count=len(self)

    
    def compute_multiplier(self):
        max_length = 0
        for loop in self:
            max_length = max(max_length,len(loop))
        if max_length>0:
            self.multiplier = max_length//self.base_loop_length  
        else:
            self.multiplier=1
            self.base_loop_length=0
        self.longest = max_length
        Status.longest = self.longest

    def load_saved_loops(self):
        #to do : write something to find out filenames in directory
        #prefix=AudioParam.PREFIX
        if path.exists(F_INFO.DATADIR+'/song_info.dat'):
            fil=open(F_INFO.DATADIR+'/song_info.dat','rb')
            song_name,volumes = pickle.load(fil)
            fil.close()
            Handlers.saved_song_name = song_name
            self.current_volumes = volumes  #if it exists - this will load the last volume of track -1 (live samples)
            mLOG.log(f'reading song_info.dat name={song_name} ; volumes {volumes}',level=mLOG.INFO,
                     identifier=self.__class__.__name__)

        filename=F_INFO.PREFIX+'0.wav'
        cnt=0
        while path.exists(filename):
            try:
                volume = self.current_volumes[cnt] # note: loads loads deleted track volumes as well.
            except:
                volume=50
            self.current_volumes[cnt]=volume #make sure there is an entry in dict for all current loops
            loop=Loop(volume)
            file_ok=loop.load_wavefile(filename)
            if file_ok:
                self.add_loop(loop)
            cnt+=1
            filename=F_INFO.PREFIX+str(cnt)+'.wav'
        #make sure there is a current track volume in the current_volumes dict:
        if -1 not in self.current_volumes.keys():
            self.current_volumes[-1]=50
        Status.track_count=len(self)
    
    def delete_track(self):
        #deletes the last recorded loop from loops and rename it on disk
        # if not deleting last - index MUST BE Positive - to identify the correct wavefile
        try: 
            index=len(self)-1
            self.pop()
            if len(self)>0:
                self.compute_multiplier()
            else:
                self.multiplier=1
                self.base_loop_length=0
            file_name=F_INFO.PREFIX+str(index)+'.wav'
            mLOG.log(f'deleting last track ({file_name})',level=mLOG.INFO,
                        identifier=self.__class__.__name__)
             # this does not delete the wave file but renames to filename_deleted.wav
            #only removes it from recognized loops - but still available for a possible undo later...
            new_filename,ext=path.splitext(file_name)
            rename(file_name,new_filename+'_deleted'+ext)  #note - if ported to windows - this fails if new_filename exists
            return index
        except:
            return -1 #fail silently and do nothing (tracks won't be deleted - or no tracks existed in the first place)

    def restaure_tracks(self):
        """restaure the deleted track (loopX_deleted.wav) where X is the  loop number equal to the next possible track 
        in current state of the looper - which is to say the current track count.  
        The track is restaured by renaming it from loopX_deleted.wav to loopX.wav, and incrementing the track count accordingly.
        It is possible that a deleted track with that name was left over from a previous song that does not match the current base loop.
            To prevent this, before restoring, the track length is checked to ensure it is 
            an integer number multiple of the length of the current base loop.
        """
        index = len(self) #this points to the next loop/file 
        try:
            file_name=F_INFO.PREFIX+str(index)+'.wav'
            deleted_file_name=F_INFO.PREFIX+str(index)+'_deleted.wav'
            if os.path.isfile(deleted_file_name):
                loop=Loop()
                file_ok=loop.load_wavefile( deleted_file_name) # this loads the wavefile but does not yet add it to the loops list.
                if file_ok:
                    #check that samples length match this set of files:
                    if len(self)==0 or len(loop)%self.base_loop_length == 0:
                        mLOG.log(f'restauring last deleted track ({deleted_file_name})',level=mLOG.INFO,
                                        identifier=self.__class__.__name__)
                        rename(deleted_file_name,file_name)  #note - if ported to windows - this fails if new_filename exists.     
                        if len(self) in self.current_volumes:
                            loop.volume = self.current_volumes[len(self)]
                        self.add_loop(loop)
                        return index
                    else:
                        mLOG.log(f'could not restaure {deleted_file_name} - No match/multiple of base loop length',
                                level=mLOG.CRITICAL,identifier=self.__class__.__name__)
                else:
                    mLOG.log(f'failed to load file: {deleted_file_name}',
                                level=mLOG.CRITICAL,identifier=self.__class__.__name__)
        except Exception:
            mLOG.log(traceback.format_exc(),level=mLOG.CRITICAL,identifier=self.__class__.__name__)
        return -1

    
    def mix(self,x,y,tracks_in_mix=0):
        """ 
        x,y are Chuncks of loops - must be aligned at the same index in loops
        audioop.mul(fragment, width, factor)
        audioop.add(fragment1, fragment2, width)
        formula: 
            first time: V0x/2 + V1y/2 n=track_mixed=1,  will be 2 after mix isdone
            secnd time:  (V0x/2+V1y/2)*2/3 + V2z*1/3 = V0x/3 + V1y/3 + V2z/3 ( the n/n+1 cancels the previous factor...) track_mixed=n=2
        where V0 is the volume of the track ) (x), V1 is track 1 (y) etc.
        volume is number between 0 and 100 - where 50 gives unity gain and 100 doubles the gain
        track_in_mix is used when using mixdown of saved tracks.
        TODO: ignore inserted zero samples so volume is not reduced
        """
        if tracks_in_mix: 
            a= tracks_in_mix/(tracks_in_mix+1)
        else:
            a=self.tracks_mixed/(self.tracks_mixed+1)
        x= audioop.add(audioop.mul(x,AudioParam.SAMPLEWIDTH,a),audioop.mul(y,AudioParam.SAMPLEWIDTH,(1-a)),AudioParam.SAMPLEWIDTH)
        return x

    def mixdownsample(self,extra=b''):  
        """  
        this mixes down all tracks at the current cursor position:
            - first multiplies the sample by the current volume of the track - stored in dict current_volumes
                volume varies from 0-100, then is divided by 50 to yield a value between 0-2, 
                meaning that a volume of 50 gives unity gain with whatever record level was obtained from sound card.
            - if extra is the live sample to be mixed in (either from play or overdubbing)
                note: the extra's volume is stored in track "-1" in current_volumes
                note 2: in play mode there is always a live sample mixed in - even when the player is not playing.
                at some point - I should add a noise gate type of function that does not mix extra when it is in play mode and user is not playing.
        the method adjust_sample_index accounts for loops that are shorter then the longest loop (cursor would be too long for them)
            - audioop.mul(fragment, width, factor)
        """  
        if len(self)==1 and len(extra)==0:
            '''if only on track and no sample to mix - return the sample of the one track to play'''
            sample = audioop.mul(self[0][self.cursor],AudioParam.SAMPLEWIDTH,self[0].volume/50)
            return sample
        else:
            samples_list=[audioop.mul(loop[self.adjust_sample_index(len(loop))],AudioParam.SAMPLEWIDTH,loop.volume/50) for loop in self]  
            #if self.cursor<3: print(audioop.minmax(samples_list[0],AudioParam.SAMPLEWIDTH), 'vol=', self[0].volume)
            if len(extra)>0: 
                sample = audioop.mul(extra,AudioParam.SAMPLEWIDTH,self.current_volumes[-1]/50)
                samples_list.append(sample)
            return (lambda f,v,w: f(f,v,w))( lambda g,arr,n:  arr[0] if n==0 else self.mix(g(g,arr,n-1),arr[n],n) ,samples_list,len(samples_list)-1 ) 
            #there is a possibiity that if playing zeroes volume is too low (for a loop that samples are late in the loop - test this)

    def setup_overdub(self):
        self.overdub_data={'previous_multiplier':self.multiplier,
                            'previous_longest': self.longest,
                            'base_loop_length': self.base_loop_length}
    
    def adjust_sample_index(self,loop_length):
        #if cursor is greater then length of loop - need to remove multiple of base_loop_length to reset cursor in correct range
        if self.cursor >= loop_length:
            x=self.cursor - (self.cursor//loop_length)*loop_length
            return x
        else:
            return self.cursor

    def reset_cursor(self):
        self.cursor=0
        Status.cursor=0

    def cursor_advance(self,is_recording=False):
        self.cursor+=1
        if self.cursor >= self.longest:
            if is_recording:
                mLOG.log('ready to extend while recording:\n\r'+
                            f'cursor= {self.cursor} ; length= {self.longest} ; multiplier= {self.multiplier}')
                self.add_one()  #cursor now points to 1st element of added loop
                mLOG.log(f'loop was extended - new length= {self.longest} and multiplier= {self.multiplier}',
                        level=mLOG.INFO,identifier=self.__class__.__name__)
            else: #loop back to the beginning
                self.cursor=0
                mLOG.log(f'cursor is looping / cursor= {self.cursor} ; length= {self.longest}')
        Status.cursor = self.cursor
        Status.longest = self.longest
    
    def add_one(self):
        """when extending cursor range (length of mixdown) - we need to extend by the longest loop length 
        so there is room for the longest loop to play fully twice.  
        This means adding to the multiplier the multiplier of the longest loop - whatever it was upon entering the overdub method.
        """
        self.multiplier+=self.overdub_data['previous_multiplier']
        self.longest=self.multiplier*self.base_loop_length



class AudioParam:
    #define these constants for the audio recording and playback
    #in module wave a frame is one conversion analog-to-digital of SAMPLEWIDTH bytes - example: b'\x00x00
    SAMPLE_LENGTH = 256  #periodsize in pyalsaaudio (5.8 ms at 44.1KHz)
    FORMAT = alsaaudio.PCM_FORMAT_S16_LE  
    SAMPLEWIDTH=2 # in pyalsa audio it is infered from format  (16 bit = width of 2  x 8 bit)
    CHANNELS = 1
    RATE = 44100
    RECORD = alsaaudio.PCM_CAPTURE
    PLAY=alsaaudio.PCM_PLAYBACK
    RECDEV='output'
    PLAYDEV='default'
    #PREFIX = "/home/pi/data/loop"  -> moved to F_INFO class
    NO_KEEP = 170  #number of samples around start of loop that corresponds to no_keep_zone  (see RecLoop) - approx one second

    @staticmethod
    def params():
        """This is used for managing wave files:Wave_write.setparams(tuple)
        params is a tuple that should be (nchannels, sampwidth, framerate, nframes, comptype, compname)
        """
        a=(AudioParam.CHANNELS,AudioParam.SAMPLEWIDTH,AudioParam.RATE,0,'NONE',' ')
        return a
    


class Loop(list):

    def __init__(self,volume=50):
        self.volume = volume
    
    def convert_external_wave_file(self):
        #needs to set=up the loop (self) of audio data as list of samples of length AudioParam.SAMPLELENGTH
        # to do: allow wave files recorded elsewhere to be converted to the current Audio parameters used in Looper
        raise Exception("wave file parameters don't match current audio parameters of looper")

    def load_wavefile(self,filename):
        try:
             _file=wave.open(filename, 'rb')
             mLOG.log(f'opened {filename}')
        except wave.Error as ex:
            mLOG.log(f'wave.ERROR exception: {traceback.format_exc()}',
                                level=mLOG.CRITICAL,identifier=self.__class__.__name__)
            return False

        params=(_file.getnchannels(),_file.getsampwidth(), _file.getframerate(),0,'NONE',' ')
        frames=_file.getnframes()
        allframes=_file.readframes(frames)
        _file.close()
        if not params == AudioParam.params():
            self.convert_external_wave_file()
        else:
            #create the loop array
            n=frames//AudioParam.SAMPLE_LENGTH #number of samples in the wave file
            mLOG.log(f'loading {filename} of length = {n} samples',
                    level=mLOG.INFO,identifier=self.__class__.__name__)
            for i in range(n):
                start=i*AudioParam.SAMPLE_LENGTH*AudioParam.SAMPLEWIDTH  #to account for 2 byte width
                stop=start + AudioParam.SAMPLE_LENGTH*AudioParam.SAMPLEWIDTH
                self.append(allframes[start:stop])
        return True

    

class RecLoop(Loop):
    def __init__(self,wav_send,mdloop_length=0,cursor=0,next_loop_index=0):
        """ 
        length  & cursor info from mixed_down_loop is needed for setup in overdub
        """
        Loop.__init__(self)
        self.no_keep = (AudioParam.NO_KEEP,AudioParam.NO_KEEP) #(<begining area,>ending area) # of samples at start or end where user click start/stop where we do not keep samples
        self.record=False  #flag indicating if samples sent to rec_loop must be kept or not - for example: No if cursor is in no_keep_zone
        self.is_recording_base=False
        self.need_last_sample = -1  # needed as flag to play_audio to store the last sample position indicated by this value (-1 means not needed)
        self.file_name = F_INFO.PREFIX+str(next_loop_index)+'.wav'
        self.wav_send = wav_send
        self.wav_send.send(('START_FILE',self.file_name))
        self.setup(mdloop_length,cursor) 
        

    def setup(self,mdloop_length,cursor):
        if mdloop_length==0:
            self.record=True
            self.is_recording_base=True
        else:
            mLOG.log(f'setting up rec loop with cursor at {cursor} of loop length={mdloop_length}')
            if not self.on_record_no_keep_zone(mdloop_length,cursor):
                self.before_zeroes(cursor-1)
                self.record=True
        mLOG.log('Recording and keeping samples ' if self.record else 'setup: NOT Recording yet - waiting cursor at 0')


    def baseloop_sample(self,live_sample):
        self.append(live_sample)
        self.wav_send.send((self.file_name,live_sample))
    
    def overdub_sample(self,live_sample,cursor):
        """ 
        only call for overdub - manages the decision to start recording and records sample as required.
        this is called before mix_down to_play and right after GrabAudio has returned a live_sample
        cursor indicate next sample_index to mix & play
        we were grabbing a sample while user was hearing mixed samples at sample_index-1 being played,
            so this grabbed sample needs to go in slot = cursor-1. If already recording - this was handled by before_zeores which
            filled zeroes up to and including slot=cursor -2, and then coming here the sample grabbed while play_loop was
            playing the mixed samples at lopp_index = cursor (which coresponds to cursor-1) is added in slot -1 (by simply appending)
            (This means that when user stops recording, the next sample that arrives from Grabaudio must be stored in rec-Loop - 
            which is done in entering Looper class).
        If the user clicked in the no-keep-zone (close to end of loop) - we need to wait until cursor loops to zero before storing
            the live grabbed sample. The user will have played this live sample while hearing the mix down of previous loop at index = 0,
            which is cursor=0. But the actual grabbed live sample will not be delivered until cursor has advanced to 1.  So we need to get
            this sample and store it in slot 0 of the rec loop.
            This is done by waiting to see cursor = 0, and "arming" the recording flag - but not recording the sample 
            (since at cursor zero, the live sample delivered corresponds to the last sample of the loop at index=n-1 - and we do not want this one.)
            the next time this method is called, cursor will be at 1, and sample being delivered will be the one corresponding to played mix at cursor 0,
            and this sample will be stored in slot 0 of rec_loop (via rec-loop.append(sample)).
            similarily to the above though, when user clicks stop recording, the last sample will be delivered while state as moved to Looper class
            and it will be stored in the proper location of rec_loop - which before that has been filled with zeroes via after zeroes method

        live sample was being grabbed while mix-down was playing cursor-1 sample
        if user clicks while in no_keep_zone to enter overdub - ignore all samples until cursor loops to 0
        then set-up recording.  However at cursor == 0, while turning on recording, do not record the sample
        since it corresponds to last sample of loop whene Looper was not recording.

        returns True if sample was recorded  (but this is not used anymore since mix is not sotred in mix_down_loop)
        """
        if self.record:
                self.append(live_sample)
                self.wav_send.send((self.file_name,live_sample))
                return True
        elif cursor==0:
            self.record=True #sets up recording for next sample, but pass on this one because it's last of last loop around
            return False
        return False

    def store_last_sample(self,live_sample):
        """
        stores the live_sample that arrives in play_loop upon exit from overdub
        in the location where the first zero was added when exiting recording(overdub) mode
        returns True if live_sample was added to rec_loop - as a flag to mixed_down_loop to mix it in at cursor-1
        """ 
        if self.need_last_sample > -1:
            self[self.need_last_sample]=live_sample
            mLOG.log(f'stored last sample in last recorded loop at index = {self.need_last_sample}')
            self.wav_send.send( ( 'INSERT_AT',(self.need_last_sample,live_sample) ) )
            time.sleep(0.0005)
            self.wav_send.send(('END_FILE',self.file_name))
            self.need_last_sample=-1
            
            return True
        else:
            return False

    def end_record(self,cursor=1,multiplier = 1,overdub_data=None,discard=False):
        """ 
        MUST BE CALLED - when ending a recording either base or overdub
        returns True if mixed_down_loop needs to be truncated because user clicked "stop"  in no_keep_zone after begining
        if this is the case - this method truncates rec_loop correctly 
        otherwise - it fills the loop with zeroes to match the length of the mixed_down_loop
        note: no_keep_zone informs only on where the cursor was when user clicked. IF Looper was recording event
        when user clicked outside of no_keep_zone - Looper needs to add zeroes to complete the recorded loop.
        however if Looper was not recording - there should be no zeroes added (i.e. "recorded") - and rec_loop remains empty
        """ 
        if discard:
            mLOG.log('Discarding Recording due to double stomp in state mgr',
                        identifier=self.__class__.__name__)
            self.wav_send.send(('DISCARD_FILE',''))
            self.record=False
            self.is_recording_base=False
            return False

        if self.is_recording_base:
            mLOG.log(f'BaseLoop End Recording - rec_loop len = {len(self)}',
                        level=mLOG.INFO,identifier=self.__class__.__name__)
            self.record=False
            self.is_recording_base=False
            mLOG.log(f'sending end file - {self.file_name}')
            self.wav_send.send(('END_FILE',self.file_name))
            return False

        mdloop_length=multiplier*overdub_data['base_loop_length']
        if self.on_stop_no_keep_zone(cursor,multiplier,overdub_data):
            #remove everything since the last extension
            multiplier_step=overdub_data['previous_multiplier']
            del self[overdub_data['base_loop_length']*(multiplier-multiplier_step):]
            self.wav_send.send(('TRUNCATE',overdub_data['base_loop_length']*(multiplier-multiplier_step)))
            time.sleep(0.0005)
            self.wav_send.send(('END_FILE',self.file_name))
            # if user clicked record in no_keep_zone, then clicked off right after in no_keep_zone - rec_loop is now empty
            mLOG.log(f'Overdub End Recording in no keep zone: rec_loop len = {len(self)} ')
            self.record=False
            return True #indicates truncation has occured
        else:
            if self.record:  #only add zeroes if user was not in no_keep_zone AND Looper was recording samples at the time
                self.after_zeroes(multiplier*overdub_data['base_loop_length'])
            self.record=False
            return False

    def before_zeroes(self,how_many):
        """ cursor points to next sample to play, first recorded live sample must be stores at location cursor-1 in rec-Loop,
                so need to fill from location= 0 to location = cursor-2 with zeroes - which is cursor-1 number of zeroes 
                (This is why we pass cursor-1 to how_many)
        gives rec_loop last index = cursor-2, so extended sample will be at index cursor-1
        note: these zeroes are not mixed into the MixDownLoop - volume of MixDownLoop is unchanged
        """ 
        if how_many<=0: return False
        zero_sample = b'\x00'*AudioParam.SAMPLEWIDTH*AudioParam.SAMPLE_LENGTH    #creates a zero sample
        mLOG.log(f'inserting {how_many} zeroes before')
        self.extend([zero_sample]*(how_many))
        self.wav_send.send(('BEFORE_ZEROES',how_many))
        return True

    def after_zeroes(self,looplength):
        """
        looplength is the length of the longest loop - which could be the one we just recorded 
            if it was extended - eventhough it may not have gone to the end boundary,
            which is why we will fill it with zeroes
        add zero to self loop to extend to longest loop length (based on multiplier) 
        note: these zeroes are not mixed into the MixDownLoop - volume of MixDownLoop is unchanged
        """
        how_many = looplength - len(self)
        if how_many>0:
            mLOG.log(f'adding zeroes after: recLoop len = {len(self)} ; mixedLoop len = {looplength} ; diff = {how_many}')
            self.need_last_sample=len(self)  #index of where first zero will go - where last live sample needs to go eventually
            zero_sample = b'\x00'*AudioParam.SAMPLEWIDTH*AudioParam.SAMPLE_LENGTH    #creates a zero sample
            self.extend([zero_sample]*(how_many))
            self.wav_send.send(('AFTER_ZEROES',how_many))

    def on_record_no_keep_zone(self,loop_length,cursor):
        """identifies if user click record when nearing end of loop
        if so return True - user is in no_keep_zone: do not keep samples until new loop starts"""
        #looking near end of loop - mixed down loop has not been extended yet
        #current_postion when clicked is cursor-1 - cursor points to next sample to be played
        if cursor==0: 
            return True #user clicked at last sample which is in the no_keep_zone
        else:
            return cursor-1> (loop_length  - self.no_keep[1])

    def on_stop_no_keep_zone(self,cursor,multiplier,overdub_data):
        """ look if user clicked stop just past beginning of the loop - was aiming for end of loop
        If loop was extended during recording,  cursor_advanced will not haved loop back to zero,
            multiplier and loops.longest will have double (or quadrupled etc.) 
        cursor always points to next sample after playing the current mixed samples - so if user clicked stop:
            -user heard mixed samples at loop index = cursor-1
            -live_sample mixed in to what user heard is in location cursor-2 in rec loop 
            - next live_sample is what user played while hearing cursor-1 - will have to be stored when entering Looper class,
            unless user clicked early afterlooping - which is the no-keep-zone for ending recording.
        zero-position is the cursor value equivalent to 0 index of last added loop  (=0 if no added loop)
        (ex: base_loop_len = 5, extend twice: rec loop len = 15, origin of last base loop against rec loop is 10)
        current_position (last played sample)  is cursor-1. 
        delta indicates are far passed the zero-position cursor was when user clicked
        special case: user clicked on last sample being played:  
            if loop was extended (because looper was recording) then delta=0 and all is OK,
            and delta is less then no_keep_zone value and returns False as expected
            if loop was not extended (because looper was not recording - start was in no_keep_zone):
                then cursor_advance as looped cursor back to 0.  current_postion will be -1 which will
                evaluate at less than no_keep_zone when it fact it was not (yet) in no_keep zone
            This can be handled by testing for delta being 0 or positive before testing if in no_keep_zone
        """
        mLOG.log('Entering no_keep_zone method:')
        zero_position = overdub_data['base_loop_length']*(multiplier-overdub_data['previous_multiplier'])
        current_position = cursor-1
        delta = current_position-zero_position
        mLOG.log(f'current position= {current_position} ; zero-position= {zero_position} ; delta= {delta} ; '+
            f' previous mdloop= {overdub_data["previous_longest"]} ; current mdloop= {multiplier*overdub_data["base_loop_length"]} ; mult= {multiplier}')
        flag= (delta>=0) and (delta< self.no_keep[0])
        mLOG.log(f'no_keep_zone flag= {flag} ; cursor= {cursor}')
        return flag

    


    

class TimeInterval:
    """
    usage:
    tm = TimeInterval(10)
    in function before statement:
    tm.elapsed()  // resets the time
    ...statements ...
    tm.print_elapsed('message to print')  // this will print up to 10 times (as setup above in the class instantiation)
    """
    def __init__(self,max_count=1000,process=True):
        #max_count is the number of times print_elapsed will print to the console
        self.process=process
        self.started = self.get_time()
        self.counter =0
        self.max_count = max_count
        

    def get_time(self):
        if self.process:
            return time.perf_counter()
        else:
            return time.time()
    
    def elapsedstr(self):
        """
        returns elapsed time since instantiation or last reset in elapsed - in seconds
        but does NOT reset timer
        """
        s=f'elaspsed time is {(self.get_time()-self.started):.3f}'
        return s
    
    def elapsed(self,reset=True):
        """
        return a float in MILISECONDS with elapsed time since class instanciation
        or since last call to elapsed with rest =True (i.e it resets the time counter)
        only resets counter if reset = True - which is the default
        """
        x=self.get_time()-self.started
        if reset:
                self.started=self.get_time()
        return x*1000

    def print_elapsed(self,msg=''):
        self.counter+=1
        if self.counter<=self.max_count:
            mLOG.log(f'{msg} {self.elapsed()}')



#*************************************************************************************************

class Background(multiprocessing.Process):
    #overide init and run:
    #   init must call the class __init__ method
    #   overiding the method run - allows us to decide what RecWrite will do.
    #need to recrete behavior of RecLoop decisions on smples, zeroes etc. before writing file to disk.
    def __init__(self,wav_rec):
        multiprocessing.Process.__init__(self)
        self.daemon=True
        self.wav_rec=wav_rec 
        self.action=''
        self.data=None
        self.itv=TimeInterval()

    def construct_rec_loop(self):   
        if self.action == 'START_FILE':
            mLOG.log(f'start file received - data= {self.data}')
            self.loop=[]
            self.file_name=self.data
        elif self.action == 'DISCARD_FILE':
            mLOG.log(f'Discard file received - length= {len(self.loop)}')
            self.loop=[]
        elif self.action == 'END_FILE':
            mLOG.log(f'end file received - length= {len(self.loop)}')
            if len(self.loop)>0:
                self.write_wave()
            self.loop=[]
        elif (self.action == 'BEFORE_ZEROES') or (self.action == 'AFTER_ZEROES'):
            zero_sample = b'\x00'*AudioParam.SAMPLEWIDTH*AudioParam.SAMPLE_LENGTH    #creates a zero sample
            self.loop.extend([zero_sample]*(self.data))
        elif self.action == 'TRUNCATE':
            del self.loop[self.data:]
        elif self.action == 'INSERT_AT':
            index,live_sample=self.data
            self.loop[index]=live_sample
        else:
            self.loop.append(self.data)

    
    def write_wave(self):
        #open the file to store the wave file samples
        self.itv.elapsed()
        mLOG.log(f'starting file write  length= {len(self.loop)} ; filename= {self.file_name}',
                        identifier=self.__class__.__name__)
        self.wfout = wave.open(self.file_name, 'wb')
        self.wfout.setparams(AudioParam.params())
        #go into a loop to read data put in the queue by the record class
        self.wfout.writeframes(b''.join(list(self.loop)))
        self.wfout.close()
        mLOG.log(f'closed file write - duration= {self.itv.elapsed()} ms')

    def write_song_info(self):
        mLOG.log(f'info file write  length= {len(self.data)}',
                        identifier=self.__class__.__name__)
        fil=open(F_INFO.DATADIR+'/song_info.dat', 'wb')
        fil.write(self.data)
        fil.close()

    def run(self):
        mLOG.log(f' background pid {self.pid}')
        while 1:
            self.action,self.data = self.wav_rec.recv() #blocking
            self.itv.elapsed()
            if self.action == 'QUIT':
                mLOG.log('Background has received QUIT Code Word')
                break
            elif self.action == 'REMOVE':
                self.remove_wave(self.data)
            elif self.action == 'SONG_INFO':
                self.write_song_info()
            else:
                self.construct_rec_loop()

        mLOG.log('Background process has exited while loop',
                        level=mLOG.INFO,identifier=self.__class__.__name__)
        #leave to main process to close queue
        


# **********************************************************************************************

class GrabAudio(multiprocessing.Process):
    """  
    sound card is always grabbing samples and sending them down the pipe.  
    the only event it cares for is quit
    never need to send ENDtrans:  the play thread decides when to stop recording the samples into an array/loop
    """  

    def __init__(self,pipe_send_conn,quit_event):
        multiprocessing.Process.__init__(self)
        self.daemon=True
        self.samples = pipe_send_conn
        self.equit=quit_event

    def run(self):
        mLOG.log(f'grabaudio pid {self.pid}')
        p=alsaaudio.PCM(AudioParam.RECORD,  cardindex=1,channels=AudioParam.CHANNELS,
                    rate=AudioParam.RATE, format=AudioParam.FORMAT,periodsize=AudioParam.SAMPLE_LENGTH)
        time.sleep(0.1)
        while True:
            len,data = p.read()
            try:
                self.samples.send(data)  #warning this will block if pipe is full / ensure pipe is always read/purged
            except Exception:
                mLOG.log(f'Grab audio exception: {traceback.format_exc()}',
                        level=mLOG.CRITICAL,identifier=self.__class__.__name__)
                break
            if self.equit.is_set():
                mLOG.log('GrabAudio has received quit event')
                time.sleep(0.4)
                break
        p.close()
        mLOG.log('GrabdAudio is done',level=mLOG.INFO,identifier=self.__class__.__name__)
#**********************************************************************************************************
class Handlers:
    saved_song_name=''  #upon loading loops - if a saved name exists - this is set to it.
    timer_time=0
    all_song_names = []

    @staticmethod
    def send_track_count(val,outgoing_list):
        #this method is called upon initialisation always, and whenever track count changes
        #base recording, overdub, delete or restaure track
        outgoing_list.append(f'T{val}')

    @staticmethod
    def send_notification_message(val,outgoing_list):
        outgoing_list.append(f'M{val}')

    @staticmethod
    def send_current_song_name(outgoing_list):
        outgoing_list.append(f'C{Handlers.saved_song_name}')

    @staticmethod
    def send_volume_dict(loops,outgoing_list):
        #this is called when ios is initializing and has requested volumes
        #this sends only the volumes for live tracks - not for deleted tracks
        if len(loops.current_volumes)>0 and len(loops)>0:
            volumes_to_send= {k:v for k,v in loops.current_volumes.items() if k<len(loops)}
            volumes_to_send['notify'] = True  #only add this if sending all dict upon request
            mLOG.log(f'volumes to send {volumes_to_send}')
            outgoing_list.append(pickle.dumps(volumes_to_send))

    @staticmethod
    def send_volume_for_track(id,volume,outgoing_list):
        try:
            volumes_to_send = {id:volume}
            mLOG.log(f'one track volume to send {volumes_to_send}')
            outgoing_list.append(pickle.dumps(volumes_to_send))
        except:
            pass


    @staticmethod
    def volumes(volume_request_list,loops,out_list):
        """volume_request_list contains tupples of (track,volume) - both items must be int
        returns True if at least one track volume was handled - as a flag to force a song_info save/update"""
        flag=False
        while len(volume_request_list)>0:
            track,volume = volume_request_list.pop(0) #remove oldest first
            mLOG.log(f'handling volume track={track} ; volume={volume}')
            if volume>100: #this is a request to send all volume - not to adjust volume of track
                Handlers.send_volume_dict(loops,out_list)
            elif -1<= track <len(loops):
                if track >= 0:  #do not update a track if index is -1: it is for current samples volume only
                    loops[track].volume = volume
                loops.current_volumes[track] = volume
                flag = True
            elif  track == -3: #master playback - not stored in array
                playback = max(0,min(99,volume)) # ensure volume is between 0 and 99 no matter what was sent
                alsaaudio.Mixer('Speaker').setvolume(playback)
        return flag

    @staticmethod
    def controls(incoming_list,outgoing_list,loops):
        """this method only handles one control request at the time 
        it needs to be called again to handle the next request in the incoming list
        returns a tupple: (request_handled (boolean), type (string), request_success(boolean)) """
        if len(incoming_list)>0:
            code,payload = incoming_list.pop(0)
            mLOG.log(f"code  {code}")
            if code == 'S' or code == 'W':
                overwrite = True if code == 'W' else False
                success,msg= Handlers.save_song(payload.strip(),overwrite)
                if success:
                    Handlers.saved_song_name = msg
                    Handlers.save_song_info(loops,True)
                    Handlers.send_current_song_name(outgoing_list) # check if this is needed - used - by ios app
                    outgoing_list.append('OK') # check if this is needed - used - by ios app
                else:
                    if len(msg)>0:
                        outgoing_list.append(msg)
                mLOG.log(f"Saving to song: name= {msg} - Success={success}",level=mLOG.INFO)
                return (True,'Save', success)
            elif code == 'L':
                success,msg = Handlers.load_song(payload.strip())
                if success:
                    Handlers.saved_song_name = msg
                    Handlers.send_current_song_name(outgoing_list)
                    outgoing_list.append('OK')
                    #note: song_info already contains name of song was copied into data directory.
                else:
                    if len(msg)>0:
                        outgoing_list.append(msg)
                mLOG.log(f"Loading song: name= {msg} - Success={success}",level=mLOG.INFO)
                return (True,'Load',success)
            elif code == 'D':
                #delete does not send acknowledgements or eroor messages back to ios
                success = Handlers.delete_song_name_from_repo(payload.strip())
                if success and (Handlers.saved_song_name == payload.strip()):
                    Handlers.saved_song_name = ''
                    Handlers.send_current_song_name(outgoing_list)
                    Handlers.save_song_info(loops) #updates song_info.dat in data directory only with song_name = ''
                mLOG.log(f"Saving to song name {payload.strip()} - Success={success}",level=mLOG.INFO)
                return(True,payload.strip(),success) #returns the name of the deleted song for 'what'
            elif code == 'R': #requesting to send all song names
                mLOG.log(f"Ready to send all song names {Handlers.all_song_names}")
                outgoing_list.append(pickle.dumps(Handlers.all_song_names))
                mLOG.log(f"done  send all song names ")
                return(True,'Request',True)
        return (False,'',False)

    @staticmethod
    def check_name(val):
        """ returns True if check_name is valid: matches pattern and is not 0 lenght
        allowed characters:  letters 0-9 underscore  hyphen spaces only
        \w matches: a-z, A-Z, 0-9, including the _ (underscore) character.
        \s is whitespace"""
        if len(val) == 0:
            return False
        pattern = "^[\w\s-]+$"
        result = re.match(pattern,val)
        return result is not None

    @staticmethod
    def check_used(val):
        """ retuns True if name is  already used in repo
        """
        mLOG.log(f'checking song_name {val}')
        repos = glob(F_INFO.REPODIR+'/'+val+'0.wav')
        return len(repos) > 0

    @staticmethod
    def get_all_song_names():
        Handlers.all_song_names = []
        repos = glob(F_INFO.REPODIR+'/*0.wav')   #this will be buggy if track 10 exists
        #print(f'REPOIS= {repos}')
        #THIS WILL BE BUGGY:
        for song_name in repos:
            Handlers.all_song_names.append(os.path.basename(song_name)[:-5])
        Handlers.all_song_names.sort()
        mLOG.log(f'list of song names: {Handlers.all_song_names}')

    @staticmethod
    def delete_song_name_from_repo(val):
        success=True
        #get repofiles - note this returns only the filename - not the whole path: need to add /home/pi/repo/ when deleting etc.
        regexstr = f'{val}\d+.wav'
        repos = [f for f in os.listdir(F_INFO.REPODIR+'/') if re.match(regexstr, f)]
        #repos = glob('/home/pi/repo/'+val+'*.wav') - not used - returns all songs that starts with song name
        for filename in repos:
            try:
                remove(f'{F_INFO.REPODIR}/{filename}')
                mLOG.log(f'{F_INFO.REPODIR}/{filename}')
            except:
                sucess=False
        try:
            remove(f'{F_INFO.REPODIR}/{val}_info.dat')
            mLOG.log(f'deleting {val}_info.dat')
            #keep song name list up to date:
            if success and (val in Handlers.all_song_names):
                Handlers.all_song_names.remove(val)  # fails if name not in array
        except:
            success = False
        return success
        
        


    @staticmethod
    def save_song(requested_song_name,overwrite):
        if (not Handlers.check_name(requested_song_name)):
            return (False,'INVALID')
        elif (not overwrite) and (Handlers.check_used(requested_song_name)):
            return (False,'EXISTING')
        else:
            #get repofiles - note this returns only the filename - not the whole path: need to add /home/pi/repo/ when deleting etc.
            regexstr = f'{requested_song_name}\d+.wav'
            repos = [f for f in os.listdir(F_INFO.REPODIR+'/') if re.match(regexstr, f)] # these will be deleted or overwritten
            #repos = glob('/home/pi/repo/'+requested_song_name+'*.wav') not used since it gives all file that starts with song name 
            current_loops = glob(F_INFO.DATADIR+'/loop*[!deleted].wav') #matches all files that start with loop 
                                                                       #and don't have _deleted in the name
            mLOG.log(f'update copy find {len(repos)} in /repo and {len(current_loops)} in /data')
            if len(repos)>len(current_loops):
                    for filename in repos:
                        try:
                            remove(f'{F_INFO.REPODIR}/{filename}')
                            mLOG.log(f'deleting {F_INFO.REPODIR}/{filename}')
                        except:
                                pass
            for current_filename in current_loops: 
                #this copies only live tracks (not deleted, and not song_info.dat)
                try:
                    repo_filename=current_filename.replace(F_INFO.DATADIR+'/loop',F_INFO.REPODIR+'/'+requested_song_name)
                    copy(current_filename, repo_filename)  #overwrites if exists.
                    mLOG.log(f'copying {current_filename} to {repo_filename}')
                except:
                    mLOG('ecxeption while updating tracks copy to /repo for {requested_song_name}',level=mLOG.CRITICAL)
                    return(False,'')
            #make sure array of song names stays current:        
            if requested_song_name not in Handlers.all_song_names:
                Handlers.all_song_names.append(requested_song_name)
                Handlers.all_song_names.sort()
            return (True,requested_song_name)

    @staticmethod
    def save_song_info(loops,copy_to_repo = False):
        """this is only called by save song 
        it saves the latest volumes (which are correct anyway, 
        and the saved song name into the song.dat of the looper data directory 
        and then it copies this into the repo directory under the song name.
        Note: when volume changes - the updating to song.dat in the data directory is handles by a method in the 
        Looper class."""
        song_info = (Handlers.saved_song_name, loops.current_volumes)
        mLOG.log(f"construct song_info to save to data dir: {song_info}")
        try:
            fil = open(F_INFO.DATADIR+'/song_info.dat', 'wb')
            pickle.dump(song_info,fil)
            fil.close()
            mLOG.log('writing song info  to /data directory')
        except:
                mLOG.log(traceback.format_exc(),level=mLOG.CRITICAL)
                pass
        try:
            if copy_to_repo:
                copy(F_INFO.DATADIR+'/song_info.dat', f'{F_INFO.REPODIR}/{Handlers.saved_song_name}_info.dat')  #overwrites if exists.
                mLOG.log(f'copy song info to {Handlers.saved_song_name}_info.dat in /repo directory')
        except:
                pass


    def load_song(val):
        # check if requested song exists - return NOT_EXISTS if it does not
        mLOG.log(f'checking if load song name exists {val}')
        if not Handlers.check_used(val):
            return (False,'NOT_EXISTS')
        #remove files from data directory
        data_files = glob(F_INFO.DATADIR+'/loop*.wav')
        for filename in data_files:
            remove(filename)
        try:
            remove(F_INFO.DATADIR+'/song_info.dat')
        except:
            pass
        #load new song into /data - if we get here song exists
        regexstr = f'{val}\d+.wav'
        repos = [f for f in os.listdir(F_INFO.REPODIR+'/') if re.match(regexstr, f)]
        for repo_file in repos:
            filename=repo_file.replace(val,F_INFO.DATADIR+'/loop')
            copy(f'{F_INFO.REPODIR}/{repo_file}', filename)  #overwrites if exists.
            mLOG.log(f'loading song - copying {F_INFO.REPODIR}/{repo_file} to {filename}')
        try:
            copy(f'{F_INFO.REPODIR}/{val}_info.dat', F_INFO.DATADIR+'/song_info.dat')
            mLOG.log(f'loading song - copying {val}_info.dat to song_info.dat on /data')
        except:
            return(False,'FAILED_LOAD')
        return (True,val)
        
    @staticmethod
    def timer(start=False):
        #returns True if timer is running 
        if not start:
            if Handlers.timer_time == 0:
                return False
            elif time.perf_counter()-Handlers.timer_time > 3:  #hard wired 3 seconds delay
                Handlers.timer_time = 0
                return False
            else:
                return True # timer is going and less than 3 seconds
        else:
            Handlers.timer_time = time.perf_counter()
            return True



#**********************************************************************************************************
class Looper:
    """
    this is the main process class.
    its function is to receive recorded frames and play them in a loop
    and to keep each loop/dub into memeory and play them in a loop when required.

    loop: a loop is either the base loop or any dub made afterwards.
    loop is an array of audioparam SAMPLES - which contains chunck of frames 
    Chunck correspond to period size in alsaaudio PCM object
    loops: is an array that contain the base loop (always at index 0) and 
    all overdubs loop made afterwards
    (note: loops is not strictly necessary - it is only a holder of all loops in memory 
    in case we want to do something with them individually later):
    currentloop contains the loop currently recording  - which needs to be mixed - in during recording. 
    After recording it becomes the newest member of loops (nth number) - and play mixes that down to 
    the mixed loop (if it's confirmed that the currentloop (recorded) is good and to be kept,)
    mergedloop is the mix of all loops (imcluding the current loop dub) 
    this uses a pipe instead of a queue to play samples that have been recorded via pcm capture stream

    """

    def __init__(self):
        """
        states are defined as: 
        list of states: 0:"idle"  1: "play_loop"  2:"overdub"  3:"base_recording  4:"quit"
        idle: this is the state where loop is not playing - just pass grabbed framses to play output
            may not be necessary to actually play them if analof op-amp mixes input and Rpi output...
        base_recording:  when there are no loops and recording first base_loop
        play_loop: looper is playing mixed_down loop (and mixing in live input (if no op-map analog mixer)
        overdub: when at least one loop exists and we are recording over it.
        quit:  quitting the program
        self.states is a tupple of the functions that implement each state behavior - call the function as self.states[index]()
        """

        self.samples,self.sampSend=multiprocessing.Pipe(False)
        self.wav_rec,self.wav_send=multiprocessing.Pipe(False)
        self.flash_rec,self.flash_send=multiprocessing.Pipe(False)
        self.equit= multiprocessing.Event()

        self.states=[self.idle,self.play_loop,self.overdub,self.base_recording,self.quit]

        self.user_output = rgb_segment.LED()
        self.mgr = StateMgr()

        self.loops=None  # will become Loops class - array of loops recorded so far index=0 is base loop
        #instantiate Loops class and load loops that are in the physical Looper
        self.initialize()
        
        self.pcm=alsaaudio.PCM(AudioParam.PLAY,  channels=AudioParam.CHANNELS,
                rate=AudioParam.RATE, format=AudioParam.FORMAT,periodsize=AudioParam.SAMPLE_LENGTH, )


    def initialize(self):
        self.loops=Loops()  # array of loops recorded so far index=0 is base loop
        self.loops.load_saved_loops()
        Handlers.send_current_song_name(self.mgr.outgoing_msg)
        Handlers.send_track_count(len(self.loops),self.mgr.outgoing_msg)
        self.has_tracks = len(self.loops)>0
        #Handlers.send_volume_dict(self.loops,self.mgr.outgoing_msg)
        self.volume_change = True #will force current name/volumes to be written upon start
                                          # based on current loop content - or create info file if it does not exists
        Handlers.get_all_song_names() # load song name array ready to be sent to ios app when requested
        Handlers.send_notification_message('Initialized',self.mgr.outgoing_msg)
    
    def get_next_sample(self):
        #note: this always purges extra samples 
        if self.samples.poll(2):  #check pipe conn for samples - blocks until data in pipe or  time out of 2 seconds
            try:
                data = self.samples.recv()
                if self.samples.poll():
                    purge_count = self.purge_sample_pipe()
                    if purge_count<5:
                        mLOG.log(f'While getting next sample - purged {purge_count} samples')
                    else:
                        mLOG.log(f'While getting next sample - purged {purge_count} samples',level=mLOG.INFO)
                return data
            except EOFError:
                #pipe was closed at the other end - normally after a quit event
                if self.equit.is_set():
                    pass
                else:
                    mLOG.log('GrabAudio has closed the pipe - need to reset..',
                        level=mLOG.CRITICAL,identifier=self.__class__.__name__)
                    #create an event that request main to reset GrabAudio (meanwhile it should play nothing - maybe a "reset" state?)
                return b'\x00'*AudioParam.SAMPLEWIDTH*AudioParam.SAMPLE_LENGTH
        else:  # 
                mLOG.log('no data samples coming after poll waited 2 seconds',
                        level=mLOG.CRITICAL,identifier=self.__class__.__name__)
                return b'\x00'*AudioParam.SAMPLEWIDTH*AudioParam.SAMPLE_LENGTH
    
    def delete_or_add_last(self,delete=True):
        if delete:
            index =self.loops.delete_track()
            Handlers.send_track_count(len(self.loops),self.mgr.outgoing_msg)
        else:
            index = self.loops.restaure_tracks()
            #send volume first so we know it is ready to be read by ios when ios get track ccount notification
            Handlers.send_volume_for_track(len(self.loops)-1,self.loops[-1].volume,self.mgr.outgoing_msg)
            Handlers.send_track_count(len(self.loops),self.mgr.outgoing_msg)
            

        self.has_tracks = len(self.loops)>0
        #self.flash_send.send(('tracks',self.loops.longest))
        if len(self.loops) == 0:
            self.has_tracks = False
        self.user_output.has_tracks(self.has_tracks)
        Status.track_count = len(self.loops)  # send track count to bluetooth service

    def update_song_info(self):
        """song_info is a tupple :
            - song_name if created - empty string if not
            - dictionary of volumes {int,int} - where track number (index in loops) is key,and volume is value
        Note: to avoid pipe conflicts with rec - only call this when in idle"""
        song_info = (Handlers.saved_song_name, self.loops.current_volumes)
        pickled_song_info = pickle.dumps(song_info)
        self.wav_send.send( ('SONG_INFO',pickled_song_info) )
        self.volume_change=False
        Handlers.timer(True) # start timer to give time to background to write to song_dat.info 
                            # and prevent a song_save operation to do the same on the same file

    def display_tracks_num(self,flash=False):
        if flash:
            self.flash_send.send(len(self.loops))
            #note: this flashes the display with the number of tracks - including zero tracks
        else:
            if len(self.loops)>0:
                self.flash_send.send( ('tracks',len(self.loops)) )
                #this display a solid digit euqal to the number of loops - no flashing
            else:
                self.flash_send.send( ('tracks',-1) )
                #self.flash_send.send( ('OFF',0) )
                #this means display is off when zero track - need to confirm we want this behavior?
        self.user_output.has_tracks(self.has_tracks)

    def purge_sample_pipe(self):
        nc=0
        while self.samples.poll():
            self.samples.recv() 
            nc+=1   
        return nc    

        
    def idle(self):  #just play tru grabbed samples
        """  
        this just plays out what GrabAudio is putting out.  
        consider putting in a noise gate (if less than a certain volume - output b'\x00\x00')
        """
        mLOG.log('entering idle mode',level=mLOG.INFO)
        #self.user_output.looper_play(False)
        self.user_output.looper_rec(False)
        self.display_tracks_num(flash = (self.mgr.run_button.value == 1))
        self.user_output.edit_mode(self.mgr.run_button.value == 1)  # indicate looper is in edit mode
        self.loops.reset_cursor()

        keep_idling = True
        while keep_idling:
            live_sample=self.get_next_sample()      
            self.pcm.write(live_sample)
            keep_idling=self.mgr.manage(len(self.loops)>0)
            if keep_idling: #manager has not asked for a change of state
                #do controls first
                # saving song won't occur while song_info data is being updated. - 
                # timer waits if we came to edit mode from play_loop (which is from overdub/or base recording)
                timer_flag = False
                if self.mgr.run_button.value == 1:
                    if (not Handlers.timer()) and self.mgr._previous_state == self.mgr.PLAY_LOOP:
                        timer_flag = Handlers.timer(True) # start the timer and go back to idling
                    else: 
                        timer_flag = Handlers.timer()
                if not timer_flag: #assuming no timer was set or timer has run 3 seconds - check controls
                    handled,what,success = Handlers.controls(self.mgr.incoming_controls,
                                                        self.mgr.outgoing_msg,
                                                        self.loops)
                    if handled and success and (what == 'Load'):
                        self.initialize()
                        keep_idling=False
                #song_info_is latched if True until it is reset when writing song info
                self.volume_change=Handlers.volumes(self.mgr.incoming_volumes,self.loops,self.mgr.outgoing_msg) or self.volume_change
                if self.volume_change:
                    self.update_song_info()

        if self.mgr.action_requested == self.mgr.NOACTION:
            return True
        elif self.mgr.action_requested == self.mgr.DELETE_LAST:
            self.delete_or_add_last(delete=True)
        elif self.mgr.action_requested == self.mgr.REINSTATE_LAST:
            self.delete_or_add_last(delete=False)
            
        return True #every state function returns True unless it is the quit function

    def play_loop(self):
        """
        plays the mixed down loops available and the grabbed frames coming in
        ToDo: need to implement a noise gate on grabbed Frames to remove noise when user not playing.
        mixed_down_loop is always an integer multiple of the length of the base_loop
        if frame "n" was being grabbed when recording stops or idle start event occured - frame "n" will have been put in play_pcm stream
        before checking events and changing state to play_loop.  So when loop start, wait ofr the next grabbed frame "n+1"
        and mix it with loop[0] then send to play_pcm stream
        """
        self.user_output.looper_rec(False)
        #self.user_output.looper_play(True)
        self.user_output.edit_mode(False)
        self.user_output.loop_reset(self.loops.longest)
        self.user_output.has_tracks(self.has_tracks)
        zero_order=[0,2]  # for def mixin_zeroes - order of mixing zeroes: [0,2]=begining, end 
        
        # check if coming from overdub and need to record mix down of last sample (being played while we get here)
        try:
            if self.loops[-1].need_last_sample>-1:
                mLOG.log(f'entering play_loop and recording last sample= {self.loops.cursor} ; last sample position= {self.loops[-1].need_last_sample}')
                live_sample = self.get_next_sample()
                self.loops[-1].store_last_sample(live_sample)
                mixed=self.loops.mixdownsample(live_sample)
                self.pcm.write(mixed)
                self.loops.cursor_advance()
                if self.mgr.action_requested==self.mgr.ON_PLAY_GO_IDLE:
                    self.mgr.state = self.mgr.IDLE
                    return True
                elif not self.mgr.manage():
                    self.user_output.loop_reset(self.loops.longest)
                    return True
        except:
            pass # error if loop was a loaded loop from file (type=Loop) instead of RecLoop recorded in this session
                 # because Loop does not have store.need_last_sample attribute

        keep_playing=True
        mLOG.log(f'entering play_loop at cursor= {self.loops.cursor} ; mdloop len= {self.loops.longest}',level=mLOG.INFO)
        while keep_playing:
            live_sample = self.get_next_sample()
            mixed=self.loops.mixdownsample(live_sample)
            self.pcm.write(mixed)
            self.loops.cursor_advance()
            self.user_output.loop(self.loops.cursor)
            self.volume_change=Handlers.volumes(self.mgr.incoming_volumes,self.loops,self.mgr.outgoing_msg) or self.volume_change
            """if self.zeroes_to_clear:
                time_remaining = 5.8-itv.elapsed()-1 # the 1 is a 1 ms buffer to handle the rest of while loop upon return
                self.zeroes_to_clear=self.mixed_down_loop.mixin_zeroes(time_remaining,zero_order)
                mLOG.log(f'doing zeroes - cursor at {self.mixed_down_loop.cursor}')
            """
            if not self.mgr.manage():
                keep_playing=False 
        self.user_output.loop_reset(self.loops.longest)
        return True 
            
    def base_recording(self):
        mLOG.log('entering base loop recording',level=mLOG.INFO)
        #self.user_output.looper_play(False)
        self.user_output.edit_mode(False)
        self.user_output.looper_rec(True)
        self.user_output.has_tracks(self.has_tracks)
        
        rec_loop=RecLoop(self.wav_send)
        keep_recording = True
        while keep_recording:
            live_sample = self.get_next_sample()
            self.pcm.write(live_sample)
            rec_loop.baseloop_sample(live_sample)
            self.volume_change=Handlers.volumes(self.mgr.incoming_volumes,self.loops,self.mgr.outgoing_msg) or self.volume_change
            keep_recording=self.mgr.manage()  #returns False if state is changing due to user input (i.e. event)

        mLOG.log(f'leaving base loop recording with # of samples= {len(rec_loop)}')
        rec_loop.end_record()
        
        if len(rec_loop)>0:
            self.loops.add_loop(rec_loop)
            self.user_output.loop_reset(len(rec_loop))
            Handlers.send_volume_for_track(len(self.loops)-1,self.loops[-1].volume,self.mgr.outgoing_msg)
            Handlers.send_track_count(len(self.loops),self.mgr.outgoing_msg)
            self.has_tracks=True
            self.volume_change= True  # to capture volume of new track from volumes dict
        return True
        
    def quit(self):
        mLOG.log('entering Looper class quit routine',level=mLOG.INFO)
        self.purge_sample_pipe()  # if quiting with button (3 sec wait) / pipe will have filled up and GrabAudio is blocked on send
        self.equit.set()
        self.wav_send.send(('QUIT',0))
        self.flash_send.send('QUIT')
        self.mgr.LPsend.send('QUIT')
        
        time.sleep(1) # give times to sample in pcm stream to finish playing
        self.pcm.close()
        #self.loops.save(all=True)
        try:
            self.purge_sample_pipe() 
            self.samples.close()
            self.sampSend.close()
        except:
            pass
        try:
            while self.mgr.fromBTrec.poll():
                self.mgr.fromBTrec.recv()
            self.mgr.fromBTrec.close()
            self.mgr.BTsend.close()
            self.mgr.LPsend.close()
            self.mgr.fromLPrec.close()
        except:
            pass
        
        try:
            while self.wav_rec.poll():
                self.wav_rec.recv()
            self.wav_rec.close()
            self.wav_send.close()
        except:
            pass

        try:
            while self.flash_rec.poll():
                self.flash_rec.recv()
            self.flash_rec.close()
            self.flash_send.close()
        except:
            pass
        
        self.user_output.close_it()
        self.mgr.close_it()
        mLOG.log(' Looper class leaving quit routine',level=mLOG.INFO)
        return False

    

    def overdub(self):
        #note: self.cursor is pointing at the next sample from mixed_down_loop that will be played
        #can only arrive here from play - which will have set cursor at least = 1 before exiting (reacting to event)
        #self.user_output.looper_play(False)
        self.user_output.edit_mode(False)
        self.user_output.looper_rec(True)
        self.user_output.has_tracks(self.has_tracks)
        keep_going = True
        loop_length=self.loops.longest #upon entry (this may change)
        self.loops.setup_overdub()
        mLOG.log(f'entering overdub at cursor= {self.loops.cursor} ; loop length = {loop_length}',
                        level=mLOG.INFO,identifier=self.__class__.__name__)
        rec_loop=RecLoop(self.wav_send,loop_length,self.loops.cursor,len(self.loops))  #this runs set-up and fills with zeroes if needed
        record_samples_flag=False
        self.user_output.loop_reset(loop_length)
        
        multiplier_on_entry=self.loops.multiplier
        while keep_going:
            live_sample = self.get_next_sample() # this sample corresponds to cursor-1
            record_samples_flag= rec_loop.overdub_sample(live_sample,self.loops.cursor) #cursor points to (last mixed sample heard by user)+1
            mixed = self.loops.mixdownsample(live_sample)
            self.pcm.write(mixed)  
            self.loops.cursor_advance(record_samples_flag)
            #in case multiplier has been increase by user recording into second loop:
            #this resets cursor location to within origianl longest loop when overdub was entered
            self.user_output.loop(self.loops.cursor-(self.loops.multiplier-multiplier_on_entry)*self.loops.base_loop_length)
            self.volume_change=Handlers.volumes(self.mgr.incoming_volumes,self.loops,self.mgr.outgoing_msg) or self.volume_change
            if not self.mgr.manage():
                keep_going=False
                if self.mgr.action_requested==self.mgr.DISCARD_RECORDING:
                    rec_loop.end_record(discard=True)
                else:
                    truncate_mdloop=rec_loop.end_record(self.loops.cursor,self.loops.multiplier,self.loops.overdub_data) #if True, rec_loop is already truncated
                    if len(rec_loop)>0:
                        rec_loop.volume = self.loops.current_volumes[-1]
                        self.loops.add_loop(rec_loop)
                        Handlers.send_volume_for_track(len(self.loops)-1,self.loops[-1].volume,self.mgr.outgoing_msg)
                        Handlers.send_track_count(len(self.loops),self.mgr.outgoing_msg)
                        self.volume_change= True
                        mLOG.log(f'keeping overdub - mixed_down length= {self.loops.longest} ; length rec= {len(rec_loop)}',
                                level=mLOG.INFO,identifier=self.__class__.__name__)
                """ 
                At this point we may have multiple length of the inital base loop in mixed_down_loop 
                and the newly added rec_loop in self.loops matches this length as well.
                while all the loops before this one are of length = to intial base loop
                (unless they were increased in a previous overdub)
                Need to keep track of this if this rec loop is kept to increase the size of the previous loops 
                and store them for future retrieval.  (or store initital loops and a multiplier)
                ToDo: handle in UNDO function
                """ 
        self.user_output.loop_reset(self.loops.longest)
        mLOG.log(f'exiting overdub - mixed_down length= {self.loops.longest} ; length rec= {len(rec_loop)}',
                                 identifier=self.__class__.__name__)
        return True


    
    
                 

    def run(self):
        """list of states: 0:"idle"  1: "play_loop"  2:"overdub"  3:"base_recording  4:"quit"
        - The list "self.states" contains the methods of the Looper  class: idle, play_loop, overdub and quit
        - The variable "self.state" contains the index of the method we wish to run next which is set
                in each of the above methods by calling StateMgr class which handles button presses by the user.
                if a change of state is required, the current state's method sets the requested new state in self.state and exits returning True
                which makes the while loop call the next state's method
        """
        x=True
        while x:
            x=self.states[self.mgr.state]()

        mLOG.log('Looper class has left the while loop',
                        level=mLOG.INFO,identifier=self.__class__.__name__)

        
 
#********************************************************************************************************


def main():
    #mLOG.current_level=mLOG.INFO
    mLOG.current_level=mLOG.DEV
    mLOG.log_filename = "/home/pi/loop/looperLog.log"
    #comment this line for production:
    mLOG.print_to_console = True

    mLOG.log('****************** Starting Looper **************',level=mLOG.INFO)
    #set directory info:
    # this yields absolutepath of the python file looper4.py 
    main_dir = os.path.dirname(sys.argv[0])
    mLOG.log(f'computed main dir= {main_dir}',level=mLOG.INFO)
    F_INFO.DATADIR = main_dir+F_INFO.DATADIR
    mLOG.log(f'computed data dir= {F_INFO.DATADIR}')
    F_INFO.REPODIR = main_dir+F_INFO.REPODIR
    F_INFO.PREFIX = main_dir+F_INFO.PREFIX
    
    play=Looper()
    try:
        os.system("sudo systemctl stop segment.service")
    except:
        mLOG.log(traceback.format_exc(),level=mLOG.CRITICAL)

    flasher= rgb_segment.Flash(play.flash_rec)
    flasher.start()
    play.flash_send.send(-1)
    
    """
    internal bluetooth pipes:
    from Looper class - Statemgr:
        Looper class.StateMgr sends through LPsend --> bt_svc receives through fromLPrec
        bt_svc send through BTsend --> Looper class.StateMgr receives through fromBTrec
    """
    btcomm = bt_svc.Bt_Svc(play.mgr.fromLPrec,play.mgr.BTsend)
    btcomm.start()
    time.sleep(1)

    grab=GrabAudio(play.sampSend,play.equit)
    background=Background(play.wav_rec)
    background.start()
    grab.start()
    play.run()
    mLOG.log('waiting a little while to ensure all subprocesses terminate gracefully...')
    time.sleep(1)
 

    background.join()  #no need to join because daemon=True
    grab.join()
    btcomm.join()
    mLOG.log('joins are done - cleaning up GPIO\n',level=mLOG.INFO)
    GPIO.cleanup()
    if  not play.mgr.graceful_quit_requested:
        os.system("sudo shutdown -h now")





    





if __name__ == "__main__":
    main()

