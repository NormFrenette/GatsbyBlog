import multiprocessing
import alsaaudio
import wave
import audioop
import time
import RPi.GPIO as GPIO
import sys
from my_logger.my_logger import mLOG
from looperui import User_Input,User_Output
import traceback
import os
import pickle
import bt_svc 
from os import path, rename, remove
from shutil import copy
from glob import glob
import re
import configparser


class F_INFO():
    '''directories and needed files - must be updated with location of looper4.py script'''

    DATADIR = '/data'
    REPODIR = '/repo'
    PREFIX = '/data/loop'
    INI_FILE = '/looper.ini'

class ConfigData:
    '''reads the .ini file and stores the resulting map (dict) for later use.
    Note: config_map is a ConfigParser object that behaves/accesses like a directory 
    but is still not a pure directory - per python docs - no effects on code used here though.'''
    
    def __init__(self,file_name):
        #GPIO data - defaults to manual wiring (looper will start but may be unusable if .ini errors)
        self.config_map = {}
        self.file_name = file_name
        self.initialize()

    def initialize(self):
        self.config_map = configparser.ConfigParser()
        try:
            self.config_map.read(self.file_name)  # file is located in same directory as looper4.py
        except Exception as e:
            mLOG.log(f'Exception Reading .ini file: {e} - config_map remains empty',level=mLOG.CRITICAL,
                     identifier=self.__class__.__name__)

# *************************************************************************   



# **********************************************************************************************

class Tracks_Diskwriter(multiprocessing.Process):
    #overide init and run:
    #   init must call the class __init__ method
    #   overiding the method run - allows us to decide what RecWrite will do.
    #need to recrete behavior of RecLoop decisions on smples, zeroes etc. before writing file to disk.
    def __init__(self):
        multiprocessing.Process.__init__(self)
        self.action=''
        self.data=None
        self.itv=TimeInterval()
        self.dispatch = bt_svc.Msg_Dispatch('working_dir')
        self.wav_rec = self.dispatch.get_pipe_rec('working_dir')

    def send_data(self,data):
        self.dispatch.send_msg(data,'working_dir')

    def construct_rec_loop(self):   
        if self.action == 'START_FILE':
            mLOG.log(f'start file received - data= {self.data}')
            self.loop=[]
            self.file_name=self.data
        elif self.action == 'DISCARD_FILE':
            mLOG.log(f'Discard file received - length= {len(self.loop)}')
            self.loop=[]
        elif self.action == 'END_FILE':
            mLOG.log(f'end file received - length= {len(self.loop)}')
            if len(self.loop)>0:
                self.write_wave()
            self.loop=[]
        elif (self.action == 'BEFORE_ZEROES') or (self.action == 'AFTER_ZEROES'):
            zero_sample = b'\x00'*AudioParam.SAMPLEWIDTH*AudioParam.SAMPLE_LENGTH    #creates a zero sample
            self.loop.extend([zero_sample]*(self.data))
        elif self.action == 'TRUNCATE':
            del self.loop[self.data:]
        elif self.action == 'INSERT_AT':
            index,live_sample=self.data
            self.loop[index]=live_sample
        else:
            self.loop.append(self.data)

    
    def write_wave(self):
        #open the file to store the wave file samples
        self.itv.elapsed()
        mLOG.log(f'starting file write  length= {len(self.loop)} ; filename= {self.file_name}',
                        identifier=self.__class__.__name__)
        self.wfout = wave.open(self.file_name, 'wb')
        self.wfout.setparams(AudioParam.params())
        #go into a loop to read data put in the queue by the record class
        self.wfout.writeframes(b''.join(list(self.loop)))
        self.wfout.close()
        mLOG.log(f'closed file write - duration= {self.itv.elapsed()} ms')

    def write_song_info(self):
        mLOG.log(f'info file write  length= {len(self.data)}',
                        identifier=self.__class__.__name__)
        fil=open(F_INFO.DATADIR+'/song_info.dat', 'wb')
        fil.write(self.data)
        fil.close()

    def run(self):
        mLOG.log(f' Tracks_Diskwriter pid {self.pid}')
        while 1:
            self.action,self.data = self.wav_rec.recv() #blocking
            self.itv.elapsed()
            if self.action == 'QUIT':
                while self.wav_rec.poll():
                    discard = self.wav_rec.recv()
                mLOG.log('Background has received QUIT Code Word')
                break
            #elif self.action == 'REMOVE': # this code is not used.
                #self.remove_wave(self.data)
            elif self.action == 'SONG_INFO':
                self.write_song_info()
            else:
                self.construct_rec_loop()

        mLOG.log('Background process is closing pipes',
                        level=mLOG.INFO,identifier=self.__class__.__name__)
        self.dispatch.close_all_pipes()
        mLOG.log('Background process has exited while loop',
                        level=mLOG.INFO,identifier=self.__class__.__name__)
        #leave to main process to close queue
        
# **********************************************************************************************


class Grab_Audio(multiprocessing.Process):
    """  
    sound card is always grabbing samples and sending them down the pipe.  
    the only event it cares for is quit
    never need to send ENDtrans:  the play thread decides when to stop recording the samples into an array/loop
    """  

    def __init__(self,quit_event):
        multiprocessing.Process.__init__(self)
        #self.samples_rec,self.samples_send=multiprocessing.Pipe(False)
        self.equit=quit_event
        self.dispatch =  bt_svc.Msg_Dispatch('samples')
        self.samples_rec = self.dispatch.get_pipe_rec('samples')  #the receiving end of the pipe named "samples"
        

    def get_next_sample(self):
        ''' This gets the next sample fron Grab Audio pipe - blocking until it arrives
            After getting the sample - it always checks if there are more samples.
            Normally there should not be since the Looper is built to manage every samples within 5.8ms.
            However, especially when idle, data storage for song names etc. means that more than 5.8ms passes 
            and samples accumulate in the pipe.  In this case they are discarded (play through will skip).
            This should never happen in play or record states - but the event is logged so it can be analysed 
            if it does (user would hear skipping when recording...)
            Errors:  exceptions are caught - so as not to crash the program.  a zero samples is returned in this case
            TODO:  flag the problem to user - or automatically reset Looper (and Grab Audio - which may have closed pipe...)
        '''
        #polls blocks until someting is in the pipe (returns True) or timeout = 2seconds (returns False)- which ever is less
        if self.samples_rec.poll(2):  #check pipe conn for samples - blocks until data in pipe or  time out of 2 seconds
            try:
                data = self.samples_rec.recv()
                # check if there are more samples in the pipe - if so discard them 
                if self.samples_rec.poll():
                    purge_count = self.purge_sample_pipe()
                    if purge_count<5: #this line only in DEV debug mode.
                        mLOG.log(f'While getting next sample - purged {purge_count} samples')
                    else:
                        mLOG.log(f'While getting next sample - purged {purge_count} samples',level=mLOG.INFO)
                return data
                # this error is rare: Grab Audio would have to close the pipe after being poll while doing the .recv
            except EOFError:
                mLOG.log('Grab_Audio has closed the pipe - need to reset..',
                        level=mLOG.CRITICAL,identifier=self.__class__.__name__)
                return b'\x00'*AudioParam.SAMPLEWIDTH*AudioParam.SAMPLE_LENGTH
        else:  # timeout was hit - no data for 2 seconds
                mLOG.log('no data samples coming after poll waited 2 seconds',
                        level=mLOG.CRITICAL,identifier=self.__class__.__name__)
                return b'\x00'*AudioParam.SAMPLEWIDTH*AudioParam.SAMPLE_LENGTH

    def purge_sample_pipe(self):
        nc=0
        try:
            while self.samples_rec.poll():
                self.samples_rec.recv() 
                nc+=1  
        except:
            pass 
        return nc 


    def run(self):
        mLOG.log(f'grab_audio pid {self.pid}')
        soundcard_mic_stream=alsaaudio.PCM(AudioParam.RECORD,  cardindex=1,channels=AudioParam.CHANNELS,
                    rate=AudioParam.RATE, format=AudioParam.FORMAT,periodsize=AudioParam.SAMPLE_LENGTH)
        time.sleep(0.1)
        while True:
            len,data = soundcard_mic_stream.read()
            try:
                self.dispatch.send_msg(data,'samples')  #warning this will block if pipe is full / ensure pipe is always read/purged
            except Exception:
                mLOG.log(f'Grab audio exception: {traceback.format_exc()}',
                        level=mLOG.CRITICAL,identifier=self.__class__.__name__)
                break
            if self.equit.is_set():
                mLOG.log('Grab_Audio has received quit event')
                time.sleep(0.4)
                break
        mLOG.log('Grabd_Audio is closing things down',level=mLOG.INFO,identifier=self.__class__.__name__)
        soundcard_mic_stream.close()
        self.dispatch.close_all_pipes()
        mLOG.log('Grabd_Audio is done',level=mLOG.INFO,identifier=self.__class__.__name__)
#**********************************************************************************************************
class Position:

    def __init__(self):
        self.cursor = 0
        self.start_no_keep = False
        self.end_no_keep = True
        self.starting_point_for_no_keep = 0
        self.base_loop_length = 0
        self.longest = 0 # always contain the length of longest loop in Loops
        self.multiplier = 1
        self.overdub_data={'previous_multiplier':self.multiplier,
                            'previous_longest': self.longest,
                            'base_loop_length': self.base_loop_length}

    def zero_cursor(self):
        self.cursor = 0
        self.starting_point_for_no_keep = 0
        self.start_no_keep = False
        self.end_no_keep = True


    def cursor_for_shorter_loops(self,loop_length):
        '''returns the index of the sample corresponding to the cursor,
        when the targetted loop has a length less then the longest loop.
        In this case cursor > loop_length - and it can't be used directly has an index.'''
        #if cursor is greater then length of loop - need to remove multiple of loop_length to reset cursor in correct range
        #// returns integer part of the division result
        if self.cursor >= loop_length:
            x=self.cursor - (self.cursor//loop_length)*loop_length
            return x
        else:
            return self.cursor

    def update_lengths(self,loops):
        '''call this when adding or removing loops
        note: this will fail if any loop in loops is zero-length 
            -> perform integrity check before running looper.
        '''
        self.base_loop_length = 0
        self.longest = 0 # always contain the length of longest loop in Loops
        self.multiplier = 1
        if len(loops)>0:
            max_length = 0
            min_length = sys.maxsize
            for loop in loops:
                max_length = max(max_length,len(loop))
                min_length  = min(min_length,len(loop))

            if min_length>0 and max_length > 0:
                self.base_loop_length = min_length
                self.longest = max_length
                self.multiplier = max_length//self.base_loop_length  

            

    def setup_overdub(self):
        self.overdub_data={'previous_multiplier':self.multiplier,
                            'previous_longest': self.longest,
                            'base_loop_length': self.base_loop_length}

    def advance(self,is_recording=False):
        '''end_no_keep zone is at the beggining of the loop  = 0 -> end_no_keep number, 
            unless loop was extended zone = N -> N+end_no_keep number.
            we have to wait for cursor to advance - to see what happens.   
            Since, advance is always called after a sample has been sent to looper headphone: 
                If user clicks, user is currently hearing cursor-1.  
                This means if user clicks when advanced cursor here = 0 (or N), then user is still on last sample of the loop 
                    and therefore is not in the no_keep zone yet. 
            So for this method,end_no_keep Zone starts at 1 (or N+1) and ends at 1+end_no_keep number,
                and it is check after cursor has advanced
        start_no_keep_zone is at the end of the loop:  a similar problem would exist: 
            if user clicks exactly when cursor here says = 0: user is still on last sample which is in fact in no_keep zone.
                The best way to deal with this is check the start_no_keep zone before advancing the cursor.
                It is not necessary to wait see if loop will be extended because if loop is extended,
                it means we are already recording - at which point the start_no_keep zone does not have to be correct,
                (i.e it can keep being based on the previous loop length) - since it will not be used.  
                When user ends recording, the loops length will be updated and start_no_keep_zone will be correct again.'''
        self.start_no_keep = self.cursor > (self.longest - AudioParam.START_NO_KEEP)
        self.cursor+=1
        if self.cursor >= self.longest:
            if is_recording:
                mLOG.log('ready to extend while recording:\n\r'+
                            f'cursor= {self.cursor} ; length= {self.longest} ; multiplier= {self.multiplier}')
                self.add_one()  
                mLOG.log(f'loop was extended - new length= {self.longest} and multiplier= {self.multiplier}',
                        level=mLOG.INFO,identifier=self.__class__.__name__)
            else: #loop back to the beginning
                self.cursor=0
                self.starting_point_for_no_keep = 0
                mLOG.log(f'cursor is looping / cursor= {self.cursor} ; length= {self.longest}')
        
        self.end_no_keep = self.starting_point_for_no_keep+1 < self.cursor < (self.starting_point_for_no_keep+1+ AudioParam.END_NO_KEEP)

    def add_one(self):
        """when extending cursor range (length of mixdown) - we need to extend by the longest loop length 
        so there is room for the longest loop to play fully twice.  
        This means adding to the multiplier the multiplier of the longest loop - whatever it was upon entering the overdub method.
        when this is called cursor is pointing at first sample of extension to be added to loop
        starting point for end_no_keep must be adjusted = cursor - 
            in case user is about to click stop (just went pass end of previous loop)
        """
        self.multiplier+=self.overdub_data['previous_multiplier']
        self.longest=self.multiplier*self.base_loop_length
        self.starting_point_for_no_keep = self.cursor


class Loops(list):
    '''
    notes on tracks/volumes:
    - master volume  It is never saved to disk. 
        However master volume is set via linux ALSA mixer - and raspberry pi remembers last volume on boot.
    - rec_volume is represented by track -1 for communication with iphone app. it is saved in song_info
    - Track volumes cannot be saved with the wave files - so they are saved in song_info.  
        Hence when loading track, the previously set volume for a track can be loaded back 
        in the track loop.volume attribute.
    - volumes for tracks that are deleted are persisted in the deted_volume directory, 
        in case the deleted track is restaored (undeleted).
        These are not saved to song_info, so deleted_volumes are only valid for the session,
        until Looper is rebooted, or until a new song is loaded.
    - Note that deleted tracks are never stored with a song - so they too are only available for the current session.
    '''

    MASTER_VOLUME = -3  
    REC_VOLUME = -1    
    
    def __init__(self,tracks_diskwriter: Tracks_Diskwriter, bt_app_handler:bt_svc.Bluetooth_App_Handler):
        self.tracks_diskwriter = tracks_diskwriter
        self.bt_app_handler = bt_app_handler
        self.initialize()
        try:
            self.master_volume = alsaaudio.Mixer('Speaker').getvolume[0]
        except:
            self.master_volume = 50
        
        

    def initialize(self):
        self.clear()
        self.position = Position()
        self.rec_volume = 50 
        self.deleted_volumes={}  #key=track,  value = volume
        #flag if True indicates track volume (including rec_volume, but not master) needs to be saved)
        self.volume_change=False 
        self.song_name = ''


    def add_loop(self,loop,send_update = False):
        """adds a loop to the Loops class (list) - updates position and song info 
        unless it is being done by loading all loops (which then takes care of updating 
        - after all loops are loaded"""
        mLOG.log(f'adding loop of length {len(loop)}')
        self.append(loop)
        self.volume_change = True
        if send_update:
            mLOG.log('updating and sending info ')
            self.position.update_lengths(self)
            self.update_song_info_on_disk()
            mLOG.log(f'one track volume to send {len(self)-1},{self[-1].volume}')
            self.bt_app_handler.send_looper_msg(pickle.dumps( {len(self)-1: self[-1].volume} ))
            self.bt_app_handler.send_looper_msg(f'T{len(self)}')

    def load_saved_loops(self):
        '''this loads all loopXX.wav file that are in the loop/data directory into memory
            i.e into the list that Loops is.  
            This is called when starting the Looper.  
            It is also called if Handlers has loaded a new song:
                Handlers will have erased the /data directory and copied the desired song
                from the repo directory into the /data directory (.wav files and the song_info.dat file)
                at which point this method is ready to load this into memory.'''
        #first - clear self, by initializing
        self.initialize()
        if path.exists(F_INFO.DATADIR+'/song_info.dat'):
            fil=open(F_INFO.DATADIR+'/song_info.dat','rb')
            #volumes is a dictionary: key = track number   value= volume between 0 and 100
            song_name,volumes = pickle.load(fil)
            fil.close()
            self.song_name = song_name
            if Loops.REC_VOLUME in volumes:
                self.rec_volume = volumes[Loops.REC_VOLUME]
            mLOG.log(f'reading song_info.dat name={song_name} ; volumes {volumes}',level=mLOG.INFO,
                     identifier=self.__class__.__name__)
        else:
            self.song_name = ''
            volumes={}

        #load all loops wave files:
        #TODO: verify integrity of all loops as multiple of base_loop at index zero
        #       this is needed when user can change loops outside of looper (not yet)
        filename=F_INFO.PREFIX+'0.wav'
        cnt=0
        while path.exists(filename):
            volume = volumes[cnt] if cnt in volumes else 50
            loop=Loop(volume)
            file_ok=loop.load_wavefile(filename)
            if file_ok:
                self.add_loop(loop)
            cnt+=1
            filename=F_INFO.PREFIX+str(cnt)+'.wav'
        # set-up position parameters corresponding to all loaded loops
        self.position.update_lengths(self)
        self.position.zero_cursor()
        if not path.exists(F_INFO.DATADIR+'/song_info.dat'):
            self.update_song_info_on_disk()
        Handlers.actions_after_loading_loops(self.song_name,len(self),self.bt_app_handler)
    
    def delete_track(self):
        #deletes the last recorded loop from loops and rename it on disk
        # if not deleting last - index MUST BE Positive - to identify the correct wavefile
        try: 
            index=len(self)-1
            self.deleted_volumes[index] = self[index].volume
            self.pop(-1)
            self.position.update_lengths(self)
            file_name=F_INFO.PREFIX+str(index)+'.wav'
            mLOG.log(f'deleting last track ({file_name})',level=mLOG.INFO,
                        identifier=self.__class__.__name__)
             # this does not delete the wave file but renames to filename_deleted.wav
            new_filename,ext=path.splitext(file_name)
            rename(file_name,new_filename+'_deleted'+ext)  #note - if ported to windows - this fails if new_filename exists
            self.bt_app_handler.send_looper_msg(f'T{len(self)}')
            return index
        except:
            mLOG.log(f'caught execption - tried to delete track with count = {len(self)} {traceback.format_exc()}',level=mLOG.INFO,
                        identifier=self.__class__.__name__)
            return -1 #fail silently and do nothing (tracks won't be deleted - or no tracks existed in the first place)

    def restore_tracks(self):
        """restore the deleted track (loopX_deleted.wav) where X is the  loop number equal to the next possible track 
        in current state of the looper - which is to say the current track count.  
        The track is restored by renaming it from loopX_deleted.wav to loopX.wav, and incrementing the track count accordingly.
        It is possible that a deleted track with that name was left over from a previous song that does not match the current base loop.
            To prevent this, before restoring, the track length is checked to ensure it is 
            an integer number multiple of the length of the current base loop.
        """
        index = len(self) #this points to the next loop/file 
        try:
            file_name=F_INFO.PREFIX+str(index)+'.wav'
            deleted_file_name=F_INFO.PREFIX+str(index)+'_deleted.wav'
            if os.path.isfile(deleted_file_name):
                volume = self.deleted_volumes[index] if index in self.deleted_volumes else 50
                loop=Loop(volume)
                file_ok=loop.load_wavefile( deleted_file_name) # this loads the wavefile but does not yet add it to the loops list.
                if file_ok:
                    #check that samples length match this set of files:
                    if len(self)==0 or len(loop)%self.position.base_loop_length == 0:
                        mLOG.log(f'restauring last deleted track ({deleted_file_name})',level=mLOG.INFO,
                                        identifier=self.__class__.__name__)
                        rename(deleted_file_name,file_name)  #note - if ported to windows - this fails if new_filename exists.     
                        self.add_loop(loop,True) #note: this updates position parameters
                        return index
                    else:
                        mLOG.log(f'could not restore {deleted_file_name} - Not match a multiple of base loop length',
                                level=mLOG.CRITICAL,identifier=self.__class__.__name__)
                else:
                    mLOG.log(f'failed to load file: {deleted_file_name}',
                                level=mLOG.CRITICAL,identifier=self.__class__.__name__)
        except Exception:
            mLOG.log(traceback.format_exc(),level=mLOG.CRITICAL,identifier=self.__class__.__name__)
        return -1

    
    def mix(self,x,y,tracks_in_mix=0):
        """ 
        x,y are Chuncks of loops - must be aligned at the same index in loops
        audioop.mul(fragment, width, factor)
        audioop.add(fragment1, fragment2, width)
        formula: 
            first time: V0x/2 + V1y/2 n=track_mixed=1,  will be 2 after mix isdone
            secnd time:  (V0x/2+V1y/2)*2/3 + V2z*1/3 = V0x/3 + V1y/3 + V2z/3 ( the n/n+1 cancels the previous factor...) track_mixed=n=2
        where V0 is the volume of the track ) (x), V1 is track 1 (y) etc.
        volume is number between 0 and 100 - where 50 gives unity gain and 100 doubles the gain
        track_in_mix is used when using mixdown of saved tracks.
        TODO: ignore inserted zero samples so volume is not reduced
        """
        if tracks_in_mix: 
            a= tracks_in_mix/(tracks_in_mix+1)
        else:
            a=self.tracks_mixed/(self.tracks_mixed+1)
        x= audioop.add(audioop.mul(x,AudioParam.SAMPLEWIDTH,a),audioop.mul(y,AudioParam.SAMPLEWIDTH,(1-a)),AudioParam.SAMPLEWIDTH)
        return x

    def mixdownsample(self,extra=b''):  
        """  
        this mixes down all tracks at the current cursor position:
            - first multiplies the sample by the current volume of the track
                volume varies from 0-100, then is divided by 50 to yield a value between 0-2, 
                meaning that a volume of 50 gives unity gain with whatever record level was obtained from sound card.
            - if extra is the live sample to be mixed in (either from play or overdubbing)
                note 1: the extra's volume is in self.rec_volume
                note 2: in play mode there is always a live sample mixed in - even when the player is not playing.
        the method cursor_for_shorter_loops accounts for loops that are shorter then the longest loop (cursor would be too long for them)
            - audioop.mul(fragment, width, factor)
        """  
        if len(self)==1 and len(extra)==0:
            '''if only on track and no sample to mix - return the sample of the one track to play'''
            sample = audioop.mul(self[0][self.position.cursor],AudioParam.SAMPLEWIDTH,self[0].volume/50)
            return sample
        else:
            samples_list=[audioop.mul(loop[self.position.cursor_for_shorter_loops(len(loop))],
                                        AudioParam.SAMPLEWIDTH,loop.volume/50) for loop in self]  
            if len(extra)>0: 
                sample = audioop.mul(extra,AudioParam.SAMPLEWIDTH,self.rec_volume/50)
                samples_list.append(sample)
            return (lambda f,v,w: f(f,v,w))( lambda g,arr,n:  arr[0] if n==0 else self.mix(g(g,arr,n-1),arr[n],n) ,samples_list,len(samples_list)-1 ) 
            #there is a possibiity that if playing zeroes volume is too low (for a loop that samples are late in the loop - test this)
    
    @property 
    def song_info(self):
        """song_info is a tupple :
            - song_name if created - empty string if not
            - dictionary of volumes {int,int} - where track number (index in loops) is key,and volume is value
                includes all non-deleted tracks and rec_volume, but not master volume setting.
        """
        volume_dict = {-1: self.rec_volume} 
        for index,loop in enumerate(self):
            volume_dict[index] = loop.volume
        return (self.song_name, volume_dict)

    def update_song_info_on_disk(self):
        """file song_info.dat is stored in /data directory"""
        pickled_song_info = pickle.dumps(self.song_info)
        self.tracks_diskwriter.send_data( ('SONG_INFO',pickled_song_info) )
        self.volume_change=False

    def perform_volume_request(self,track,volume):
        """
        sets volume_change as a flag to force a song_info save/update"""
        mLOG.log(f'handling volume track={track} ; volume={volume}')
        if track >= 0:
            try: 
                self[track].volume = volume
                self.volume_change = True
            except IndexError: 
                pass  #fail silently if requested volume is for a loop that does not exist.
        elif track == Loops.REC_VOLUME:
            self.rec_volume = volume
            self.volume_change = True
        elif  track == Loops.MASTER_VOLUME: 
            alsaaudio.Mixer('Speaker').setvolume(max(0,min(99,volume)))
        


#**********************************************************************************************************

class AudioParam:
    #define these constants for the audio recording and playback
    #in module wave a frame is one conversion analog-to-digital of SAMPLEWIDTH bytes - example: b'\x00x00
    SAMPLE_LENGTH = 256  #periodsize in pyalsaaudio (5.8 ms at 44.1KHz)
    FORMAT = alsaaudio.PCM_FORMAT_S16_LE  
    SAMPLEWIDTH=2 # in pyalsa audio it is infered from format  (16 bit = width of 2  x 8 bit)
    CHANNELS = 1
    RATE = 44100
    RECORD = alsaaudio.PCM_CAPTURE
    PLAY=alsaaudio.PCM_PLAYBACK
    RECDEV='output'
    PLAYDEV='default'
    #PREFIX = "/home/pi/data/loop"  -> moved to F_INFO class
    NO_KEEP = 170  #number of samples around start of loop that corresponds to no_keep_zone  (see RecLoop) - approx one second
    START_NO_KEEP = 200
    END_NO_KEEP = 200

    @staticmethod
    def initialize(config_map):
        try:
            _no_keep = config_map['NO-KEEP']
            AudioParam.START_NO_KEEP = int(float(_no_keep['Start_No_Keep'])/( AudioParam.SAMPLE_LENGTH/AudioParam.RATE))
            AudioParam.END_NO_KEEP = int(float(_no_keep['End_No_Keep'])/( AudioParam.SAMPLE_LENGTH/AudioParam.RATE))
        except:
            pass
        mLOG.log(f'START_NO_KEEP = {AudioParam.START_NO_KEEP}  END_NO_KEEP = {AudioParam.END_NO_KEEP}')


    @staticmethod
    def params():
        """This is used for managing wave files:Wave_write.setparams(tuple)
        params is a tuple that should be (nchannels, sampwidth, framerate, nframes, comptype, compname)
        """
        a=(AudioParam.CHANNELS,AudioParam.SAMPLEWIDTH,AudioParam.RATE,0,'NONE',' ')
        return a
    
#**********************************************************************************************************

class Loop(list):

    def __init__(self,volume=50):
        self.volume = volume
    
    def convert_external_wave_file(self):
        #needs to set=up the loop (self) of audio data as list of samples of length AudioParam.SAMPLELENGTH
        # to do: allow wave files recorded elsewhere to be converted to the current Audio parameters used in Looper
        raise Exception("wave file parameters don't match current audio parameters of looper")

    def load_wavefile(self,filename):
        try:
             _file=wave.open(filename, 'rb')
             mLOG.log(f'opened {filename}')
        except wave.Error as ex:
            mLOG.log(f'wave.ERROR exception: {traceback.format_exc()}',
                                level=mLOG.CRITICAL,identifier=self.__class__.__name__)
            return False

        params=(_file.getnchannels(),_file.getsampwidth(), _file.getframerate(),0,'NONE',' ')
        frames=_file.getnframes()
        allframes=_file.readframes(frames)
        _file.close()
        if not params == AudioParam.params():
            self.convert_external_wave_file()
        else:
            #create the loop array
            n=frames//AudioParam.SAMPLE_LENGTH #number of samples in the wave file
            mLOG.log(f'loading {filename} of length = {n} samples',
                    level=mLOG.INFO,identifier=self.__class__.__name__)
            for i in range(n):
                start=i*AudioParam.SAMPLE_LENGTH*AudioParam.SAMPLEWIDTH  #to account for 2 byte width
                stop=start + AudioParam.SAMPLE_LENGTH*AudioParam.SAMPLEWIDTH
                self.append(allframes[start:stop])
        return True

#**********************************************************************************************************    

class RecLoop(Loop):
    def __init__(self,tracks_diskwriter: Tracks_Diskwriter,position:Position,next_loop_index=0):
        """ 
        mdloop_length = longest length of current loops
        cursor is where user has clicked: it points to next sample to be played - so in actuality, user click when cursor-1 was playing
        """
        Loop.__init__(self)
        #(<begining area,>ending area) # of samples at start or end where user click start/stop where we do not keep samples
        self.position = position
        self.no_keep = (AudioParam.NO_KEEP,AudioParam.NO_KEEP) 
        #flag indicating if samples sent to rec_loop must be kept or not - for example: No if cursor is in no_keep_zone
        self.record=False  
        self.is_recording_base=False
        # needed as flag to play_audio to store the last sample position indicated by this value (-1 means not needed)
        self.need_last_sample = -1  
        self.file_name = F_INFO.PREFIX+str(next_loop_index)+'.wav'
        self.tracks_diskwriter = tracks_diskwriter
        self.tracks_diskwriter.send_data(('START_FILE',self.file_name))
        self.setup(next_loop_index) 
        

    def setup(self,next_loop_index):
        if next_loop_index==0:
            self.record=True
            self.is_recording_base=True
        else:
            mLOG.log(f'setting up rec loop with cursor at {self.position.cursor} of loop length={self.position.longest}')
            if not self.position.start_no_keep:
                self.before_zeroes(self.position.cursor-1)
                self.record=True
        mLOG.log('Recording and keeping samples ' if self.record else 'setup: NOT Recording yet - waiting cursor at 0')


    def baseloop_sample(self,live_sample):
        self.append(live_sample)
        self.tracks_diskwriter.send_data((self.file_name,live_sample))
    
    def overdub_sample(self,live_sample):
        """ 
        this manages the decision to record a live_sample or not - based on record flag,
        ir record flag is not yet set (satrt_no_keep zone), it waits until cursors loops to zero before starting recording.
        note: that since live_sample is always one slot behind the cursor,
        
        returns True if recording  - this is captured in Looper class and used to decide if cursor loops back to zero or extends 
        because user is recording past the loop.
        """
        if self.record:
                self.append(live_sample)
                self.tracks_diskwriter.send_data((self.file_name,live_sample))
                return True
        elif self.position.cursor==0: 
            self.record=True 
            return False
        return False

    def store_last_sample(self,live_sample):
        """
        stores the live_sample that arrives in play_loop upon exit from overdub
        in the location where the first zero was added when exiting recording(overdub) mode
        returns True if live_sample was added to rec_loop - as a flag to mixed_down_loop to mix it in at cursor-1
        """ 
        if self.need_last_sample > -1:
            self[self.need_last_sample]=live_sample
            mLOG.log(f'stored last sample in last recorded loop at index = {self.need_last_sample}')
            self.tracks_diskwriter.send_data( ( 'INSERT_AT',(self.need_last_sample,live_sample) ) )
            time.sleep(0.0005)
            self.tracks_diskwriter.send_data(('END_FILE',self.file_name))
            self.need_last_sample=-1
            
            return True
        else:
            return False

    def end_record(self,discard=False):
        """ 
        MUST BE CALLED when user stops recording because it sends the flag to diskwriter to store the samples into a loop file.
        - discard is True when user has double-click to go from Play to Idle: the first click will have started a recording
            which must be discarded when the double_click shows up.
        - if user click in end_no_keep zone, loop was just extended, and must be truncated  back to last end of loop
            (which may itself have been extended).
        - if user clicked anywhere else - which is somewhere before the end of the loop - zeroes must be added to make a complete loop.
        """ 
        if discard:
            mLOG.log(f'Discarding Recording due to double stomp in state mgr - discard={discard}',
                        identifier=self.__class__.__name__)
            self.tracks_diskwriter.send_data(('DISCARD_FILE',''))
            self.record=False
            self.is_recording_base=False
            self.clear()
            return False

        if self.is_recording_base:
            mLOG.log(f'BaseLoop End Recording - rec_loop len = {len(self)}',
                        level=mLOG.INFO,identifier=self.__class__.__name__)
            self.record=False
            self.is_recording_base=False
            mLOG.log(f'sending end file - {self.file_name}')
            self.tracks_diskwriter.send_data(('END_FILE',self.file_name))
            return False

        if self.position.end_no_keep:
            #remove everything since the last extension
            multiplier_step=self.position.overdub_data['previous_multiplier']
            del self[self.position.overdub_data['base_loop_length']*(self.position.multiplier-multiplier_step):]
            self.tracks_diskwriter.send_data(('TRUNCATE',
                                self.position.overdub_data['base_loop_length']*(self.position.multiplier-multiplier_step)))
            time.sleep(0.0005)
            self.tracks_diskwriter.send_data(('END_FILE',self.file_name))
            # if user clicked record in no_keep_zone, then clicked off right after in no_keep_zone - rec_loop is now empty
            mLOG.log(f'Overdub End Recording in no keep zone: rec_loop len = {len(self)} ')
            self.record=False
        else: 
            #user did not go past end of loop - just add zeroes but wait until play to store last sample and close file
            if self.record:  #only add zeroes if user was not in no_keep_zone AND Looper was recording samples at the time
                self.after_zeroes(self.position.multiplier*self.position.overdub_data['base_loop_length'])
            self.record=False
        return False

    def before_zeroes(self,how_many):
        """ cursor points to next sample to play, first recorded live sample must be stores at location cursor-1 in rec-Loop,
                so need to fill from location= 0 to location = cursor-2 with zeroes - which equals "cursor-1" number of zeroes 
                (This is why we pass cursor-1 to how_many)
       Thus rec_loop last index = cursor-2, so first recorded sample will be at index cursor-1
        """ 
        if how_many<=0: return False  #handles case where cursor was 0
        zero_sample = b'\x00'*AudioParam.SAMPLEWIDTH*AudioParam.SAMPLE_LENGTH    #creates a zero sample
        mLOG.log(f'inserting {how_many} zeroes before')
        self.extend([zero_sample]*(how_many))
        self.tracks_diskwriter.send_data(('BEFORE_ZEROES',how_many))
        return True

    def after_zeroes(self,looplength):
        """
        add zeroes to self loop to extend to longest looplength (based on multiplier) 
        """
        how_many = looplength - len(self)
        if how_many>0:
            mLOG.log(f'adding zeroes after: recLoop len = {len(self)} ; mixedLoop len = {looplength} ; diff = {how_many}')
            #index of where first zero will go - where last live sample needs to go eventually
            self.need_last_sample=len(self)  
            zero_sample = b'\x00'*AudioParam.SAMPLEWIDTH*AudioParam.SAMPLE_LENGTH    #creates a zero sample
            self.extend([zero_sample]*(how_many))
            self.tracks_diskwriter.send_data(('AFTER_ZEROES',how_many))

#**********************************************************************************************************
    

class TimeInterval:
    """
    usage:
    tm = TimeInterval(10)
    in function before statement:
    tm.elapsed()  // resets the time
    ...statements ...
    tm.print_elapsed('message to print')  // this will print up to 10 times (as setup above in the class instantiation)
    """
    def __init__(self,max_count=1000,process=True):
        #max_count is the number of times print_elapsed will print to the console
        self.process=process
        self.started = self.get_time()
        self.counter =0
        self.max_count = max_count
        

    def get_time(self):
        if self.process:
            return time.perf_counter()
        else:
            return time.time()
    
    def elapsedstr(self):
        """
        returns elapsed time since instantiation or last reset in elapsed - in seconds
        but does NOT reset timer
        """
        s=f'elaspsed time is {(self.get_time()-self.started):.3f}'
        return s
    
    def elapsed(self,reset=True):
        """
        return a float in MILISECONDS with elapsed time since class instanciation
        or since last call to elapsed with rest =True (i.e it resets the time counter)
        only resets counter if reset = True - which is the default
        """
        x=self.get_time()-self.started
        if reset:
                self.started=self.get_time()
        return x*1000

    def print_elapsed(self,msg=''):
        self.counter+=1
        if self.counter<=self.max_count:
            mLOG.log(f'{msg} {self.elapsed()}')



#*************************************************************************************************


class Handlers:
    all_song_names = []

    @staticmethod
    def send_volume_dict(loops: Loops, bt_app_handler: bt_svc.Bluetooth_App_Handler):
        #this is called when ios is initializing and has requested volumes
        #this sends only the volumes for live tracks - not for deleted tracks
        volumes_to_send = loops.song_info[1]  # need only the volume directory
        volumes_to_send[loops.MASTER_VOLUME]=loops.master_volume
        # only add this when sending all volume to reqply to requested volumes by iphone:
        volumes_to_send['notify'] = True  
        mLOG.log(f'volumes to send {volumes_to_send}')
        bt_app_handler.send_looper_msg(pickle.dumps(volumes_to_send))

    @staticmethod
    def controls(bt_app_handler: bt_svc.Bluetooth_App_Handler,loops:Loops):
        """this method only handles one control request at the time 
        it needs to be called again to handle the next request in the incoming list
        returns a tupple: (request_handled (boolean), type (string), request_success(boolean)) """
        for incoming_list in bt_app_handler.get_controls_request():
            code,payload = incoming_list
            mLOG.log(f"code  {code}")
            if code == 'S' or code == 'W':
                overwrite = True if code == 'W' else False
                requested_song_name = payload.strip()
                success,msg= Handlers.save_song_to_repo(loops,requested_song_name,overwrite)
                if success:
                    loops.song_name = requested_song_name
                    #ensure the song_info.dat file has the requested-song_name in it:
                    loops.update_song_info_on_disk()
                    if requested_song_name not in Handlers.all_song_names:
                        Handlers.all_song_names.append(requested_song_name)
                        Handlers.all_song_names.sort()
                    bt_app_handler.send_looper_msg(f'C{requested_song_name}') 
                    bt_app_handler.send_looper_msg('OK')
                else: #not successful:
                    if len(msg)>0:
                        bt_app_handler.send_looper_msg(msg)
                mLOG.log(f"Saving to song: name= {msg} - Success={success}",level=mLOG.INFO)
                return (True,'Save', success)
            elif code == 'L':
                requested_song_name = payload.strip()
                success,msg = Handlers.move_song_to_working_dir(requested_song_name)
                if success: #do not change loops.song_name yet - not loaded into Loops yet.
                    bt_app_handler.send_looper_msg(f'C{requested_song_name}')
                    bt_app_handler.send_looper_msg('OK')
                else:
                    if len(msg)>0:
                        bt_app_handler.send_looper_msg(msg)
                mLOG.log(f"finished Loading song: name= {msg} - Success={success}",level=mLOG.INFO)
                return (True,'Load',success)
            elif code == 'D':
                """does not send confirmation to iphone, unless song being deleted is currently loaded in memory
                    in which case, it only deletes the song from repo
                    In any case - it does not remove song from looper working dir or from memory (Loops)"""
                requested_song_name = payload.strip()
                success = Handlers.delete_song_name_from_repo(requested_song_name)
                if success:
                    if loops.song_name == requested_song_name:
                        loops.song_name = ''
                        #remove the song_name from song_info.dat:
                        loops.update_song_info_on_disk()
                        bt_app_handler.send_looper_msg('C') #sending empty string song name
                    try:
                        Handlers.all_song_names.remove(requested_song_name)
                    except ValueError:
                        pass
                mLOG.log(f"Deleted song name {payload.strip()} - Success={success}",level=mLOG.INFO)
                return(True,payload.strip(),success) #returns the name of the deleted song for 'what'
            elif code == 'R': #requesting to send all song names
                mLOG.log(f"Ready to send all song names {Handlers.all_song_names}")
                bt_app_handler.send_looper_msg(pickle.dumps(Handlers.all_song_names))
                mLOG.log(f"done sending all song names ")
                return(True,'Request',True)
        return (False,'',False)

    @staticmethod
    def check_name(val):
        """ returns True if check_name is valid: matches pattern and is not 0 lenght
        allowed characters:  letters 0-9 underscore  hyphen spaces only
        \w matches: a-z, A-Z, 0-9, including the _ (underscore) character.
        \s is whitespace"""
        if len(val) == 0:
            return False
        pattern = "^[\w\s-]+$"
        result = re.match(pattern,val)
        return result is not None

    @staticmethod
    def check_used(val):
        """ retuns True if name is  already used in repo
        """
        mLOG.log(f'checking song_name {val}')
        repos = glob(F_INFO.REPODIR+'/'+val+'0.wav')
        return len(repos) > 0

    @staticmethod
    def get_all_song_names():
        Handlers.all_song_names = []
        repos = glob(F_INFO.REPODIR+'/*0.wav')   #this will be buggy if track 10 exists
        #print(f'REPOIS= {repos}')
        #THIS WILL BE BUGGY:
        for song_name in repos:
            Handlers.all_song_names.append(os.path.basename(song_name)[:-5])
        Handlers.all_song_names.sort()
        mLOG.log(f'list of song names: {Handlers.all_song_names}')

    @staticmethod
    def delete_song_name_from_repo(val):
        flag_success=False
        #get repofiles - note this returns only the filename - not the whole path: need to add /home/pi/repo/ when deleting etc.
        regexstr = f'{val}\d+.wav'
        repos = [f for f in os.listdir(F_INFO.REPODIR+'/') if re.match(regexstr, f)]
        for filename in repos:
            try:
                remove(f'{F_INFO.REPODIR}/{filename}')
                mLOG.log(f'removing file: {F_INFO.REPODIR}/{filename}')
            except:
                mLOG.log(traceback.format_exc(),level=mLOG.CRITICAL)
        try:
            remove(f'{F_INFO.REPODIR}/{val}_info.dat')
            mLOG.log(f'deleting {val}_info.dat')
        except:
            mLOG.log(traceback.format_exc(),level=mLOG.CRITICAL)

        flag_success=True
        return flag_success
        
        


    @staticmethod
    def save_song_to_repo(loops:Loops, requested_song_name, overwrite):
        '''deletes tracks of exisitng song in repo if they exists
        then copies current tracks in /data directory to repo with the song_name requested.
        note: deleted tracks loopXX_deleted.wav in /data directory are not copied to repo.
        '''
        flag_success = False
        if (not Handlers.check_name(requested_song_name)):
            return (False,'INVALID')
        elif (not overwrite) and (Handlers.check_used(requested_song_name)):
            return (False,'EXISTING')
        else:
            #get repofiles - note this returns only the filename - not the whole path: need to add /home/pi/repo/ when deleting etc.
            regexstr = f'{requested_song_name}\d+.wav'
            repos = [f for f in os.listdir(F_INFO.REPODIR+'/') if re.match(regexstr, f)] # these will be deleted or overwritten
            #repos = glob('/home/pi/repo/'+requested_song_name+'*.wav') not used since it gives all file that starts with song name 
            current_loops = glob(F_INFO.DATADIR+'/loop*[!deleted].wav') #matches all files that start with loop 
                                                                       #and don't have _deleted in the name
            mLOG.log(f'update copy find {len(repos)} in /repo and {len(current_loops)} in /data')
            if len(repos)>len(current_loops):
                    for filename in repos:
                        try:
                            remove(f'{F_INFO.REPODIR}/{filename}')
                            mLOG.log(f'deleting {F_INFO.REPODIR}/{filename}')
                        except:
                                pass
            for current_filename in current_loops: 
                #this copies only live tracks (not deleted, and not song_info.dat)
                try:
                    repo_filename=current_filename.replace(F_INFO.DATADIR+'/loop',F_INFO.REPODIR+'/'+requested_song_name)
                    copy(current_filename, repo_filename)  #overwrites if exists.
                    mLOG.log(f'copying {current_filename} to {repo_filename}')
                except:
                    mLOG('ecxeption while updating tracks copy to /repo for {requested_song_name}',level=mLOG.CRITICAL)
                    return(False,'')
            # now save song_info in [requested_song_name]_info.dat
            song_info = (requested_song_name, loops.song_info[1])
            mLOG.log(f"song_info to save to repo dir: {song_info}")
            try:
                fil = open(f'{F_INFO.REPODIR}/{requested_song_name}_info.dat', 'wb')
                pickle.dump(song_info,fil)
                fil.close()
                mLOG.log(f'written song info  to {F_INFO.REPODIR}/{requested_song_name}_info.dat')
                flag_success = True
            except:
                    mLOG.log(traceback.format_exc(),level=mLOG.CRITICAL)
                    pass

            return (flag_success,requested_song_name)


    def move_song_to_working_dir(val):
        """This moves the song into the /data directory - which is the working directory for looper
        it does not load the song into memory (into Loops class)"""
        # check if requested song exists - return NOT_EXISTS if it does not
        mLOG.log(f'checking if load song name exists {val}')
        if not Handlers.check_used(val):
            return (False,'NOT_EXISTS')
        #remove files from data directory
        data_files = glob(F_INFO.DATADIR+'/loop*.wav')
        for filename in data_files:
            remove(filename)
        try:
            remove(F_INFO.DATADIR+'/song_info.dat')
        except:
            pass
        #load new song into /data - if we get here song exists
        regexstr = f'{val}\d+.wav'
        #find all wavefiles with the song_name
        repos = [f for f in os.listdir(F_INFO.REPODIR+'/') if re.match(regexstr, f)]
        for repo_file in repos:
            filename=repo_file.replace(val,F_INFO.DATADIR+'/loop')
            copy(f'{F_INFO.REPODIR}/{repo_file}', filename)  #overwrites if exists.
            mLOG.log(f'loading song in /data directory- copying {F_INFO.REPODIR}/{repo_file} to {filename}')
        try:
            copy(f'{F_INFO.REPODIR}/{val}_info.dat', F_INFO.DATADIR+'/song_info.dat')
            mLOG.log(f'loading song in /data directory - copying {val}_info.dat to song_info.dat on /data')
        except:
            return(False,'FAILED_LOAD')
        return (True,val)

    @staticmethod
    def actions_after_loading_loops(song_name,track_count,bt_app_handler: bt_svc.Bluetooth_App_Handler):
        bt_app_handler.send_looper_msg(f'C{song_name}')
        bt_app_handler.send_looper_msg(f'T{track_count}')
        Handlers.get_all_song_names() # load song name array ready to be sent to ios app when requested
        val = 'Initialized'
        bt_app_handler.send_looper_msg(f'M{val}')


#**********************************************************************************************************
#Below are method objects to replace the idle,play,base_recording,overdub, quit methods

class Looper_State:
    """ 
    Abstract class that defines what the Looper does when user puts it in a specific state.

    """
    NO_ACTION=0
    DELETE_LAST = 10
    REINSTATE_LAST = 20
    DISCARD_RECORDING = 30
    RECORD_LAST_SAMPLE = 40

    def __init__(self,loops: Loops,user_gui,grab_audio:Grab_Audio,audio_output_stream,bt_app_handler:bt_svc.Bluetooth_App_Handler):
        #note - don't forget to call super().__init__() in derived classes
        self.loops = loops
        self.user_output = user_gui
        self.grab_audio = grab_audio
        self.audio_output_stream = audio_output_stream
        self.bt_app_handler = bt_app_handler
        self.action_requested = self.NO_ACTION


    @property
    def state_name(self):
        return self.__class__.__name__
    
    def do_on_start(self):
        '''things to do when state changes to this class'''
        pass

    def run(self):
        ''' must return a boolean'''
        pass
        return True

    def do_on_exit(self):
        '''things to do when leaving this state'''
        pass

    def close(self):
        '''may not be needed'''
        pass


    def check_and_manage_any_volume_request(self,ok_to_save = False):
        for incoming_volume in self.bt_app_handler.get_volume_request():
            track,volume = incoming_volume #remove oldest first
            if volume>100: #this is a request to send all volume - not to adjust volume of track
                Handlers.send_volume_dict(self.loops,self.bt_app_handler)
            else:
                self.loops.perform_volume_request(track,volume)
        if ok_to_save and self.loops.volume_change:
            self.loops.update_song_info_on_disk()

    def record_last_sample(self):
        '''When recording a loop, at the time where the stop recording is issued (button click)
            the last played sample during recording is being grabbed from the sound card by Grab Audio
            and is not available for sotrage in the RecLoop - which is nevertheless added to Loops
            upon exiting the recording state (base_loop or overdub).
            This methods handles this work.
            States that can be reached directly from either recording states (either play_state or edit_mode_state)
            need to check the action_requested = REACORD_LAST_SAMPLE called this method
        '''
        try:
            if self.loops[-1].need_last_sample>-1:
                mLOG.log(f'recording last sample= {self.loops.position.cursor} ; last sample position= {self.loops[-1].need_last_sample}')
                live_sample = self.grab_audio.get_next_sample()
                self.loops[-1].store_last_sample(live_sample)
                mixed=self.loops.mixdownsample(live_sample)
                self.audio_output_stream.write(mixed)
                self.loops.position.advance()
                mLOG.log(f'cursor has advanced {self.loops.position.cursor}')
        except:
            mLOG.log(traceback.format_exc(),level=mLOG.CRITICAL)
            pass

class Edit_Mode(Looper_State):

    def __init__(self,loops,user_gui,grab_audio,audio_output_stream,bt_app_handler):
        super().__init__(loops,user_gui,grab_audio,audio_output_stream,bt_app_handler)


    def do_on_start(self):
        '''things to do when state changes to this class'''
        """  
        this just plays out what Grab_Audio is putting out.  
        consider putting in a noise gate (if less than a certain volume - output b'\x00\x00')
        """
        mLOG.log(f'entering edit(bypass) mode with action {self.action_requested}',level=mLOG.INFO)
        self.user_output.looper_rec(False)
        self.user_output.edit_mode(True)  # indicate looper is in edit mode (green LED)

        if self.action_requested == Looper_State.RECORD_LAST_SAMPLE:
            self.record_last_sample()
        elif self.action_requested == Looper_State.DELETE_LAST:
            self.loops.delete_track()
        elif self.action_requested == Looper_State.REINSTATE_LAST:
            self.loops.restore_tracks()
        
        self.user_output.display_digit(len(self.loops))
        self.action_requested = Looper_State.NO_ACTION #always clear after taking action
        self.loops.position.zero_cursor()

    def run(self):
        ''' must return a boolean'''
        live_sample=self.grab_audio.get_next_sample()
        self.audio_output_stream.write(live_sample)
        #check if any Looper controls were requested via iPhone app/bluetooth
        handled,what,success = Handlers.controls(self.bt_app_handler,self.loops)
        if handled and success and (what == 'Load'): 
            self.loops.load_saved_loops()
            self.user_output.display_digit(len(self.loops))

        #volume request also come from iPhone app:
        self.check_and_manage_any_volume_request(ok_to_save=True)
        # only in edit mode - check log file size for rotation:
        mLOG.check_size_and_rotate()
        return True

    def do_on_exit(self):
        '''things to do when leaving this state'''
        pass

class Idle(Looper_State):

    def __init__(self,loops,user_gui,grab_audio,audio_output_stream,bt_app_handler):
        super().__init__(loops,user_gui,grab_audio,audio_output_stream,bt_app_handler)

    def display_tracks(self):
        if len(self.loops) == 0:
            #display hyphen instead of zero
            self.user_output.display_digit(-1)
        else: #display number of tracks 
            self.user_output.display_digit(len(self.loops))


    def do_on_start(self):
        '''things to do when state changes to this class'''
        """  
        this just plays out what Grab_Audio is putting out.  
        consider putting in a noise gate (if less than a certain volume - output b'\x00\x00')
        """
        mLOG.log('entering idle mode',level=mLOG.INFO)
        self.user_output.looper_rec(False)
        self.user_output.edit_mode(False)  # indicate looper is in edit mode (green LED)
        self.display_tracks()
        self.loops.position.zero_cursor()

    def run(self):
        ''' must return a boolean'''
        live_sample=self.grab_audio.get_next_sample()
        self.audio_output_stream.write(live_sample)
        #check if any Looper controls were requested via iPhone app/bluetooth
        handled,what,success = Handlers.controls(self.bt_app_handler,self.loops)
        if handled and success and (what == 'Load'): 
            self.loops.load_saved_loops()
            self.user_output.display_digit(len(self.loops))

        #volume request also come from iPhone app:
        self.check_and_manage_any_volume_request(ok_to_save=True)

        return True

    def do_on_exit(self):
        '''things to do when leaving this state'''
        pass

class Play(Looper_State):

    def __init__(self,loops,user_gui,grab_audio,audio_output_stream,bt_app_handler):
        super().__init__(loops,user_gui,grab_audio,audio_output_stream,bt_app_handler)

    def do_on_start(self):
        '''things to do when state changes to this class
            plays the mixed down loops available and the grabbed frames coming in
            if frame "n" was being grabbed when recording stops or idle start event occured - 
            frame "n" will have been put in play_pcm stream before checking events and changing state to play_loop.  
            So when loop start, wait for the next grabbed frame "n+1"
            and mix it with loop[0] then send to play_pcm stream
        '''
        self.user_output.looper_rec(False)
        self.user_output.edit_mode(False)
        self.user_output.loop_reset(self.loops.position.longest)
        mLOG.log(f'entering play_loop at cursor= {self.loops.position.cursor} ; mdloop len= {self.loops.position.longest}',level=mLOG.INFO)
        # check if coming from overdub and need to record mix down of last sample (being played while we get here)
        # in this case the last loop added to Loops is a RecLoop - has extra methods
        if self.action_requested == self.RECORD_LAST_SAMPLE:
            self.record_last_sample()
            self.action_requested = self.NO_ACTION

    def run(self):
        ''' must return a boolean'''
        live_sample = self.grab_audio.get_next_sample()
        mixed=self.loops.mixdownsample(live_sample)
        self.audio_output_stream.write(mixed)
        self.loops.position.advance()
        self.user_output.loop(self.loops.position.cursor)
        self.check_and_manage_any_volume_request(ok_to_save=False)

        
        return True

    def do_on_exit(self):
        '''things to do when leaving this state'''
        self.user_output.loop_reset(self.loops.position.longest)


class Record_Base_Loop(Looper_State):

    def __init__(self,loops,user_gui,grab_audio,audio_output_stream,bt_app_handler,tracks_diskwriter: Tracks_Diskwriter):
        super().__init__(loops,user_gui,grab_audio,audio_output_stream,bt_app_handler)
        self.tracks_diskwriter = tracks_diskwriter

    def do_on_start(self):
        '''things to do when state changes to this class'''
        mLOG.log('entering base loop recording',level=mLOG.INFO)
        self.user_output.edit_mode(False)
        self.user_output.looper_rec(True)
        self.rec_loop=RecLoop(self.tracks_diskwriter,self.loops.position)
        

    def run(self):
        ''' must return a boolean'''

        live_sample = self.grab_audio.get_next_sample()
        self.audio_output_stream.write(live_sample)
        self.rec_loop.baseloop_sample(live_sample)
        self.check_and_manage_any_volume_request(ok_to_save=False)
        return True

    def do_on_exit(self):
        '''things to do when leaving this state'''
        mLOG.log(f'leaving base loop recording with # of samples= {len(self.rec_loop)}')
        self.rec_loop.end_record()
        
        if len(self.rec_loop)>0:
            self.loops.add_loop(self.rec_loop,True)
            self.user_output.loop_reset(len(self.rec_loop))


class Overdub(Looper_State):

    def __init__(self,loops,user_gui,grab_audio,audio_output_stream,bt_app_handler,tracks_diskwriter: Tracks_Diskwriter):
        super().__init__(loops,user_gui,grab_audio,audio_output_stream,bt_app_handler)
        self.tracks_diskwriter = tracks_diskwriter

    def do_on_start(self):
        '''things to do when state changes to this class'''
        #note: self.cursor is pointing at the next sample from mixed_down_loop that will be played
        #can only arrive here from play - which will have set cursor at least = 1 before exiting (reacting to event)
        self.user_output.edit_mode(False)
        self.user_output.looper_rec(True)
        loop_length=self.loops.position.longest #upon entry (this may change)
        self.loops.position.setup_overdub()
        mLOG.log(f'entering overdub at cursor= {self.loops.position.cursor} ; loop length = {loop_length}',
                        level=mLOG.INFO,identifier=self.__class__.__name__)
        self.rec_loop=RecLoop(self.tracks_diskwriter,self.loops.position,len(self.loops))  
        self.record_samples_flag=False
        self.user_output.loop_reset(loop_length)
        self.multiplier_on_entry=self.loops.position.multiplier

    def run(self):
        ''' must return a boolean'''
        live_sample = self.grab_audio.get_next_sample() # this sample corresponds to cursor-1
        #cursor points to the sample about to be played - which is the last mixed sample heard by user +1
        mixed = self.loops.mixdownsample(live_sample)
        #this appends the live_sample to RecLoop being constructed through recording. sample ends up at location = cursor-1
        self.record_samples_flag= self.rec_loop.overdub_sample(live_sample) 
        self.audio_output_stream.write(mixed)  
        self.loops.position.advance(self.record_samples_flag)
        #in case multiplier has been increase by user recording into second loop:
        #this resets cursor location to within original longest loop when overdub was entered
        self.user_output.loop(self.loops.position.cursor-(self.loops.position.multiplier-self.multiplier_on_entry)*self.loops.position.base_loop_length)
        self.check_and_manage_any_volume_request(ok_to_save=False)
        return True

    def do_on_exit(self):
        '''things to do when leaving this state'''
        mLOG.log(f'overdub on exit - discarding: {self.action_requested==Looper_State.DISCARD_RECORDING}')
        if self.action_requested==Looper_State.DISCARD_RECORDING:
            self.rec_loop.end_record(discard=True)
            self.loops.position.update_lengths(self.loops)
            self.action_requested=Looper_State.NO_ACTION
        else:
            self.rec_loop.end_record() 
            if len(self.rec_loop)>0:
                self.loops.add_loop(self.rec_loop,True)
                mLOG.log(f'keeping overdub - mixed_down length= {self.loops.position.longest} ; length rec= {len(self.rec_loop)}',
                        level=mLOG.INFO,identifier=self.__class__.__name__)
      
        self.user_output.loop_reset(self.loops.position.longest)
        mLOG.log(f'exiting overdub - longest length= {self.loops.position.longest} ; length rec= {len(self.rec_loop)}',
                                 identifier=self.__class__.__name__)


class Quit(Looper_State):

    def __init__(self,loops,user_gui,grab_audio,audio_output_stream,bt_app_handler,quit_event,
                    tracks_diskwriter: Tracks_Diskwriter,user_input: User_Input):
        super().__init__(loops,user_gui,grab_audio,audio_output_stream,bt_app_handler)
        self.equit = quit_event
        self.grab_audio = grab_audio
        self.tracks_diskwriter = tracks_diskwriter
        self.user_input = user_input

    def do_on_start(self):
        '''things to do when state changes to this class'''
        pass

    def run(self):
        ''' must return a boolean'''
        mLOG.log('entering Looper class quit routine',level=mLOG.INFO)
        #close remote processes
        self.grab_audio.purge_sample_pipe()  # if quiting with button (3 sec wait) / pipe will have filled up and Grab_Audio is blocked on send
        self.equit.set()
        self.tracks_diskwriter.send_data(('QUIT',0))
        self.bt_app_handler.send_looper_msg('QUIT')
        
        time.sleep(1) # give times to sample in pcm stream to finish playing
        mLOG.log('after 1 sec sleep - closing pcm output stream')
        #self.audio_output_stream.close()
        #self.loops.save(all=True)
        try:
            mLOG.log('closing samples pipe on this end')
            self.grab_audio.dispatch.close_all_pipes()
        except:
            pass
        try:
            mLOG.log('closing bluetooth pipe on this end')
            self.bt_app_handler.teardown()
        except:
            pass
        
        try:
            mLOG.log('closing wave writer pipe on this end')
            self.tracks_diskwriter.dispatch.close_all_pipes()
        except:
            pass
        
        mLOG.log('calling close on user_input')
        self.user_input.close_it()
        mLOG.log('calling close on user_output')
        self.user_output.close_it()
        mLOG.log(' Looper class leaving quit routine',level=mLOG.INFO)
        return False

    def do_on_exit(self):
        '''things to do when leaving this state'''
        pass

#**********************************************************************************************************


class Looper:
    """
    this is the main process class.
    its function is to receive recorded frames and play them in a loop
    and to keep each loop/dub into memeory and play them in a loop when required.

    loop: a loop is either the base loop or any dub made afterwards.
    loop is an array of audioparam SAMPLES - which contains chunck of frames 
    Chunck correspond to period size in alsaaudio PCM object
    loops: is an array that contain the base loop (always at index 0) and 
    all overdubs loop made afterwards
    (note: loops is not strictly necessary - it is only a holder of all loops in memory 
    in case we want to do something with them individually later):
    currentloop contains the loop currently recording  - which needs to be mixed - in during recording. 
    After recording it becomes the newest member of loops (nth number) - and play mixes that down to 
    the mixed loop (if it's confirmed that the currentloop (recorded) is good and to be kept,)
    mergedloop is the mix of all loops (imcluding the current loop dub) 
    this uses a pipe instead of a queue to play samples that have been recorded via pcm capture stream

    """
   

    def __init__(self,config_map):
        """
        states are defined as: 
        list of states: 0:"idle"  1: "play_loop"  2:"overdub"  3:"base_recording  4:"quit"
        idle: this is the state where loop is not playing - just pass grabbed frames to play output
        base_recording:  when there are no loops and recording first base_loop
        play_loop: looper is playing mixed_down loop (and mixing in live input (if no op-map analog mixer)
        overdub: when at least one loop exists and we are recording over it.
        quit:  quitting the program
        self.states is a tupple of the functions that implement each state behavior - call the function as self.states[index]()
        """

        self.tracks_diskwriter=Tracks_Diskwriter()
        self.equit= multiprocessing.Event()
        self.grab_audio=Grab_Audio(self.equit)
        self.bt_app_handler = bt_svc.Bluetooth_App_Handler()

        self.pcm=alsaaudio.PCM(AudioParam.PLAY,  channels=AudioParam.CHANNELS,
                rate=AudioParam.RATE, format=AudioParam.FORMAT,periodsize=AudioParam.SAMPLE_LENGTH, )

        self.user_input = User_Input(config_map)
        self.user_output = User_Output(config_map)

        self.loops=Loops(self.tracks_diskwriter,self.bt_app_handler)  # array of loops recorded so far index=0 is base loop

        self.idle_state = Idle(self.loops,self.user_output,self.grab_audio,self.pcm,self.bt_app_handler)
        self.play_state = Play(self.loops,self.user_output,self.grab_audio,self.pcm,self.bt_app_handler)
        self.overdub_state = Overdub(self.loops,self.user_output,self.grab_audio,self.pcm,self.bt_app_handler,self.tracks_diskwriter)
        self.base_loop_record_state = Record_Base_Loop(self.loops,self.user_output,self.grab_audio,self.pcm,
                                                        self.bt_app_handler,self.tracks_diskwriter)
        self.quit_state = Quit(self.loops,self.user_output,self.grab_audio,self.pcm,self.bt_app_handler,self.equit,
                                self.tracks_diskwriter,self.user_input)
        self.edit_mode_state = Edit_Mode(self.loops,self.user_output,self.grab_audio,self.pcm,self.bt_app_handler)
        self.state = None
        self.previous_state = None

        

                
    def start_sub_processes(self):
        self.bt_app_handler.start()
        self.tracks_diskwriter.start()
        self.grab_audio.start()
        time.sleep(1)


    def set_state_on_user_input(self,start,is_double,run,graceful_quit_requested):
        """
        list of states: 0:"idle"  1: "play_loop"  2:"overdub"  3:"base_recording  4:"quit" 
        the only other information that manager requires is whether there are loops already recorded or not,
        and this is only use in the idle state to decide whether the start button triggers a base recording (no loops yet)
        or goes to play_loop (there is at least one loop).  if looper is in any other state, loops_exist is ignored and can be safely left to its True default

        return flag:  True means either no events was received - keep doing what you were doing
                            False means user input was received  - and next (requested ) state was set-up. (in self.state)

        double stomp management (when start is pressed twice within a short amount of time)
        while in run mode:
            if user is in idle - existing tracks: the first stomp goes into play, the second stomp does into overdub (that is what user wants - not a double stomp)
            if user is in idle - no tracks: the first stomp goes into base recording, the second stomp must be ignored
            if user is in play mode: double stomp means go to idle.  the first stomp will go into overdub, so the double stomp will be detected while 
                                        in overdub, and the recording must be discarded and state must be set to idle
            if user is in overdub or base recording: the double stomp is not necessary but must be handled as a single stomp - which is to stop recording
                    and return to play mode.  the first stomp will have done that, and the second stomp will be detected while user is in play mode.
                    In this case the second stomp must be ignored (otherwise it will restart a recording)
        while in edit mode:
            if user stomps once - deleted the last track - but wait to confirm that a second stomp is not coming
            if user stomps twice - reinstate the last deleted track with the next number
            if user stomps once and hold 3 seconds: shut down looper and RPi
            
        """
        self.ignore_user_input = False
        #check bluetooth first
        #TODO: self.manage_bluetooth()
        
        mLOG.log(f'STATE on entry={self.state.state_name} ; start={start} ; double_stomp={is_double} run={run} ; signal_quit={graceful_quit_requested}')
        mLOG.log(f'edit button is {self.user_input.run_button_value} : 0=Run,  1= Edit (bypass)')

        if graceful_quit_requested:
            return self.quit_state

        if self.user_input.run_button_value == 0: #run mode
            #transition from edit to run simply puts the looper in idle and run mode
            #if start was recieved exactly at the same time as run - start is handled as if we were already in run mode
            if run and (not start):
                return self.idle_state
            if start:
                # checking for edit_mode_state here handles the case where run and start where clicked exactly at the same time
                if self.state == self.idle_state or self.state == self.edit_mode_state:
                    if len(self.loops)>0:
                        return self.play_state
                    else:
                        return self.base_loop_record_state
                elif self.state==self.play_state:  
                    if is_double and (self.previous_state==self.base_loop_record_state or self.previous_state==self.overdub_state):
                        #user did a double stomp to stop recording - which was already handled by the first stomp - so ignore it and stay in play_loop
                            self.ignore_user_input = True
                            return self.play_state
                    else: # note: a double stomp from idle that went to play_loop on first stomp, goes to overdub on second.
                        return self.overdub_state
                elif self.state==self.overdub_state:
                    # if user was in play state, and doubled stomped, the first stomp will have started the overdubbing
                    # then 1/2 second later the double stomp is detected, so we need to get rid of the recording 
                    if is_double:
                        self.overdub_state.action_requested = Looper_State.DISCARD_RECORDING # to be performed on exit in run loop
                        return self.idle_state
                    else: # normal single stomp  or first stomp of a double on start button will stop the recording
                        self.play_state.action_requested = Looper_State.RECORD_LAST_SAMPLE
                        return self.play_state
                elif self.state==self.base_loop_record_state:  
                    # if user was in idle state, and doubled stomped, the first stomp will have started the base recording 
                    # then 1/2 second later the double stomp is detected, this is ignored and the base recording continues
                    if is_double:
                        self.ignore_user_input = True
                        return self.base_loop_record_state
                    else:
                        self.play_state.action_requested = Looper_State.RECORD_LAST_SAMPLE
                        return self.play_state
        elif self.user_input.run_button_value == 1: #edit/bypass mode
            #logic - if run occurs we handle it and ignore start if a start occured at exactly the same time.
            if run: #user has just switched to edit mode
                if self.state ==self.overdub_state or self.state == self.base_loop_record_state:  
                    self.edit_mode_state.action_requested = Looper_State.RECORD_LAST_SAMPLE  # tell play loop to store last sample and then exit to idle
                    return self.edit_mode_state
                else: #either in idle or playLoop
                    return self.edit_mode_state
            else:
                ''' in edit mode - we know we get either single or double click (or hold)
                so when we get a first click - we sleep a bit longer than double click time and check 
                - if a double click has arrived then we act on it, if not it is a single click (unless button is held down)'''
                t = self.user_input.start_button_last_edge_info[1]
                #first check if we get a double stump:
                time.sleep(self.user_input.start_button.DOUBLE_MAX_TIME+0.1)
                s, double_stomp, r = self.user_input.check_for_button_input()
                if double_stomp:
                    mLOG.log('in edit mode - received DOUBLE CLIK',level=mLOG.INFO)
                    self.edit_mode_state.action_requested = Looper_State.REINSTATE_LAST  # re-instate a deleted track
                    return self.edit_mode_state
                elif self.user_input.start_button_value==0: # check if user has already released the button - if so it's a quick single stomp
                    mLOG.log('in edit mode - received SINGLE_CLICK',level=mLOG.INFO)
                    self.edit_mode_state.action_requested = Looper_State.DELETE_LAST  # delete last track 
                    return self.edit_mode_state   
                else:  #user is still holding the button
                    mLOG.log('HELD FOR QUIT',level=mLOG.INFO)   
                    ready_to_quit = True
                    while time.perf_counter()-t < 2.1:  #loop for up to 3 seconds to see if user is holding down button trying to exit looper/shutdown rpi
                        if self.user_input.start_button_value==0:
                            #user has released button before 3 seconds - delete last track
                            mLOG.log('not held long enough for QUIT - treated as SINGLE CLICK',level=mLOG.INFO)  
                            ready_to_quit = False
                            self.edit_mode_state.action_requested = Looper_State.DELETE_LAST  # delete last track 
                            return self.edit_mode_state
                        time.sleep(0.5)
                    if ready_to_quit:
                        return self.quit_state 

    def run(self):
        self.start_sub_processes()
        self.loops.load_saved_loops()

        if self.user_input.run_button_value == 0:  #run mode
            self.state = self.idle_state
        else:
            self.state = self.edit_mode_state
        self.previous_state = self.state
        self.state.do_on_start()
        keep_going = True

        while keep_going:
            start,is_double,run = self.user_input.check_for_button_input()
            if start or run or self.user_input.graceful_quit_requested:
                temp = self.state
                self.state = self.set_state_on_user_input(start,is_double,run,self.user_input.graceful_quit_requested)
                if not self.ignore_user_input:
                    self.previous_state = temp
                    self.previous_state.do_on_exit()
                    self.state.do_on_start()
            keep_going = self.state.run()

        mLOG.log('Looper class has left the while loop',
                        level=mLOG.INFO,identifier=self.__class__.__name__)
        mLOG.log('waiting a little while to ensure all subprocesses terminate gracefully...')
        time.sleep(1)
        self.tracks_diskwriter.join()  
        self.grab_audio.join()
        self.bt_app_handler.join()
        mLOG.log('exiting Looper run method',level=mLOG.INFO)
 
#********************************************************************************************************


def main():
     # this yields absolutepath of the python file looper4.py 
    main_dir = os.path.dirname(sys.argv[0])

    mLOG.current_level=mLOG.INFO
    mLOG.log_filename = f'{main_dir}/looperLog.log'
    #comment the following lines for production:
    mLOG.current_level=mLOG.DEV
    mLOG.print_to_console = True
    
    mLOG.log('********* Starting Looper ** version date: June 15, 2022  *******',level=mLOG.INFO)

    #set directory info:
    mLOG.log(f'computed main dir= {main_dir}',level=mLOG.INFO)
    F_INFO.DATADIR = main_dir+F_INFO.DATADIR
    mLOG.log(f'computed data dir= {F_INFO.DATADIR}')
    F_INFO.REPODIR = main_dir+F_INFO.REPODIR
    F_INFO.PREFIX = main_dir+F_INFO.PREFIX
    F_INFO.INI_FILE = main_dir+F_INFO.INI_FILE

    config = ConfigData(F_INFO.INI_FILE)
    mLOG.initialize(config.config_map)
    AudioParam.initialize(config.config_map)

    play=Looper(config.config_map)
    
    try:
        os.system("sudo systemctl stop segment.service")
    except:
        mLOG.log(traceback.format_exc(),level=mLOG.CRITICAL)

    play.user_output.display_digit(-1)
    play.run()
    
    if  not play.user_input.graceful_quit_requested:
        play = None
        os.system("sudo shutdown -h now")
    else:
        play = None

if __name__ == "__main__":
    main()

