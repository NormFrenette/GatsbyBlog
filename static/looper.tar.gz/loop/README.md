# looper
#This is a instrument (guitar/base etc.) looper pedal implemented in python for a raspberry pi.
There are 4 python files to download, and a number of dependencies to install.  
Python 3.7 or newer is required.

A raspberry pi equipped with appropriate switches, LED and 7-segment LED is also required.

An iphone app will soon be available to control the looper via bluetooth - although the looper is usuable as a stand-alone pedal.  

This is essentially a maker's project.

Details of schematics, parts list, and software installation can be found at https://normfrenette.com/
under the Looper entry.

The software is open source under the MIT license - a copy is included with the python files.

Copyright (c) 2021 normfrenette.com - Normand Frenette
