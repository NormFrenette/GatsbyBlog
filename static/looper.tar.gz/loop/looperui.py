import RPi.GPIO as GPIO
import time
from my_logger.my_logger import mLOG
import traceback
import signal



class ButtonPoll:
    """this class is built on the premise that the application that needs to read the button is polling the button value regularly, and to some extent
    relatively quickly (1-25 ms period).  this is the case for the looper app at 5 ms or so.
    the class reads the button value every time it is polled and looks for a  multiple n reads to be the same before reporting a new stable value.  
    the consecutive values are averaged over the last n reads - and the stable value is reported as 1 if the average is 0.5 or above, or 0 if below.
    to arm the system - the initial value is reported until n reads have occured.
    the check method returns whether a change of state has occured since the last poll.  if so application should 
    query the stable_state variable to find out the current value (and infer the transition that occured).
    NOTE: This class should be used for relatively slow moving switches/buttons and reactions to these that are not very time sensitive:
          if the switch transition is moving faster than n times the poll period - the transition will be missed 
    """
    def __init__(self, channel, sample_count = 5, pullup=None, GPIO_mode = GPIO.BCM):  #bouncetime is for GPIO module - in milliseconds
        GPIO.setmode(GPIO_mode)
        GPIO.setwarnings(False)
        #default of RPi is 1-8 have Ppull up and the rest have pull_down - so unless user has specified a value simply enforce default.
        if (pullup is None) or not(pullup==GPIO.PUD_UP or pullup==GPIO.PUD_DOWN):
            if channel<=8:
                pullup=GPIO.PUD_UP
            else:
                pullup=GPIO.PUD_DOWN
        GPIO.setup(channel, GPIO.IN,pull_up_down=pullup)
        self.channel = channel
        self.sample_count = sample_count

        self._stable_state = GPIO.input(self.channel)  # it is assumed that when initializing the class, buttons are not being manipulated - i.e value is stable
        self.values = []

    def check(self):
        '''returns True if state has changed'''
        pin_value=GPIO.input(self.channel)
        if len(self.values)<self.sample_count:
            self.values.append(pin_value)
        else:
            self.values.pop(0)
            self.values.append(pin_value)
            avg = sum(self.values)/self.sample_count
            avgLevel = (avg >=0.5)  #true - or 1 - if average is greater or equal than 0.5
            if avgLevel != self._stable_state:
                self._stable_state = avgLevel
                return True

        return False

    @property
    def value(self):
        return self._stable_state

    def cleanup(self):
        pass
            

class ButtonEdgeDetect:
    """
    Detects a rising or falling edge of a button (typically push and hold button but also works for toggle)
    class always detects both edges, and applies the standard GPIO debouncer as soon as an edge occurs.
    It then filters for the rising or falling edge by checking the actual value of the button after a suitable smaller debounce time
    (which should be tested against the physical button being used).
    this class corrects the problem of detecting a rising or falling edge using the standard edge_detect function of GPIO - 
    which always detect both edges because if looking for falling edge - the rising edge is not debounced - and vice-versa  

    Latching of Detection:
    The class latches the detection of the requested type of edge (GPIO.RISING / FALLING / BOTH) in the variable self._edge
    which is only reset when it is read via the property edge_detected.

    Always recording both edge transitions:
    Internally, it detects every edge that occurs (after the GPIO bouncetime ) and always stores 
    the last rising edge and the time.perf_counter in the  tupple self.last_edge.  This should be used carefully:
        - if a switch is set to detect GPIO.RISING - the push of a button (normally_off) will set _edge to True 
            and record GPIO.RISING / time in last_edge
        - momentarily later when the button is released, last_edge will be updated to read GPIO/FALLING / time of release 
            even though _edge has not be read yet.
        - one usage of this is for timing length of a push/hold-down:
            * set edge detection to GPIO.RISING (assuming button pushed = high)
            * check edge detection via property edge_detected.
            * read last_edge tupple: if edge == self._type_of_edge, button is still being held down.  
               a time-sleep loop can be started that checks last_edge until it changes - and for accuracy we can use the time stamp.

    double_click/stomp detection:
        NOTE: for the following to work, the edge detection must be set to RSING or FALLING - but not BOTH
              If set to BOTH the following is not run
        How it works:|
        The callback stores the time of a click that match the type_of_edge detection requested in self._edge_time.
            when the next click (of the same type of edge) is detected,
            it compares its click time to the previous and decides if a double stump occured
        if a double stomp occured:
            - it sets _double to True
            - it sets _edge_time to 0  
        note: if another click occurs after this, _double is reset to False, 
            so it is possible that the calling function does not see it if it does not check
              (this is not a problem for the looper since it is checking state after each sample is processed = 5 ms intervals)

        note:   for Looper - start button is normally high (in off position) - pushing it down is low.  
                button is set to detect GPIO.RISING (detect when user releases the button)

    """

    DOUBLE_MAX_TIME = 0.5  # constant in second within which a double stomp is detected and called S
    #note - must be larger than hardware debounce otherwise will me missed
    #sample period is 5.8 ms - each 0.1 seconds = about 17 samples  (0.5s = 86 samples)
    # these state correspond to the name of the methods of the Looper class of the looper.
    

    def __init__(self, channel, detect, pullup=None, bouncetime=50, hardware_debounce = 0.01, GPIO_mode = GPIO.BCM):  #bouncetime is for GPIO module - in milliseconds
        self.hardware_debounce = hardware_debounce  #in seconds - for time.sleep
        GPIO.setmode(GPIO_mode)
        GPIO.setwarnings(False)
        #default of RPi is 1-8 have Ppull up and the rest have pull_down - so unless user has specified a value simply enforce default.
        if (pullup is None) or not(pullup==GPIO.PUD_UP or pullup==GPIO.PUD_DOWN):
            if channel<=8:
                pullup=GPIO.PUD_UP
            else:
                pullup=GPIO.PUD_DOWN
        GPIO.setup(channel, GPIO.IN,pull_up_down=pullup)
        GPIO.add_event_detect(channel, GPIO.BOTH,callback=self._edge_callback, bouncetime=bouncetime)

        self.last_edge = (None,0)  # (RISING or FALLING, time.perfcounter() at which edge occured) - used for button push & hold detection.
                                   # always recorded even if class does not report a trigger on edge.
        self._edge_time = 0  # keeps the time (form last_edge) at which the _type_of_edge was detected  (used for double stomp detection)
        self._double = False  # True if double stomp has occured

        self._edge = False   # True if _type_of_edge (detect) is detected - latched until read
        self._type_of_edge = detect  #For Looper start button - this set to  GPIO.RISING
        self.channel = channel

    def _edge_callback(self,channel):
        t=time.perf_counter()
        time.sleep(self.hardware_debounce)  # switch debounce / check against the physical switch if it's value is enough to debounce the switch
        
        try:
            #determine which type of edge and record its time
            if GPIO.input(self.channel)==1:
                self.last_edge = (GPIO.RISING,t)
            else:
                self.last_edge = (GPIO.FALLING,t)

            #only set _edge to True if it matches the one we wish to detect
            if self._type_of_edge == GPIO.BOTH:
                self._edge=True
            elif self._type_of_edge == self.last_edge[0]:
                self._edge=True
                #check for double click/stomp:
                if (t-self._edge_time) < self.DOUBLE_MAX_TIME:
                    self._double = True
                    self._edge_time =0
                else:
                    self._double = False
                    self._edge_time = t
            
        except RuntimeError:
            # when exiting looper with shutdown button, GPIO looses initialization then stop button rises - and this callback
            # is called, and GPIO raise error: Please set pin numbering mode using GPIO.setmode(GPIO.BOARD) or GPIO.setmode(GPIO.BCM)
            mLOG.log(f'RunTime error occured: {traceback.format_exc()}', level=mLOG.CRITICAL)


    @property
    def edge_detected(self):
        #_edge remains True until it is read - so multiple hit of the button cannot be detected between reads
        x=self._edge
        self._edge = False
        return x

    @property
    def value(self):
        return (GPIO.input(self.channel))

    @property
    def isDouble(self):
        # when querying if a button press is double, the user may not have querying _edge, such as in waiting for a double before acting.
        #in this case we must clear the last value of _edge which created the double as if user had queried _edge detected.
        #not if user queried edge detected and then checked if it was a double, clearing _edge has no effect since edge_detected already cleared it.
        self._edge = False
        return self._double

    def cleanup(self):
        GPIO.remove_event_detect(self.channel)

    def avg_value(self):  #this is not used currently
        """ A better way to check value during debounce.
        but since call back runs in another thread - this keeps the thread busy for the duration of the debounce
        as opposed to the time.sleep() approach - which releases the python GIL.
        in an application where real time behavior is not important - this is better method
        """
        t=time.perf_counter()
        values=[]
        while time.perf_counter()-t < self.hardware_debounce:
            values.append(GPIO.input(self.channel))
        x=sum(values)/len(values)
        return x

'''
LED are GPIO outputs - and cannot be provided with defaults because we do not know
what hardware is connected to the pins on a unitialized RPi 
    (setting a pin high that is somehow connected to gnd would likely destroy the RPi GPIO)
instead - the code is written to only output something if the LED or 7-segments are initialized
'''

class Single_LED:
    def __init__(self, bcm_pin_number=0):
        self.pin = bcm_pin_number
        if self.pin>0:
            GPIO.setmode(GPIO.BCM)
            #GPIO.setwarnings(False)
            GPIO.setup(self.pin,GPIO.OUT)
            self.set(0)

    def set(self,light: int):
        if self.pin>0:
            GPIO.output(self.pin,light)

    @property
    def value(self):
        return GPIO.input(self.pin)

    
class Seven_Segment_LED:
    def __init__(self,config_map={},bcm_pin_list = [],bcm_pin_decimal_point = 0):
        '''bcm_pin_list must have 7 pins in order of segment A to G
                   _  (top segment is A)
                F |_| B
                E |_| C   note: G is middle segment
                   D
        or use the config_map from configparser (from an ini file)
            which must label the pins in the .ini file in [GPIO] section as:
                segment_a_pin_7, segment_b_pin_6, segment_c_pin_4, segment_d_pin_2,  
                segment_e_pin_1, segment_f_pin_9, segment_g_pin_10'])]
        '''
        self.initialized = True
        self.segments = []
        self.digits=[(1,1,1,1,1,1,0),(0,1,1,0,0,0,0),(1,1,0,1,1,0,1),(1,1,1,1,0,0,1),(0,1,1,0,0,1,1),
                        (1,0,1,1,0,1,1),(1,0,1,1,1,1,1),(1,1,1,0,0,0,0),(1,1,1,1,1,1,1),(1,1,1,0,0,1,1)]  #0 to 9 in order
        if 'GPIO' in config_map:
            self.initialize_segment(config_map)
        elif len(bcm_pin_list) == 7:
            self.segments = bcm_pin_list
            self.decimal_point = bcm_pin_decimal_point
        if len(self.segments) == 7:
            GPIO.setmode(GPIO.BCM)
            GPIO.setwarnings(True)
            GPIO.setup(self.segments,GPIO.OUT)    
            GPIO.setup(self.decimal_point,GPIO.OUT)
            self.initialized = True
            self.segment_off()
            


        
    def initialize_segment(self,config_map):
        
        try:
            _gpio = config_map['GPIO']
            self.decimal_point = int(_gpio['segment_dp_pin_5'])
            self.segments = [ int(_gpio['segment_a_pin_7']),int(_gpio['segment_b_pin_6']), 
                                int(_gpio['segment_c_pin_4']), int(_gpio['segment_d_pin_2']), 
                                int(_gpio['segment_e_pin_1']),  int(_gpio['segment_f_pin_9']), 
                                int(_gpio['segment_g_pin_10'])]
            mLOG.log(f'initialized LED Segment: {self.segments}, decimal point is pin {self.decimal_point}',level=mLOG.DEV)
        except Exception as e:
            mLOG.log(f'exception: {e}  was handled  - error not raised: {traceback.format_exc()}',level=mLOG.CRITICAL,
                     identifier=self.__class__.__name__)

    def segment_off(self):
        if self.initialized:
            GPIO.output(self.segments,(0,0,0,0,0,0,0))  #turn-off all anodes
            GPIO.output(self.decimal_point,0)

    def display_digit(self,digit):
        if self.initialized:
            if digit<0:
                GPIO.output(self.segments,(0,0,0,0,0,0,1)) # displays an hyphen (segment G only)
            else:
                if digit>9:
                    digit=9
                GPIO.output(self.segments,self.digits[digit])
    
    def set_decimal(self,light):
        if self.initialized:
            GPIO.output(self.decimal_point,light)






class User_Input:
    '''For Looper, user input on the pedal are switches, which make use of ButtonPoll and/or ButtonEdgeDetect.
        the signal method to detect ctrl-c user quit via keyboard (when debuging) is also here'''
    def __init__(self,config_map={}):
        #This section is hard coded defaults for GPIO pins - switches
        self._run_gpio = 3
        self._rec_gpio = 20
        #This reads .ini file to get pin values of buttons
        self.initialize_SW(config_map)
        #now initialize button objects
        self.start_button = ButtonEdgeDetect(self._rec_gpio,GPIO.RISING)  #wire switch to GPIO with internal pull down, open = 0V, psuh/closed is 3.3V
        self.run_button = ButtonPoll(self._run_gpio)  # wire switch so off/edit - middle position  = high (3.3V), togled closed-run = low
        self.graceful_quit_requested = False
        self.set_up_signal_handling()    

    def set_up_signal_handling(self):
        signal.signal(signal.SIGINT, self.graceful_quit)
        signal.signal(signal.SIGTSTP, self.graceful_quit)
        signal.signal(signal.SIGTERM, self.graceful_quit)

    def graceful_quit(self,signum,frame):
        mLOG.log('received signal to quit',level=mLOG.DEV)
        self.graceful_quit_requested=True
    
    def initialize_SW(self,config_map):
        GPIO.setmode(GPIO.BCM)
        GPIO.setwarnings(False)
        try:
            _gpio = config_map['GPIO']
            self._run_gpio = int(_gpio['run_edit_switch'])
            self._rec_gpio = int(_gpio['play_rec_stop_switch'])
            mLOG.log(f'initialized switches: rec is pin {self._rec_gpio}, run/edit is pin {self._run_gpio}',level=mLOG.DEV)
        except Exception as e:
            mLOG.log(f'Exception Reading .ini file - switches: {e} - default values will be used',level=mLOG.CRITICAL,
                        identifier=self.__class__.__name__)

    def check_for_button_input(self):
        '''this returns True if a click (or double_click) on the buttons was detected
            It does not return the value of the button'''
        start=self.start_button.edge_detected
        double_stomp = self.start_button.isDouble
        run = self.run_button.check()
        return(start,double_stomp,run)

    @property
    def run_button_value(self):
        return self.run_button.value

    @property
    def start_button_value(self):
        return self.start_button.value

    @property
    def start_button_last_edge_info(self):
        '''
        return a tupple (type of edge,time)
         where type of edge is either GPIO.RISING or GPIO.FALLING, 
         and time is the time.perfcounter() value at the moment this last edge was detected
        '''
        return  self.start_button.last_edge
   
    def close_it(self):
        mLOG.log('User_Ouput is closing  buttons')
        self.start_button.cleanup()
        self.run_button.cleanup()

class User_Output:
    '''user output is the way Looper pedal communicates with user, which in the current iteration
    is one 7-segment LED and two single LED (red, green)'''

    def __init__(self,config_map={}):
        try:
            _gpio = config_map['GPIO']
            self._edit_mode = Single_LED(int(_gpio['LED_green']))  #green LED
            self._looper_record = Single_LED(int(_gpio['LED_red']))  #red LED
            self.display = Seven_Segment_LED(config_map)
        except Exception as e:
            mLOG.log(f'exception: {e}  error is raised: {traceback.format_exc()}',level=mLOG.CRITICAL,
                     identifier=self.__class__.__name__)
            raise
        self.current=-1 #holds current segment lit - for looping indicator
        self.divisor=0  #holds loop_length/ 10 = increments of loop for each segment displayed


    
    def loop_reset(self,loop_length=0):
        self.divisor = loop_length/10
        self.current = -1
        self.display.segment_off()

    def loop(self,cursor):
        try: 
            "this gives a number between 0 and 9 inclusive of where the cursor is at"
            position = min(9,max(0,int((cursor+1)//self.divisor)))
            if position!=self.current:
                self.current=position
                self.display.segment_off()
                #since display is counting backward - need to light 9-position digit
                self.display.display_digit(9-position)
        except ZeroDivisionError: 
            mLOG.log("loop divisor was not initialized - setting to loop length 1000 until you fix this",
                                level=mLOG.CRITICAL, identifier=self.__class__.__name__)
            self.divisor = 100
            self.current=-1

    def display_digit(self,digit):
       self.display.display_digit(digit)

    def edit_mode(self,light):
        self._edit_mode.set(light)

    def looper_rec(self,light):
        self._looper_record.set(light)

    def close_it(self):
        self.edit_mode(0)
        self.looper_rec(0)
        self.display.segment_off
        self.display.set_decimal(0)
        GPIO.cleanup()

def main():
    
    GPIO.cleanup()




if __name__ == "__main__":
    main()