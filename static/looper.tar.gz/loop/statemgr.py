import RPi.GPIO as GPIO
import time
from my_logger.my_logger import mLOG
import traceback
import signal
from  multiprocessing import Pipe
#import pickle


class Status:
    cursor=0
    longest = 0
    track_count = 0

    class Bluetooth:  # contains variable set byt received bluetooth message from iphone app
        song_name = ''
        volume = (-1,-1)
        track_count =0

class ButtonPoll:
    """this class is built on the premise that the application that needs to read the button is polling the button value regularly, and to some extent
    relatively quickly (1-25 ms period).  this is the case for the looper app at 5 ms or so.
    the class reads the button value every time it is polled and looks for a  multiple n reads to be the same before reporting a new stable value.  
    the consecutive values are averaged over the last n reads - and the stable value is reported as 1 if the average is 0.5 or above, or 0 if below.
    to arm the system - the initial value is reported until n reads have occured.
    the check method returns whether a change of state has occured since the last poll.  if so application should 
    query the stable_state variable to find out the current value (and infer the transition that occured).
    NOTE: This class should be used for relatively slow moving switches/buttons and reactions to these that are not very time sensitive:
          if the switch transition is moving faster than n times the poll period - the transition will be missed 
    """
    def __init__(self, channel, sample_count = 5, pullup=None, GPIO_mode = GPIO.BCM):  #bouncetime is for GPIO module - in milliseconds
        GPIO.setmode(GPIO_mode)
        GPIO.setwarnings(False)
        #default of RPi is 1-8 have Ppull up and the rest have pull_down - so unless user has specified a value simply enforce default.
        if (pullup is None) or not(pullup==GPIO.PUD_UP or pullup==GPIO.PUD_DOWN):
            if channel<=8:
                pullup=GPIO.PUD_UP
            else:
                pullup=GPIO.PUD_DOWN
        GPIO.setup(channel, GPIO.IN,pull_up_down=pullup)
        self.channel = channel
        self.sample_count = sample_count

        self._stable_state = GPIO.input(self.channel)  # it is assumed that when initializing the class, buttons are not being manipulated - i.e value is stable
        self.values = []

    def check(self):
        pin_value=GPIO.input(self.channel)
        if len(self.values)<self.sample_count:
            self.values.append(pin_value)
        else:
            self.values.pop(0)
            self.values.append(pin_value)
            avg = sum(self.values)/self.sample_count
            avgLevel = (avg >=0.5)  #true - or 1 - if average is greater or equal than 0.5
            if avgLevel != self._stable_state:
                self._stable_state = avgLevel
                return True

        return False

    @property
    def value(self):
        return self._stable_state

    def cleanup(self):
        pass
            
            




class ButtonEdgeDetect:
    """
    Detects a rising or falling edge of a button (typically push and hold button but also works for toggle)
    class always detects both edges, and applies the standard GPIO debouncer as soon as an edge occurs.
    It then filters for the rising or falling edge by checking the actual value of the button after a suitable smaller debounce time
    (which should be tested against the physical button being used).
    this class corrects the problem of detecting a rising or falling edge using the standard edge_detect function of GPIO - 
    which always detect both edges because if looking for falling edge - the rising edge is not debounced - and vice-versa  

    Latching of Detection:
    The class latches the detection of the requested type of edge (GPIO.RISING / FALLING / BOTH) in the variable self._edge
    which is only reset when it is read via the property edge_detected.

    Always recording both edge transitions:
    Internally, it detects every edge that occurs (after the GPIO bouncetime ) and always stores 
    the last rising edge and the time.perf_counter in the  tupple self.last_edge.  This should be used carefully:
        - if a switch is set to detect GPIO.RISING - the push of a button (normally_off) will set _edge to True and record GPIO.RISING / time in last_edge
        - momentarily later when the button is released, lats_edge will be updated to read GPIO/FALLING / time of release - even though _edge has not be read yet.
        - one usage of this is for timing length of a push-down:
            * set edge detection to GPIO.RISING (assuming button pushed = high)
            * check edge detection via property edge_detected.
            * read last_edge tupple: if edge == self._type_of_edge, button is still being held down.  
               a time-sleep loop can be started that checks last_edge until it changes - and for accuracy we can use the time stamp.

    double_click/stomp detection:
        NOTE: for the following to work, the edge detection must be set to RSING or FALLING - but not BOTH
              If set to BOTH the following is not run
        How it works:|
        The callback stores the time of a click that match the type_of_edge detection requested in self._edge_time.
        when the next click (of the same type of edge) is detected - it compares its click time to the previous and decides if a double stump occured
        if a double stomp occured:
            - it sets _double to True
            - it sets _edge_time to 0  
        note: if another click occurs after this, _double is reset to False, so it is possible that the calling function does not see it if it does not check
              (this is not a problem for the looper since it is checking state after each sample is processed = 5 ms intervals)

    """

    DOUBLE_MAX_TIME = 0.5  # constant in second within which a double stomp is detected and called S
    #note - must be larger than hardware debounce otherwise will me missed
    #sample period is 5.8 ms - each 0.1 seconds = about 17 samples  (0.5s = 86 samples)
    # these state correspond to the name of the methods of the Looper class of the looper.
    

    def __init__(self, channel, detect, pullup=None, bouncetime=50, hardware_debounce = 0.01, GPIO_mode = GPIO.BCM):  #bouncetime is for GPIO module - in milliseconds
        self.hardware_debounce = hardware_debounce  #in seconds - for time.sleep
        GPIO.setmode(GPIO_mode)
        GPIO.setwarnings(False)
        #default of RPi is 1-8 have Ppull up and the rest have pull_down - so unless user has specified a value simply enforce default.
        if (pullup is None) or not(pullup==GPIO.PUD_UP or pullup==GPIO.PUD_DOWN):
            if channel<=8:
                pullup=GPIO.PUD_UP
            else:
                pullup=GPIO.PUD_DOWN
        GPIO.setup(channel, GPIO.IN,pull_up_down=pullup)
        GPIO.add_event_detect(channel, GPIO.BOTH,callback=self._edge_callback, bouncetime=bouncetime)

        self.last_edge = (None,0)  # (RISING or FALLING, time.perfcounter() at which edge occured) - used for button push & hold detection.
                                   # always recorded even if class does not report a trigger on edge.
        self._edge_time = 0  # keeps the time (form last_edge) at which the _type_of_edge was detected  (used for double stomp detection)
        self._double = False  # True if double stomp has occured

        self._edge = False   # True if _type_of_edge (detect) is detected - latched until read
        self._type_of_edge = detect
        self.channel = channel

    def _edge_callback(self,channel):
        t=time.perf_counter()
        time.sleep(self.hardware_debounce)  # switch debounce / check against the physical switch if it's value is enough to debounce the switch
        
        try:
            #determine which type of edge and record its time
            if GPIO.input(self.channel)==1:
                self.last_edge = (GPIO.RISING,t)
            else:
                self.last_edge = (GPIO.FALLING,t)

            #only set _edge to True if it matches the one we wish to detect
            if self._type_of_edge == GPIO.BOTH:
                self._edge=True
            elif self._type_of_edge == self.last_edge[0]:
                self._edge=True
                #check for double click/stomp:
                if (t-self._edge_time) < self.DOUBLE_MAX_TIME:
                    self._double = True
                    self._edge_time =0
                else:
                    self._double = False
                    self._edge_time = t
            
        except RuntimeError:
            # when exiting looper with shutdown button, GPIO looses initialization then stop button rises - and this callback
            # is called, and GPIO raise error: Please set pin numbering mode using GPIO.setmode(GPIO.BOARD) or GPIO.setmode(GPIO.BCM)
            mLOG.log(f'RunTime error occured: {traceback.format_exc()}', level=mLOG.CRITICAL)


    @property
    def edge_detected(self):
        #_edge remains True until it is read - so multiple hit of the button cannot be detected between reads
        x=self._edge
        self._edge = False
        return x

    @property
    def value(self):
        return (GPIO.input(self.channel))

    @property
    def isDouble(self):
        # when querying if a button press is double, the user may not have querying _edge, such as in waiting for a double before acting.
        #in this case we must clear the last value of _edge which created the double as if user had queried _edge detected.
        #not if user queried edge detected and then checked if it was a double, clearing _edge has no effect since edge_detected already cleared it.
        self._edge = False
        return self._double

    def cleanup(self):
        GPIO.remove_event_detect(self.channel)

    def avg_value(self):  #this is not used currently
        """ A better way to check value during debounce.
        but since call back runs in another thread - this keeps the thread busy for the duration of the debounce
        as opposed to the time.sleep() approach - which releases the python GIL.
        in an application where real time behavior is not important - this is better method
        """
        t=time.perf_counter()
        values=[]
        while time.perf_counter()-t < self.hardware_debounce:
            values.append(GPIO.input(self.channel))
        x=sum(values)/len(values)
        return x


class StateMgr:
    """
    current implementation:
    if run switch is in run mode (0V = low):
        if idle, start button starts playing the mixed down loop, unless there is not track - then it jumps into base recording
        if in play loop mode, start button starts overdub recording 
        start button stops recording if in base recording or overdub and returns to play loop at that point (cursor) in the loop
        while in play mode - a double stomp on start goes to idle (stops playing the loop but user can hear instruments live)
        note: in case user double stomps while in recording mode - it is handled ha a stop recording.
        but a double stomp from idle is handled has two separate start button events: the first goes to play mode, the second goes into overdub.
    if run switch is in off/edit mode (3.3V = high)
        when flicked to off - it puts looper in idle mode.
        if start is tapped once: last track is deleted
        if start is tapped twice (double stomp) - the deleted track bearing the number of the next track is brought back to looper
            NOTE:   if user deletes a track(for example track3), then records a new track 3, then double stomp starts while in edit mode - 
                    it will bring back the dleted track #4 if it exists.  But the deleted track 3 is no longer available to the looper 
                    (although it could be available to an iphone app). furhtermore if the user then deletes this new recorded track 3, 
                    it will overwrite the deleted track 3 that was there before).
        if start is pushed and held 3 seconds - the looper prgram ends and the RPi shuts down.

    note: for previous implementation of del button state mgmt - look on GIT for version before Aug 7, 2021
    """
    IDLE = 0
    PLAY_LOOP = 1
    OVERDUB = 2
    BASE_RECORDING = 3
    QUIT = 4

    NOACTION=0
    DELETE_LAST = 10
    REINSTATE_LAST = 20
    DISCARD_RECORDING = 30
    ON_PLAY_GO_IDLE = 40

    def __init__(self):
            #This pipe used to communicate messages received from Bluetooth Service back to main process of Looper
            self.fromBTrec,self.BTsend = Pipe(False) 
            #This pipe used to communicate messages to be sent from Looper main proces to Bluetooth
            self.fromLPrec,self.LPsend = Pipe(False)
            self.track_volume = (-1,-1)
            self.track_count = -1  #this forces a send of track_count to Bluetooth upon startup

            self.start_button = ButtonEdgeDetect(20,GPIO.RISING)  #wire switch to GPIO with internal pull down, open = 0V, psuh/closed is 3.3V
            self.run_button = ButtonPoll(3)  # wire switch so off/edit - middle position  = high (3.3V), togled closed-run = low
            self.graceful_quit_requested = False
            self.state = 0  # contains the current state upon entry into manage method and is changed to the next required state
                            # as decided by manager method based on user button presses. 
                            # It is accessible to Looper class run method to decide what state method to use
            self._previous_state = 0
            self.action_requested = self.NOACTION
            self.test_time =0
            self.testing = False

            self.incoming_controls = [] # used for everything except volume changes
            self.incoming_volumes = []  #used only for incoming volume changes
            self.outgoing_msg = []  #used for message from looper to send to bluetooth
            self.signal_handling()

    
    def signal_handling(self):
        signal.signal(signal.SIGINT, self.graceful_quit)
        signal.signal(signal.SIGTSTP, self.graceful_quit)
        signal.signal(signal.SIGTERM, self.graceful_quit)

    def graceful_quit(self,signum,frame):
        self.graceful_quit_requested=True


    #Note: method to check keyboard input has been removed (find it in version 0.1 or before if needed)
    # quiting the program without shuting down the RPi in VSCode or terminal mode is done via CTRL-C
    def check_kb_input(self):
        pass

    def check_for_input(self):
        if self.testing:
                x=self.test()
                return x
        else:
            start=self.start_button.edge_detected
            double_stomp = self.start_button.isDouble
            run = self.run_button.check()
            return(start,double_stomp,run)

    def close_it(self):
        mLOG.log('StateMgr is closing  button')
        self.start_button.cleanup()
        self.run_button.cleanup()

    def manage_bluetooth(self):
        while self.fromBTrec.poll():  #this checks if outer class as received any signals and put then in the pipe for Looper to read
            val = self.fromBTrec.recv()
            try:
                code = val[0]
                if code == 'V':
                    payload = val[1:].split(',')  
                    mLOG.log(f'received from bluetooth code={code};  volume payload={payload}')
                    self.incoming_volumes.append( (int(payload[0]),int(payload[1])) )
                else:
                    mLOG.log(f'received from bluetooth val={code}; payload={val[1:]}')
                    self.incoming_controls.append( (code, val[1:]) )
            except:
                mLOG.log(f'bluetooth message reception error -msg= {val}', level=mLOG.INFO)
                break
        #send:
        while len(self.outgoing_msg)>0:
            mLOG.log(f'sending Looper msg to BT_svc on pipe: {self.outgoing_msg[0]}')
            self.LPsend.send(self.outgoing_msg.pop(0))
            


    def manage(self,loops_exist=True):
        """
        list of states: 0:"idle"  1: "play_loop"  2:"overdub"  3:"base_recording  4:"quit" 
        the only other information that manager requires is whether there are loops already recorded or not,
        and this is only use in the idle state to decide whether the start button triggers a base recording (no loops yet)
        or goes to play_loop (there is at least one loop).  if looper is in any other state, loops_exist is ignored and can be safely left to its True default

        return flag:  True means either no events was received - keep doing what you were doing
                          False means user input was received  - and next (requested ) state was set-up. (in self.state)

        double stomp management (when start is pressed twice within a short amount of time)
        while in run mode:
            if user is in idle - existing tracks: the first stomp goes into play, the second stomp does into overdub (that is what user wants - not a double stomp)
            if user is in idle - no tracks: the first stomp goes into base recording, the second stomp must be ignored
            if user is in play mode: double stomp means go to idle.  the first stomp will go into overdub, so the double stomp will be detected while 
                                     in overdub, and the recording must be discarded and state must be set to idle
            if user is in overdub or base recording: the double stomp is not necessary but must be handled as a single stomp - which is to stop recording
                    and return to play mode.  the first stomp will have done that, and the second stomp will be detected while user is in play mode.
                    In this case the second stomp must be ignored (otherwise it will restart a recording)
        while in edit mode:
            if user stomps once - deleted the last track - but wait to confirm that a second stomp is not coming
            if user stomps twice - reinstate the last deleted track with the next number
            if user stomps once and hold 3 seconds: shut down looper and RPi
            
        """
        self.action_requested = self.NOACTION
        #check bluetooth first
        self.manage_bluetooth()

        #check if user stomped a switch:
        start, is_double, run = self.check_for_input()
            
        if not(start or run or self.graceful_quit_requested):
            #note - order above is important - list in order of events we want to handle first
            return True
        else: 
            mLOG.log(f'STATE on entry={self.state} ; start={start} ; double_stomp={is_double} run={run} ; signal_quit={self.graceful_quit_requested}')
        mLOG.log(f'edit button is {self.run_button.value}')
        if self.graceful_quit_requested:
            self.state=self.QUIT
            return False
        elif self.run_button.value == 0: 
            #transition from edit to run simply puts the looper in idle and run mode
            #unless start was recieved exactly at the same time as run (unlikely) - in which case
            #deal with start as if we were already in run mode (we will miss the update info).
            if run and (not start):
                self._previous_state=self.state
                self.state = self.IDLE
                return False
            if start:
                if self.state==self.IDLE: #this handles start - not need to check it since run and graceful quit is already taken care of
                    self._previous_state=self.state
                    if run:
                        self.state = self.IDLE
                        return False
                    if loops_exist:
                        self.state=self.PLAY_LOOP
                    else:
                        self.state=self.BASE_RECORDING
                    return False
                elif self.state==self.PLAY_LOOP:  
                    if is_double and (self._previous_state==self.BASE_RECORDING or self._previous_state==self.OVERDUB):
                        #user did a double stomp to stop recording - which was already handled by the first stomp - so ignore it and stay in play_loop
                            self._previous_state = self.state
                            return True
                    else: # this also handles a double stomp from idle that went to play_loop on first stomp and goes to overdub on second.
                        self._previous_state = self.state
                        self.state = self.OVERDUB
                        return False
                elif self.state==self.OVERDUB:
                    # if user was in play state, and doubled stomped, the first stomp will have started the overdubbing
                    # then 1/2 second later the double stomp is detected, so we need to get rid of the recording which was not meant to be nad go to idle
                    self._previous_state=self.state
                    if is_double:
                        self.action_requested = self.DISCARD_RECORDING
                        self.state = self.IDLE
                    else: # normal single stomp on start stops the recording
                        self.state =  self.PLAY_LOOP
                    return False
                elif self.state==self.BASE_RECORDING:  
                    # if user was in idle state, and doubled stomped, the first stomp will have started the base recording (assume no tracks existed)
                    # then 1/2 second later the double stomp is detected, this is ignored and the base recording continues
                    self._previous_state=self.state
                    if is_double:
                        return True
                    else:
                        self.state = self.PLAY_LOOP
                        return False
        elif self.run_button.value == 1:
            #logic - if run occurs we handle it and ignore start if a start occured at exactly the same time.
            if run: #user has just switched to edit mode
                if self.state >=self.OVERDUB:  #end recording - go to play loop to record last sample (like stop in run mode)
                    self._previous_state = self.PLAY_LOOP  #because we go from play_loop to idle within play_loop without coming back here.
                    self.state = self.PLAY_LOOP
                    self.action_requested = self.ON_PLAY_GO_IDLE  # tell play loop to store last sample and then exit to idle
                else: #either in idle or playLoop
                    self._previous_state = self.state
                    self.state = self.IDLE
                return False
            else:
                t = self.start_button.last_edge[1]
                self._previous_state = self.IDLE
                self.state=self.IDLE
                #first check if we get a double stump:
                time.sleep(self.start_button.DOUBLE_MAX_TIME+0.1)
                if self.start_button.isDouble:
                    mLOG.log('DOUBLE CLIK',level=mLOG.INFO)
                    self.action_requested = self.REINSTATE_LAST  # re-instate a deleted track
                    return False
                elif self.start_button.value==0: # check if user has already released the button - if so it's a quick single stomp
                    mLOG.log('SINGLE_CLICK',level=mLOG.INFO)
                    self.action_requested = self.DELETE_LAST  # delete last track 
                    return False   
                else:  #user is still holding the button
                    mLOG.log('HELD FOR QUIT',level=mLOG.INFO)   
                    ready_to_quit = True
                    while time.perf_counter()-t < 2.1:  #loop for up to 3 seconds to see if user is holding down button trying to exit looper/shutdown rpi
                        if self.start_button.value == 0:
                            #user has released button before 3 seconds - delete last track
                            self.action_requested = self.DELETE_LAST
                            ready_to_quit = False
                            return False
                        time.sleep(0.5)
                    if ready_to_quit:
                        self.state=self.QUIT
                        return False    
    def test(self):
        #start,double_stomp,run
        test_case = 2  
        if self.test_time==0:
            self.test_time = time.perf_counter()
        if test_case == 1:
            if time.perf_counter()-self.test_time > 3:
                if self.state == self.IDLE:
                    mLOG.log(f'TEST CASE # {1} - rec on last sample, exit in no keep zone with single click')
                    return(1,0,0)
                elif self.state == self.PLAY_LOOP:
                    if Status.cursor == Status.longest-1:
                        return(1,0,0)
                elif self.state == self.OVERDUB:
                    if Status.cursor == 100:
                        return (1,0,0) 
            return (0,0,0)
        if test_case == 2:
            if time.perf_counter()-self.test_time > 3:
                if self.state == self.IDLE:
                    mLOG.log(f'TEST CASE # {2} - rec on last sample, exit in no keep zone with double click')
                    return(1,0,0)
                elif self.state == self.PLAY_LOOP:
                    if Status.cursor == Status.longest-1:
                        return(1,0,0)
                elif self.state == self.OVERDUB:
                    if Status.cursor == 70:
                        self.test_time=0
                        return (1,1,0) # clicks within 86 samples will appear has double click
            
            return (0,0,0)
        return (0,0,0)





 

def main():
    mgr = StateMgr()
    mgr.state=0
    loops=False
    while not mgr.graceful_quit_requested:
        if not mgr.manage(loops):
            print(f'    **** previous state={mgr._previous_state} ; returned state={mgr.state} ; action requested={mgr.action_requested}')
            if mgr.state == mgr.BASE_RECORDING:
                loops = True
            print('- - - - - - - - - - - - - - - - - - - - - ')
        time.sleep(0.005)
    mgr.close_it()
    GPIO.cleanup()




if __name__ == "__main__":
    main()