"""
anode is pos side of diode 
cathode is neg side - grounded here
RGB - cathode to ground,
R,G,B via 330 Homs resitor
RED = GPIO 12  - for record indicator
Green = GPIO 16 - for edit mode indicator (used to be play indicator)


7-segment: 21,19,13,6,5,22,27
0-A = GPIO 21  (changed from 26 - because 26 is not easily accessible from the pi hat breadboard)
1-B = GPIO 19
2-C = GPIO 13
3-D = GPIO 6
4-E = GPIO 5
5-F = GPIO 22
6-G = GPIO  27

   A
   _
F |_| B
E |_| C   note: G is middle segment
   D
 
0: A-B-C-D-E-F: 1,1,1,1,1,1,0
1: B-C : 0,1,1,0,0,0,0
2: A-B-D-E-G: 1,1,0,1,1,0,1
3: A-B-C-D-G: 1,1,1,1,0,0,1
4: B-C-F-G: 0,1,1,0,0,1,1
5: A-C-D-F-G: 1,0,1,1,0,1,1
6: A-C-D-E-F-G: 1,0,1,1,1,1,1
7:A-B-C: 1,1,1,0,0,0,0
8: A-B-C-D-E-F-G-: 1,1,1,1,1,1,1
9: A-B-C-F-G: 1,1,1,0,0,1,1
-; G : 0,0,0,0,0,0,1

list of 0,1,2,3,4,5,6,7,8,9:
[(1,1,1,1,1,1,0),(0,1,1,0,0,0,0),(1,1,01,1,0,1),(1,1,1,1,0,0,1),(0,1,1,0,0,1,1),
(1,0,1,1,0,1,1),(1,0,1,1,1,1,1),(1,1,1,0,0,0,0),(1,1,1,1,1,1,1),(1,1,1,0,0,1,1)]

LOOP:
0-L: (0,0,0,1,1,1,0)
1-2 -O: (1,1,1,1,1,1,0)
3-P: (1,1,0,0,1,1,1)


decimal "dot: - gpio 25
"""
#import time
import multiprocessing
from my_logger.my_logger import mLOG
import RPi.GPIO as GPIO
import time

class LED:
    def __init__(self,config_map={}):
        
        # this section is the hard coded defaults if .ini file does not yield correct info
        self._looper_has_tracks = 25 # decimal dot pn 7 segment display
        self._edit_mode = 16  # using green led to display when in edit mode
        self._looper_record = 12   #red from RGB LED
        self.segments=[21,19,13,6,5,22,27]

        #normally - read gpio config from .ini file - otherwise looper may be unusable
        self.initialize_LED(config_map)

        self.anodes=[self._looper_record,self._edit_mode]
        #       anodes is only used to turn off all leds
        self.digits=[(1,1,1,1,1,1,0),(0,1,1,0,0,0,0),(1,1,0,1,1,0,1),(1,1,1,1,0,0,1),(0,1,1,0,0,1,1),
                        (1,0,1,1,0,1,1),(1,0,1,1,1,1,1),(1,1,1,0,0,0,0),(1,1,1,1,1,1,1),(1,1,1,0,0,1,1)]  #0 to 9 in order
        
        self.current=-1 #holds current segment lit - for looping indicator
        self.divisor=0  #holds loop_length/ 7 = increments of loop for each segment displayed
        self.loop_digits=True  #True if showing countdown 9 to 0 instead of segments)

        GPIO.setup(self.segments,GPIO.OUT)   
        GPIO.setup(self.anodes,GPIO.OUT)   
        GPIO.setup(self._looper_has_tracks,GPIO.OUT) 
        self.led_off()
        self.segment_off()

    def initialize_LED(self,config_map):
        GPIO.setmode(GPIO.BCM)
        GPIO.setwarnings(False)
        try:
            _gpio = config_map['GPIO']
            self._edit_mode = int(_gpio['LED_green'])
            self._looper_record = int(_gpio['LED_red'])
            self._looper_has_tracks = int(_gpio['segment_dp_pin_5'])
            self.segments = [ int(_gpio['segment_a_pin_7']),int(_gpio['segment_b_pin_6']), 
                                int(_gpio['segment_c_pin_4']), int(_gpio['segment_d_pin_2']), 
                                int(_gpio['segment_e_pin_1']),  int(_gpio['segment_f_pin_9']), 
                                int(_gpio['segment_g_pin_10'])]
            mLOG.log(f'initialized LEDs: green is pin {self._edit_mode}, red is pin {self._looper_record}',level=mLOG.DEV)
            mLOG.log(f'initialized LED Segment: {self.segments}, decimal point is pin {self._looper_has_tracks}',level=mLOG.DEV)
        except Exception as e:
            mLOG.log(f'Exception Reading .ini file - LEDs: {e} - default values will be used',level=mLOG.CRITICAL,
                     identifier=self.__class__.__name__)
       
        
    def led_off(self):
        GPIO.output(self.anodes,(0,0))  #turn-off all anodes

    def segment_off(self):
        GPIO.output(self.segments,(0,0,0,0,0,0,0))  #turn-off all anodes

    def loop_reset(self,loop_length=0):
        if self.loop_digits:
            self.divisor = loop_length/10
        else:
            self.divisor = loop_length/7
        self.current = -1
        self.segment_off()

    def light(self,what):
        if self.loop_digits:
            GPIO.output(self.segments,self.digits[9-what])
        else:
            GPIO.output(self.segments[what],1)

    def display_digit(self,digit):
        if digit<0:
            GPIO.output(self.segments,(0,0,0,0,0,0,1))
        else:
            if digit>9:
                digit=9
            GPIO.output(self.segments,self.digits[digit])

    def display_pattern(self,pattern):
        GPIO.output(self.segments,pattern)



    def loop(self,cursor):
        try: 
            segment = int((cursor+1)//self.divisor)
            if segment!=self.current:
                self.current=segment
                self.segment_off()
                self.light(segment)
        except ZeroDivisionError: 
            mLOG.log("loop divisor was not initialized - setting to 1000 until you fix this",
                                level=mLOG.CRITICAL, identifier=self.__class__.__name__)
            self.divisor = 1000/7
            self.current=-1

    
    def has_tracks(self,light):
        # True: user has recorded track and mixed them to mix_down
        GPIO.output(self._looper_has_tracks,light)

    def edit_mode(self,light):
        GPIO.output(self._edit_mode,light)

    def looper_rec(self,light):
        GPIO.output(self._looper_record,light)

    def close_it(self):
        self.led_off()
        self.segment_off()
        self.has_tracks(False)

'''     
class Flash(multiprocessing.Process):
    """
    note: this calls LED class - which is also called in main process.  
    Initializing the pi twice does not appear to have any negative effect
    instantiate this class in main app and start it
    communicate with it via the pipe passed to it.
    send:
        - a tupple (string, digit) - to display the digit (no flash) - if int>9 then it flashes 9 / currently string value is ignored
            if the string = 'OFF" - segments are turned off, anything else flashed digit.
        - a positive integer (not in a tupple) to flash the number (if number > 9 then flash 9)
        - a negative number - to start displaying a random sequence
        - any message will stop random or flashing and clear the segment - if none of the above, the message is discarded.
                usage: it is a good idea to send a simple string 'stop' - in order to stop the flashing and clear the segment.

    """
    def __init__(self,pipe_rec):
        multiprocessing.Process.__init__(self)
        self.daemon = True
        self.receive=pipe_rec
        self.LED=LED()
        

    def flash(self,digit):
        """ this flashes the digit on for delay then off for delay.
        after it has turned off the segment, it checks to see if there is another command in the pipe
        if there is not in continues in this flashing loop until a command will appear in the pipe.
        if there is a command - it returns control to to main run loop with the value of the command in the pipe.
        note: since it does this after it has turned-off the segment, the flashing is ended 
        when a command appears in the pipe.  If run loop does not return here - flashing will stay off
        """
        if digit>9:
                digit = 9
        delay=0.4
        while True:
            self.LED.display_digit(digit)
            time.sleep(delay)
            self.LED.segment_off()
            x=self.get_next()
            if not (x is False):  #(this is different than if not x - which woul return True if x=(),{} or 0)
                return x
            time.sleep(delay)

    def random(self):
        delay=0.03
        loop=[(0,0,0,0,0,0,1),(1,1,0,0,0,0,0),(0,0,0,0,0,0,1),(0,0,0,1,1,0,0),(0,0,0,0,0,0,1),(0,1,0,0,1,0,0),(0,0,1,0,0,1,0)]

        while True:
            for i in loop:
                GPIO.output(self.LED.segments,i)
                time.sleep(delay)
                self.LED.segment_off()
                x=self.get_next()
                if not (x is False):  #(this is different than if not x - which woul return True if x=(),{} or 0)
                    return x
                time.sleep(delay)

    def loop_word(self):
        word= [(0,0,0,1,1,1,0),(1,1,1,1,1,1,0),(1,1,1,1,1,1,0),(1,1,0,0,1,1,1)]
        for letter in word:
            self.LED.display_pattern(letter)
            time.sleep(0.5)
            self.LED.segment_off()
            x=self.get_next()
            if not (x is False):  #(this is different than if not x - which woul return True if x=(),{} or 0)
                return x
            time.sleep(0.3)



    def get_next(self):
        """ returns whatever message is next in the pipe at the time of the call
        or returns False if nothing is in the pipe - this is non-blocking"""
        if self.receive.poll():  #check pipe conn for samples - does not block - returns immediately True or False
            try:
                data = self.receive.recv()
                mLOG.log(f'RGB received= {data}')
                return data
            except EOFError:
                mLOG.log('Flash class error - something has closed the pipe - need to reset..',
                                level=mLOG.CRITICAL, identifier=self.__class__.__name__)
                #create an event that request main to reset GrabAudio (meanwhile it should play nothing - maybe a "reset" state?)
                return 'QUIT'
        return False
    


    def run(self):
        mLOG.log(f'flash pid {self.pid}')
        new_x=False
        while True:
                if new_x is not False:
                    x=new_x
                    new_x=False
                else:
                    time.sleep(0.005)
                    x=self.get_next()

                if type(x) == tuple:
                    if x[0] == 'OFF':
                        self.LED.segment_off()
                    else:
                        self.LED.display_digit(x[1])
                    new_x=False
                elif type(x)==int:
                    if x>=0:
                        new_x=self.flash(x)
                    else:
                        new_x=self.random()
                elif x=='LOOP':
                    new_x=self.loop_word()
                elif x=='QUIT':
                    mLOG.log('flash received QUIT')
                    break
                #put anything else in pipe and it stops flashing silently
                

        mLOG.log('Flash is done...',level=mLOG.INFO, identifier=self.__class__.__name__)

        
'''




"""
def main():
    
    led = LED()
    led.has_tracks(1)
    led1=LED()
    input()
    led.has_tracks(0)
    GPIO.cleanup()

    
    flash_rec,flash_send=multiprocessing.Pipe(False)
    flash=Flash(flash_rec)
    flash.start()
    flash_send.send(5)
    print('started flasher')
    led=LED()
    for i in range(20):
        for seg in led.segments:
                GPIO.output(seg,1)
                time.sleep(0.1)
                led.segment_off()
    led.has_tracks(1)
    input()
    led.has_tracks(0)
    flash_send.send(('tracks',2))
    input()
    flash_send.send('QUIT')
    flash.join()
    
    GPIO.cleanup()
    
    flash_rec,flash_send=multiprocessing.Pipe(False)
    led=LED()
    flash=Flash(flash_rec)
    flash.start()
    flash_send.send(('tracks',2))
    input()
    flash_send.send(-1)
    input()
    flash_send.send(('tracks',2))
    input()
    flash_send.send(-1)
    input()
    flash_send.send('QUIT')
    flash.join()


    GPIO.cleanup()
    

if __name__ == "__main__":
    main()
"""

