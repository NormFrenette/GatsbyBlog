
import multiprocessing
import dbus
import dbus.service
import dbus.mainloop.glib
from gi.repository import GLib
#from random import randint
from time import sleep
import traceback
import pickle
from my_logger.my_logger import mLOG

NOTIFY_TIMEOUT = 1000

class Blue:
    adapter_name = ''
    bus = None
    adapter_obj = None

    @staticmethod
    def set_adapter():
        Blue.bus = dbus.SystemBus()
        obj = Blue.bus.get_object('org.bluez','/')
        obj_interface=dbus.Interface(obj,'org.freedesktop.DBus.ObjectManager')
        all = obj_interface.GetManagedObjects()
        for item in all.items(): #this gives a list of all bluez objects
            if 'org.bluez.Adapter1' in item[1].keys():
                #this the bluez adapter1 object that we need
                Blue.adapter_name = item[0]
                Blue.adapter_obj = Blue.bus.get_object('org.bluez',Blue.adapter_name)
                #turn_on the adapter - to make sure (on rpi it may already be turned on)
                props = dbus.Interface(Blue.adapter_obj,'org.freedesktop.DBus.Properties')
                props.Set("org.bluez.Adapter1", "Powered", dbus.Boolean(1))
                break

    @staticmethod
    def adv_mgr(): 
        return dbus.Interface(Blue.adapter_obj,'org.bluez.LEAdvertisingManager1')

    @staticmethod
    def gatt_mgr():
        return dbus.Interface(Blue.adapter_obj,'org.bluez.GattManager1')

class Advertise(dbus.service.Object):

    def __init__(self, index):
        self.properties = dict()
        self.properties["Type"] = dbus.String("peripheral")
        self.properties["ServiceUUIDs"] = dbus.Array([UUID_LOOPER],signature='s')
        self.properties["IncludeTxPower"] = dbus.Boolean(True)
        self.properties["LocalName"] = dbus.String("LoopCtl")

        self.path = "/org/bluez/advertise" + str(index)
        dbus.service.Object.__init__(self, Blue.bus, self.path)


    def get_properties(self):
        return {"org.bluez.LEAdvertisement1": self.properties}

    def get_path(self):
        return dbus.ObjectPath(self.path)

    @dbus.service.method("org.freedesktop.DBus.Properties", in_signature="s", out_signature="a{sv}")
    def GetAll(self, interface):
        return self.get_properties()["org.bluez.LEAdvertisement1"]

    @dbus.service.method("org.bluez.LEAdvertisement1", in_signature='', out_signature='')
    def Release(self):
        mLOG.log('%s: Released!' % self.path)


    def register_ad_callback(self):
        mLOG.log("GATT advertisement registered")

    def register_ad_error_callback(self,error):
        mLOG.log(f"Failed to register GATT advertisement {error}")

    def register(self):
        #ad_manager = dbus.Interface(bus.get_object(BLUEZ_SERVICE_NAME, adapter),LE_ADVERTISING_MANAGER_IFACE)
        ad_manager = Blue.adv_mgr()            
        ad_manager.RegisterAdvertisement(self.get_path(), {},
                                     reply_handler=self.register_ad_callback,
                                     error_handler=self.register_ad_error_callback)

class Application(dbus.service.Object):
    def __init__(self):
        self.path = "/"
        self.services = []
        self.next_index = 0
        dbus.service.Object.__init__(self, Blue.bus, self.path)

    def get_path(self):
        return dbus.ObjectPath(self.path)

    def add_service(self, service):
        self.services.append(service)

    @dbus.service.method("org.freedesktop.DBus.ObjectManager", out_signature = "a{oa{sa{sv}}}")
    def GetManagedObjects(self):
        response = {}
        for service in self.services:
            response[service.get_path()] = service.get_properties()
            chrcs = service.get_characteristics()
            for chrc in chrcs:
                response[chrc.get_path()] = chrc.get_properties()
                descs = chrc.get_descriptors()
                for desc in descs:
                    response[desc.get_path()] = desc.get_properties()
        return response

    def register_app_callback(self):
        mLOG.log("GATT application registered")

    def register_app_error_callback(self, error):
        mLOG.log("Failed to register application: " + str(error))

    def register(self):
        #adapter = BleTools.find_adapter(self.bus)
        #service_manager = dbus.Interface(self.bus.get_object(BLUEZ_SERVICE_NAME, adapter),GATT_MANAGER_IFACE)
        service_manager = Blue.gatt_mgr()
        service_manager.RegisterApplication(self.get_path(), {},
                reply_handler=self.register_app_callback,
                error_handler=self.register_app_error_callback)

class Service(dbus.service.Object):
    #PATH_BASE = "/org/bluez/example/service"
    PATH_BASE = "/org/bluez/service"

    def __init__(self, index, uuid, primary):
        self.path = self.PATH_BASE + str(index)
        self.uuid = uuid
        self.primary = primary
        self.characteristics = []
        dbus.service.Object.__init__(self, Blue.bus, self.path)

    def get_properties(self):
        return {
                "org.bluez.GattService1": {
                        'UUID': self.uuid,
                        'Primary': self.primary,
                        'Characteristics': dbus.Array(
                                self.get_characteristic_paths(),
                                signature='o')
                }
        }

    def get_path(self):
        return dbus.ObjectPath(self.path)

    def add_characteristic(self, characteristic):
        self.characteristics.append(characteristic)

    def get_characteristic_paths(self):
        result = []
        for characteristic in self.characteristics:
            result.append(characteristic.get_path())
        return result

    def get_characteristics(self):
        return self.characteristics

    @dbus.service.method("org.freedesktop.DBus.Properties", in_signature='s', out_signature='a{sv}')
    def GetAll(self, interface):
        return self.get_properties()["org.bluez.GattService1"]

class Characteristic(dbus.service.Object):

    def __init__(self, index, uuid, flags, service):
        self.path = service.path + '/char' + str(index)
        self.uuid = uuid
        self.service = service
        self.flags = flags
        self.descriptors = []
        dbus.service.Object.__init__(self, Blue.bus, self.path)

    def get_properties(self):
        return {
                "org.bluez.GattCharacteristic1": {
                        'Service': self.service.get_path(),
                        'UUID': self.uuid,
                        'Flags': self.flags,
                        'Descriptors': dbus.Array(
                                self.get_descriptor_paths(),
                                signature='o')
                }
        }

    def get_path(self):
        return dbus.ObjectPath(self.path)

    def add_descriptor(self, descriptor):
        self.descriptors.append(descriptor)

    def get_descriptor_paths(self):
        result = []
        for desc in self.descriptors:
            result.append(desc.get_path())
        return result

    def get_descriptors(self):
        return self.descriptors

    @dbus.service.method("org.freedesktop.DBus.Properties", in_signature='s', out_signature='a{sv}')
    def GetAll(self, interface):
        return self.get_properties()["org.bluez.GattCharacteristic1"]

    @dbus.service.method("org.bluez.GattCharacteristic1", in_signature='a{sv}', out_signature='ay')
    def ReadValue(self, options):
        mLOG.log('Default ReadValue called, returning error')

    @dbus.service.method("org.bluez.GattCharacteristic1", in_signature='aya{sv}')
    def WriteValue(self, value, options):
        mLOG.log('Default WriteValue called, returning error')

    @dbus.service.method("org.bluez.GattCharacteristic1")
    def StartNotify(self):
        mLOG.log('Default StartNotify called, returning error')

    @dbus.service.method("org.bluez.GattCharacteristic1")
    def StopNotify(self):
        mLOG.log('Default StopNotify called, returning error')

    @dbus.service.signal("org.freedesktop.DBus.Properties", signature='sa{sv}as')
    def PropertiesChanged(self, interface, changed, invalidated):
        pass

    def add_timeout(self, timeout, callback):
        GLib.timeout_add(timeout, callback)

class Descriptor(dbus.service.Object):
    def __init__(self, index,uuid, flags, characteristic):
        self.path = characteristic.path + '/desc' + str(index)
        self.uuid = uuid
        self.flags = flags
        self.chrc = characteristic
        dbus.service.Object.__init__(self, Blue.bus, self.path)

    def get_properties(self):
        return {
                "org.bluez.GattDescriptor1": {
                        'Characteristic': self.chrc.get_path(),
                        'UUID': self.uuid,
                        'Flags': self.flags,
                }
        }

    def get_path(self):
        return dbus.ObjectPath(self.path)

    @dbus.service.method("org.freedesktop.DBus.Properties", in_signature='s', out_signature='a{sv}')
    def GetAll(self, interface):
        return self.get_properties()["org.bluez.GattDescriptor1"]

    @dbus.service.method("org.bluez.GattDescriptor1", in_signature='a{sv}', out_signature='ay')
    def ReadValue(self, options):
        mLOG.log ('Default ReadValue called, returning error')

    @dbus.service.method("org.bluez.GattDescriptor1", in_signature='aya{sv}')
    def WriteValue(self, value, options):
        mLOG.log('Default WriteValue called, returning error')

#***********Define Services and Characteristics below **************************************************
#*******************************************************************************************************
"""here are uuid to use:"""
UUID_LOOPER = '6f1d8aa3-41dc-4daa-b6f2-a2a1829a83c3'
UUID_TRACK = '768f1215-e2bb-43fc-bbca-18eb0b5ff300'
UUID_VOLUME = '1e11241c-9515-4919-8229-a86fed177fe7'
UUID_SONG_NAME = 'd5409018-7328-4790-93ec-700fd2924a3e'
UUID_SPARE1 = 'f20653f6-9462-44cd-a069-51e77453b154'
UUID_SPARE2 = '1b62e81f-6671-465b-9ea4-533acfa27c23'



class LooperService(Service):

    def __init__(self, index,pipeRec,pipeSend,main_loop):
        self.track_count=0
        self.ios_song_name=''  #used for song name actions requested by ios
        self._song_name = '!'  #contains Csong_name - C is code for current, if a saved song name exists in Looper
        self.all_song_names = []
        self.all_names_ready = False
        self.warning = ''
        self.volumes={}
        self.notifications = []
        self.is_initialized = False
        self.sender = pipeSend
        self.receiver = pipeRec
        self.main_loop = main_loop
        self.session_signal = SessionSignal(self.sender)
        Service.__init__(self, index, UUID_LOOPER, True)
        self.add_characteristic(TrackCountCharacteristic(0,self))
        self.add_characteristic(TrackVolumeCharacteristic(1,self))
        self.add_characteristic(SongNameCharacteristic(2,self))

    def signal_handler(self):
        try:
            while self.receiver.poll():
                val=self.receiver.recv()
                try: #this if the volumes directory was sent
                    payload=pickle.loads(val)
                    try: #check if it is a dictionary - which means volumes were sent
                        items = payload.items()  # this fails if we passed an array
                        code = ''
                        if 'notify' in payload:
                            self.notifications.append('VolumesReady')
                            del payload['notify']
                        self.volumes = payload
                    except: #if we get here - payload is not a dictionary - which means for us that it is an array of song names
                        self.all_song_names = payload
                        self.notifications.append('SongNamesReady')
                        self.all_names_ready = True
                        code = ''
                except: #otherwise msg is in the form T4 or Esong_name (first letter is Code, rest is payload)
                    code = val[0]
                    payload = val[1:]
                mLOG.log(f'received on pipe from state Mgr: signal msg = {val}  Code={code} Payload={payload}', level=mLOG.INFO)
                if code == 'T':
                    self.track_count=int(payload)
                elif code == 'M': # this is the code for Looper notification messages to be send on Track characteristic vis notifications
                    if payload == "Initialized":
                        self.is_initialized = True
                    self.notifications.append(payload)
                elif code == 'F':
                    #FAILED_LOAD - reset initialized
                    self.warning = f'*F,{payload}'
                    self.is_initialized = True
                elif code == 'I' :
                    #requested song_name was invalid 
                    self.warning = f'*I,{payload}'
                elif code == 'E':
                    #requested song_name already exists:
                    self.warning = f'*E,{payload}'
                elif code == 'N':
                    #requested song_name to load does not exists:
                    self.warning = f'*N,{payload}'
                elif code == "O":  #Letter O - LOOPER SENT "OK"
                    self.warning = f'*O,{payload}'
                elif code == "C":
                    self.song_name = f"!{payload}"
                elif code == 'Q':
                    mLOG.log('bt_svc is quitting mainloop')
                    self.main_loop.quit()

            GLib.timeout_add(1000, self.signal_handler)
        except:
            mLOG.log(f'internal bluetooth message reception error -msg= {val}')
            mLOG.log(traceback.format_exc())
            GLib.timeout_add(1000, self.signal_handler)

    def register_volume(self,track,volume):
        mLOG.log(f'received from iphone: registering track={track} -  volume={volume}', level=mLOG.INFO)
        self.session_signal.send_signal(f'V{track},{volume}')

    def register_song_name(self,val):
        mLOG.log(f'received from iphone: registering song name {val}', level=mLOG.INFO)
        #note the first letter = Code = must added by iphone before song_name:
        #S (hex = 53) - simple song_name request
        #W (hex = 57) - song_name request with overwrite command
        #L (hex = 4C) - loading a song of the name following the letter L
        #R - requesting list of song names - letters after R will be ignored (normally use "any" like in "Rany")
        self.ios_song_name=val[1:]
        if val[0] == 'L':
            self.is_initialized = False
        self.session_signal.send_signal(f'{val}')



class TrackCountCharacteristic(Characteristic):

    def __init__(self, index,service):
        self.notifying = False
        self.last_notification = -1
        Characteristic.__init__(self, index,UUID_TRACK,["notify", "read"], service)
        self.add_descriptor(TrackCountDescriptor(0,self))
        #self.StartNotify()

    def get_track_count(self):
        value = []
        track_count = self.service.track_count
        strtemp = str(track_count)
        for c in strtemp:
            value.append(dbus.Byte(c.encode()))
        return (value,track_count)

    def set_track_count_callback(self):
        if self.notifying:
            value,track_count = self.get_track_count()
            if self.last_notification != track_count:
                self.last_notification = track_count
                mLOG.log(f'ios being notified of  track {track_count}', level=mLOG.INFO)
                self.PropertiesChanged("org.bluez.GattCharacteristic1", {"Value": value}, [])
            elif len(self.service.notifications)>0:
                strtemp = self.service.notifications.pop(0)
                value=[]
                for c in strtemp:
                    value.append(dbus.Byte(c.encode()))
                self.PropertiesChanged("org.bluez.GattCharacteristic1", {"Value": value}, [])
        return self.notifying

    def StartNotify(self):
        mLOG.log(f'ios has started notifications for track', level=mLOG.INFO)
        #if looper has initialized prior to bluetooth connection "initialized" is sitting notifications
        #and track count was updated.  so send "initialized" to ios and also set 
        #lastnotification to track count - to prevent sending it as notification (ios will read it upon receiving "initialized")
        # if "initialized" is not in notification when ios connects and start notify is called - 
        #because ios connected once, reconected without Looper having to initialize, then we MUST send Initilized anyway
        if self.notifying:
            return
        self.notifying = True
        ignore_value,track_count = self.get_track_count()
        self.last_notification = track_count

        if len(self.service.notifications)>0:
            strtemp = self.service.notifications.pop(0)
        if self.service.is_initialized:
            strtemp = "Initialized"
            while 'Initialized' in self.service.notifications: #remove all notifications of "initialized" that may have occured so far
                self.service.notifications.remove('Initialized')
            value=[]
            for c in strtemp:
                value.append(dbus.Byte(c.encode()))  
            self.PropertiesChanged("org.bluez.GattCharacteristic1", {"Value": value}, [])
        self.add_timeout(NOTIFY_TIMEOUT, self.set_track_count_callback)

    def StopNotify(self):
        self.notifying = False

    def ReadValue(self, options):
        #when ios specifically request a read on Track characteristic - always return track count (no notifications).
        value,track_count = self.get_track_count()
        self.last_notification = track_count
        mLOG.log(f'ios is reading track {track_count}', level=mLOG.INFO)
        return value

class TrackCountDescriptor(Descriptor):
    TRACK_COUNT_DESCRIPTOR_UUID = "2901"
    TRACK_COUNT_DESCRIPTOR_VALUE = "Track Count"

    def __init__(self, index, characteristic):
        Descriptor.__init__(
                self, index, self.TRACK_COUNT_DESCRIPTOR_UUID,
                ["read"],
                characteristic)

    def ReadValue(self, options):
        value = []
        desc = self.TRACK_COUNT_DESCRIPTOR_VALUE

        for c in desc:
            value.append(dbus.Byte(c.encode()))
        return value

class TrackVolumeCharacteristic(Characteristic):

    def __init__(self, index, service):
        Characteristic.__init__(
                self, index, UUID_VOLUME,
                ["read","write"], service)
        self.add_descriptor(TrackVolumeDescriptor(0,self))

    def WriteValue(self, value, options):
        #this is called by Bluez when the clients writes a value to the server (RPI)
        received=''
        for val in value:
            received+=str(val)
        mLOG.log(f'from iphone: received value {received}', level=mLOG.INFO)
        track,volume = received.split(',')
        self.service.register_volume(track,volume)
    
    def ReadValue(self, options):
        """note: lightblue app seems to call this everytime I write a track.
        if this is the lightblue app - just make sure not to read after a write.
        If it is embeded in the BlueZ api - I'll have to handle this in code here
        This should only be read when iphone app needs the track volumes upon initialization."""
        value=[]
        try:
            track,volume=self.service.volumes.popitem()
            strtemp = f'{track},{volume}'
        except KeyError:
            strtemp = '-2,0'  #-2 indicates to iphone that there are no more track,volumes to send
        mLOG.log(f"ios reading volume: {strtemp}", level=mLOG.INFO)
        for c in strtemp:
            value.append(dbus.Byte(c.encode()))
        return value

class TrackVolumeDescriptor(Descriptor):
    TRACK_VOLUME_DESCRIPTOR_UUID = "2901"
    TRACK_VOLUME_DESCRIPTOR_VALUE = "Track Volume : 0 to 10"

    def __init__(self, index, characteristic):
        Descriptor.__init__(
                self, index, self.TRACK_VOLUME_DESCRIPTOR_UUID,
                ["read"],
                characteristic)

    def ReadValue(self, options):
        value = []
        desc = self.TRACK_VOLUME_DESCRIPTOR_VALUE

        for c in desc:
            value.append(dbus.Byte(c.encode()))

        return value

class SongNameCharacteristic(Characteristic):

    def __init__(self, index, service):
        Characteristic.__init__(
                self, index, UUID_SONG_NAME,
                ["read", "write"], service)
        self.add_descriptor(SongNameDescriptor(0,self))

    def WriteValue(self, value, options):
        #this is called by Bluez when the clients writes a value to the server (RPI Looper)
        received=''
        for val in value:
            received+=str(val)
        mLOG.log(f'from iphone received song_name: {received}', level=mLOG.INFO)
        self.service.register_song_name(received)

    def ReadValue(self, options):
        #always try to send the song_names dict first
        if len(self.service.all_song_names)>0:
            val = self.service.all_song_names.pop(0)
        else:
            val = self.service.song_name
        value=[]
        for c in val:
            value.append(dbus.Byte(c.encode()))
        return value

class SongNameDescriptor(Descriptor):
    SONG_NAME_DESCRIPTOR_UUID = "2901"
    SONG_NAME_DESCRIPTOR_VALUE = "Song name for current loops"

    def __init__(self, index, characteristic):
        Descriptor.__init__(
                self, index, self.SONG_NAME_DESCRIPTOR_UUID,
                ["read"],
                characteristic)

    def ReadValue(self, options):
        value = []
        desc = self.SONG_NAME_DESCRIPTOR_VALUE

        for c in desc:
            value.append(dbus.Byte(c.encode()))

        return value

class SessionSignal:
    def __init__(self,pipeSend):
        self.sender = pipeSend

    def signal_sending(self,msg):
        mLOG.log(f'signal sent on pipe to State Mgr = {msg}', level=mLOG.INFO)
        self.sender.send(msg)

    def send_signal(self,msg):
        self.signal_sending(msg)



class Bt_Svc(multiprocessing.Process):
    def __init__(self,pipeRec,pipeSend):
        self.pipeSend = pipeSend
        self.pipeRec = pipeRec
        multiprocessing.Process.__init__(self)
        self.daemon = True

    def run(self):
        mainloop = GLib.MainLoop()
        dbus.mainloop.glib.DBusGMainLoop(set_as_default=True)
        
        Blue.set_adapter()
        
        app = Application()
    
        app.add_service(LooperService(0,self.pipeRec,self.pipeSend,mainloop))
        app.register()

        Advertise(0).register()

        try:
            GLib.timeout_add(1000, app.services[0].signal_handler)
            mainloop.run()
        except KeyboardInterrupt:
            mainloop.quit()


    




