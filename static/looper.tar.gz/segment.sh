#!/bin/bash

exportPin()
{
  if [ ! -e /sys/class/gpio/gpio$1 ]; then
    echo "$1" > /sys/class/gpio/export
  fi
  echo "out" > /sys/class/gpio/gpio$1/direction
}

a="$(grep -oP '^segment_a_pin_7 *\= *\K[0-9]+' ~/loop/looper.ini)"
b="$(grep -oP '^segment_b_pin_6 *\= *\K[0-9]+' ~/loop/looper.ini)"
c="$(grep -oP '^segment_c_pin_4 *\= *\K[0-9]+' ~/loop/looper.ini)"
d="$(grep -oP '^segment_d_pin_2 *\= *\K[0-9]+' ~/loop/looper.ini)"
e="$(grep -oP '^segment_e_pin_1 *\= *\K[0-9]+' ~/loop/looper.ini)"
f="$(grep -oP '^segment_f_pin_9 *\= *\K[0-9]+' ~/loop/looper.ini)"
g="$(grep -oP '^segment_g_pin_10 *\= *\K[0-9]+' ~/loop/looper.ini)"
exportPin $a
exportPin $b
exportPin $c
exportPin $d
exportPin $e
exportPin $f
exportPin $g

while [ 1 ]
do

# letter L

echo "0" > /sys/class/gpio/gpio$a/value
echo "0" > /sys/class/gpio/gpio$b/value
echo "0" > /sys/class/gpio/gpio$c/value
echo "1" > /sys/class/gpio/gpio$d/value
echo "1" > /sys/class/gpio/gpio$e/value
echo "1" > /sys/class/gpio/gpio$f/value
echo "0" > /sys/class/gpio/gpio$g/value
sleep 0.5
echo "0" > /sys/class/gpio/gpio$a/value
echo "0" > /sys/class/gpio/gpio$b/value
echo "0" > /sys/class/gpio/gpio$c/value
echo "0" > /sys/class/gpio/gpio$d/value
echo "0" > /sys/class/gpio/gpio$e/value
echo "0" > /sys/class/gpio/gpio$f/value
echo "0" > /sys/class/gpio/gpio$g/value
sleep 0.25
#letter O
for i in 1 2 
do 
echo "1" > /sys/class/gpio/gpio$a/value
echo "1" > /sys/class/gpio/gpio$b/value
echo "1" > /sys/class/gpio/gpio$c/value
echo "1" > /sys/class/gpio/gpio$d/value
echo "1" > /sys/class/gpio/gpio$e/value
echo "1" > /sys/class/gpio/gpio$f/value
echo "0" > /sys/class/gpio/gpio$g/value
sleep 0.5
echo "0" > /sys/class/gpio/gpio$a/value
echo "0" > /sys/class/gpio/gpio$b/value
echo "0" > /sys/class/gpio/gpio$c/value
echo "0" > /sys/class/gpio/gpio$d/value
echo "0" > /sys/class/gpio/gpio$e/value
echo "0" > /sys/class/gpio/gpio$f/value
echo "0" > /sys/class/gpio/gpio$g/value
sleep 0.25
done

#letter P

echo "1" > /sys/class/gpio/gpio$a/value
echo "1" > /sys/class/gpio/gpio$b/value
echo "0" > /sys/class/gpio/gpio$c/value
echo "0" > /sys/class/gpio/gpio$d/value
echo "1" > /sys/class/gpio/gpio$e/value
echo "1" > /sys/class/gpio/gpio$f/value
echo "1" > /sys/class/gpio/gpio$g/value
sleep 0.5
echo "0" > /sys/class/gpio/gpio$a/value
echo "0" > /sys/class/gpio/gpio$b/value
echo "0" > /sys/class/gpio/gpio$c/value
echo "0" > /sys/class/gpio/gpio$d/value
echo "0" > /sys/class/gpio/gpio$e/value
echo "0" > /sys/class/gpio/gpio$f/value
echo "0" > /sys/class/gpio/gpio$g/value
sleep 0.25

done
