#!/bin/bash

exportPin()
{
  if [ ! -e /sys/class/gpio/gpio$1 ]; then
    echo "$1" > /sys/class/gpio/export
  fi
  echo "out" > /sys/class/gpio/gpio$1/direction
}

exportPin 21
exportPin 19
exportPin 13
exportPin 6
exportPin 5
exportPin 22
exportPin 27

while [ 1 ]
do

# letter L

echo "0" > /sys/class/gpio/gpio21/value
echo "0" > /sys/class/gpio/gpio19/value
echo "0" > /sys/class/gpio/gpio13/value
echo "1" > /sys/class/gpio/gpio6/value
echo "1" > /sys/class/gpio/gpio5/value
echo "1" > /sys/class/gpio/gpio22/value
echo "0" > /sys/class/gpio/gpio27/value
sleep 0.5
echo "0" > /sys/class/gpio/gpio21/value
echo "0" > /sys/class/gpio/gpio19/value
echo "0" > /sys/class/gpio/gpio13/value
echo "0" > /sys/class/gpio/gpio6/value
echo "0" > /sys/class/gpio/gpio5/value
echo "0" > /sys/class/gpio/gpio22/value
echo "0" > /sys/class/gpio/gpio27/value
sleep 0.25
#letter O

echo "1" > /sys/class/gpio/gpio21/value
echo "1" > /sys/class/gpio/gpio19/value
echo "1" > /sys/class/gpio/gpio13/value
echo "1" > /sys/class/gpio/gpio6/value
echo "1" > /sys/class/gpio/gpio5/value
echo "1" > /sys/class/gpio/gpio22/value
echo "0" > /sys/class/gpio/gpio27/value
sleep 0.5
echo "0" > /sys/class/gpio/gpio21/value
echo "0" > /sys/class/gpio/gpio19/value
echo "0" > /sys/class/gpio/gpio13/value
echo "0" > /sys/class/gpio/gpio6/value
echo "0" > /sys/class/gpio/gpio5/value
echo "0" > /sys/class/gpio/gpio22/value
echo "0" > /sys/class/gpio/gpio27/value
sleep 0.25

#letter O

echo "1" > /sys/class/gpio/gpio21/value
echo "1" > /sys/class/gpio/gpio19/value
echo "1" > /sys/class/gpio/gpio13/value
echo "1" > /sys/class/gpio/gpio6/value
echo "1" > /sys/class/gpio/gpio5/value
echo "1" > /sys/class/gpio/gpio22/value
echo "0" > /sys/class/gpio/gpio27/value

sleep 0.5
echo "0" > /sys/class/gpio/gpio21/value
echo "0" > /sys/class/gpio/gpio19/value
echo "0" > /sys/class/gpio/gpio13/value
echo "0" > /sys/class/gpio/gpio6/value
echo "0" > /sys/class/gpio/gpio5/value
echo "0" > /sys/class/gpio/gpio22/value
echo "0" > /sys/class/gpio/gpio27/value
sleep 0.25

#letter P

echo "1" > /sys/class/gpio/gpio21/value
echo "1" > /sys/class/gpio/gpio19/value
echo "0" > /sys/class/gpio/gpio13/value
echo "0" > /sys/class/gpio/gpio6/value
echo "1" > /sys/class/gpio/gpio5/value
echo "1" > /sys/class/gpio/gpio22/value
echo "1" > /sys/class/gpio/gpio27/value

sleep 0.5
echo "0" > /sys/class/gpio/gpio21/value
echo "0" > /sys/class/gpio/gpio19/value
echo "0" > /sys/class/gpio/gpio13/value
echo "0" > /sys/class/gpio/gpio6/value
echo "0" > /sys/class/gpio/gpio5/value
echo "0" > /sys/class/gpio/gpio22/value
echo "0" > /sys/class/gpio/gpio27/value
sleep 0.25

done
